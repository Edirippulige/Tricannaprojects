﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using EvoraClientApp.dbconnect;
using EvoraClientApp.Model;
using EvoraClientApp.ExceptionHandler;
using System.Data.SqlClient;


namespace EvoraClientApp.Service
{


    public class VendorserviceService
    {
        private readonly string _connectionString;

        public VendorserviceService(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<Vendor> ReadVendorsFromJsonString(string jsonContent)
        {
            try
            {
                return JsonSerializer.Deserialize<List<Vendor>>(jsonContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deserializing JSON content: {ex.Message}");
                return null;
            }
        }


        public async Task SaveVendorsToDatabase(List<Vendor> vendors)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    // Assuming there is a Vendor table with appropriate schema

                    using (SqlCommand command = new System.Data.SqlClient.SqlCommand("INSERT INTO Vendors (AccountNumber,Addr1,AltContact,AltPhone,Balance,City,CompanyName,Contact,Country,CreditLimit,Email,EvoraNumber,Fax,FirstName,IsActive,IsVendorEligibleFor1099,LastName,LicenseNumber,MiddleName,Name,NameOnCheck,Note,Phone,PostalCode,Salutation,State,VendorTaxIdent) VALUES (@AccountNumber,@Addr1,@AltContact,@AltPhone,@Balance,@City,@CompanyName,@Contact,@Country,@CreditLimit,@Email,@EvoraNumber,@Fax,@FirstName,@IsActive,@IsVendorEligibleFor1099,@LastName,@LicenseNumber,@MiddleName,@Name,@NameOnCheck,@Note,@Phone,@PostalCode,@Salutation,@State,@VendorTaxIdent)", connection))
                    {
                        foreach (var vendor in vendors)
                        {
                            command.Parameters.Clear();
                            command.Parameters.AddWithValue("@AccountNumber", vendor.AccountNumber);
                            command.Parameters.AddWithValue("@Addr1", vendor.Addr1);
                            command.Parameters.AddWithValue("@AltContact", vendor.AltContact);
                            command.Parameters.AddWithValue("@AltPhone", vendor.AltPhone);
                            command.Parameters.AddWithValue("@Balance", vendor.Balance);
                            command.Parameters.AddWithValue("@City", vendor.City);
                            command.Parameters.AddWithValue("@CompanyName", vendor.CompanyName);
                            command.Parameters.AddWithValue("@Contact", vendor.Contact);
                            command.Parameters.AddWithValue("@Country", vendor.Country);
                            command.Parameters.AddWithValue("@CreditLimit", vendor.CreditLimit);
                            command.Parameters.AddWithValue("@Email", vendor.Email);
                            command.Parameters.AddWithValue("@EvoraNumber", vendor.EvoraNumber);
                            command.Parameters.AddWithValue("@Fax", vendor.Fax);
                            command.Parameters.AddWithValue("@FirstName", vendor.FirstName);
                            command.Parameters.AddWithValue("@IsActive", vendor.IsActive);
                            command.Parameters.AddWithValue("@IsVendorEligibleFor1099", vendor.IsVendorEligibleFor1099);
                            command.Parameters.AddWithValue("@LastName", vendor.LastName);
                            command.Parameters.AddWithValue("@LicenseNumber", vendor.LicenseNumber);
                            command.Parameters.AddWithValue("@MiddleName", vendor.MiddleName);
                            command.Parameters.AddWithValue("@Name", vendor.Name);
                            command.Parameters.AddWithValue("@NameOnCheck", vendor.NameOnCheck);
                            command.Parameters.AddWithValue("@Note", vendor.Note);
                            command.Parameters.AddWithValue("@Phone", vendor.Phone);
                            command.Parameters.AddWithValue("@PostalCode", vendor.PostalCode);
                            command.Parameters.AddWithValue("@Salutation", vendor.Salutation);
                            command.Parameters.AddWithValue("@State", vendor.State);
                            command.Parameters.AddWithValue("@VendorTaxIdent", vendor.VendorTaxIdent);


                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }

                Console.WriteLine("Customers saved to the database successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving customers to the database: {ex.Message}");
            }
        }
    }



}
