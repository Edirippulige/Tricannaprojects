﻿using EvoraAPI.dbconnect;
using EvoraClientApp.ExceptionHandler;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EvoraClientApp.dbconnect
{
    class DbOperation
    {

        SqlConnection cn;
        SqlCommand command;
        SqlDataAdapter adapter;
        DataSet ds;
        DbConnect dbconnect = new DbConnect();

      

        //...............................................................................................................................................................
        // set sql command and then we can insert data to table in the database
        public void setData(String SqlCommand)
        {
            try
            {
                cn = dbconnect.dbConnet();
                cn.Open();
                command = new SqlCommand(SqlCommand, cn);
                command.ExecuteNonQuery();
                //MessageBox.Show("Data Added Sucessfuly");
                cn.Close();
            }
            catch (Exception e)
            {
                ExceptionWritter.LogErrorWriter("Error on database.  " + e.Message.ToString()); ;
                //MessageBox.Show("Data Additon Error....! ", "Warning.....!");
            }
        }
        //
        //...............................................................................................................................................................
        // set sql command and then we can select data from table in the database
        public DataSet getData(String SqlCommand)
        {
            cn = dbconnect.dbConnet();
            try
            {
                ds = new DataSet();
                cn.Open();
                adapter = new SqlDataAdapter(SqlCommand, cn);
                adapter.Fill(ds);
                cn.Close();
            }
            catch (Exception e)
            {
                ExceptionWritter.LogErrorWriter("Error on database.  " + e.Message.ToString()); ;
                cn.Close();
            }
            return ds;
        }
        //
        //...............................................................................................................................................................
        //Get the count of Data in the table
        public DataSet getcountData(String SqlCommand)
        {

            cn = dbconnect.dbConnet();

            try
            {
                ds = new DataSet();
                cn.Open();
                adapter = new SqlDataAdapter(SqlCommand, cn);
                adapter.Fill(ds);
                cn.Close();
            }
            catch (Exception e)
            {
                ExceptionWritter.LogErrorWriter("Error on database.  " + e.Message.ToString()); ;
                cn.Close();

            }
            return ds;

        }
        //
        //...............................................................................................................................................................
        /* public void Remove_History(String SqlCommand)            // This Method use for delete existing data item from data table        
         {
             try
             {
                 cn = dbconnect.dbConnet();

                 if (cn.State != ConnectionState.Open)
                 {
                     cn.Open();
                     OleDbCommand cmdRemove = new OleDbCommand(SqlCommand, cn);
                     cmdRemove.ExecuteNonQuery();
                     cn.Close();
                 }
             }
             catch (Exception)
             {
                 //MessageBox.Show("Connection Error, contact your system administrator", "Error State 04");


             }
         }*/
    }

}
