﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public  class EvoraNewLine
    {
        public string id { get; set; }
        public string item { get; set; }
        public string uom { get; set; }
        public string container { get; set; }
        public double? quantity { get; set; }
        public double? price { get; set; }

        public double? lot { get; set; }
        public double? gst { get; set; }

        public double? pst { get; set; }
        public double? hst { get; set; }
    }
}
