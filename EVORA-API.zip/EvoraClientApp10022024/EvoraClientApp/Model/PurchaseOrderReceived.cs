﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class PurchaseOrderReceived
    {
        public string number { get; set; }
        public string id { get; set; }
        public string item { get; set; }
        public decimal? quantity { get; set; }
        public string uom { get; set; }
        public string percent { get; set; }
    }
}
