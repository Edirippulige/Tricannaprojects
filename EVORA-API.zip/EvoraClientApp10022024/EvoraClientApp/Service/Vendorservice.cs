﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using EvoraClientApp.dbconnect;
using EvoraClientApp.Model;
using EvoraClientApp.ExceptionHandler;
using System.Data.SqlClient;


namespace EvoraClientApp.Service
{


    public class Vendorservice
    {
        public static string serverName = "DESKTOP-JAY"; // Replace with your SQL Server name or IP address
        public static string databaseName = "QB"; // Replace with your database name
        public static string userName = "sa"; // Replace with your SQL Server username
        public static string password = "SQLT3$t23"; // Replace with your SQL Server password

        // Build the connection string
        public static string connectionString = $"Server={serverName};Database={databaseName};User Id={userName};Password={password};";

        private readonly string _connectionString = connectionString;

        public Vendorservice()
        {
        }
        public Vendorservice(string connectionString)
        {
            _connectionString = connectionString;
        }

        public List<EvoraVendor> ReadVendorsFromJsonString(string jsonContent)
        {
            try
            {
                return JsonSerializer.Deserialize<List<EvoraVendor>>(jsonContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deserializing JSON content: {ex.Message}");
                return null;
            }
        }


        public async Task SaveVendorsToDatabase(List<Vendor> vendors)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    // Assuming there is a Vendor table with appropriate schema

                    using (SqlCommand command = new System.Data.SqlClient.SqlCommand("INSERT INTO Vendors (number,Name,CompanyName,Phone,Email,term,licenseType,type,LicenseNumber,Street1,Street2,City,Postal,Country) VALUES (@number,@Name,@CompanyName,@Phone,@Email,@term,@licenseType,@type,@LicenseNumber,@Street1,@Street2,@City,@Postal,@Country)", connection))
                    {
                        foreach (var vendor in vendors)
                        {
                            command.Parameters.Clear();
                            command.Parameters.AddWithValue("@number", (object)vendor.number?? DBNull.Value);
                            command.Parameters.AddWithValue("@name", (object)vendor.name ?? DBNull.Value);
                            command.Parameters.AddWithValue("@phonenumber", (object)vendor.phonenumber ?? DBNull.Value);
                            command.Parameters.AddWithValue("@licenseType", (object)vendor.licenseType ?? DBNull.Value);
                            command.Parameters.AddWithValue("@terms", (object)vendor.terms?? DBNull.Value);
                            command.Parameters.AddWithValue("@type", (object)vendor.type ?? DBNull.Value);
                            command.Parameters.AddWithValue("@street1", (object)vendor.street1 ?? DBNull.Value);
                            command.Parameters.AddWithValue("@street2", (object)vendor.street2 ?? DBNull.Value);
                            command.Parameters.AddWithValue("@city", (object)vendor.city ?? DBNull.Value);
                            command.Parameters.AddWithValue("@prov", (object)vendor.prov ?? DBNull.Value);
                            command.Parameters.AddWithValue("@postal", (object)vendor.postal ?? DBNull.Value);
                            


                            string billCountryValue = vendor.country ?? ""; // Assuming BillCountry is a string property


                            // Replace 'CA' with 'CANADA'
                            if (billCountryValue.Equals("CA", StringComparison.OrdinalIgnoreCase))
                            {
                                billCountryValue = "CANADA";
                            }

                            // Add the value to the parameter
                            command.Parameters.AddWithValue("@country", (object)billCountryValue ?? DBNull.Value);


                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }

                Console.WriteLine("Customers saved to the database successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving customers to the database: {ex.Message}");
            }
        }
    }



}
