﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public class contents
    {
        public string id { get; set; }

        public string item { get; set; }

        public string uom { get; set; }
        public decimal? quantity { get; set; }

        public string container { get; set; }
        public string lot { get; set; }
        public decimal? expectedquantity { get; set; }

        //purchaseorder
      
        public string VendorLot { get; set; }
    
        public string Count { get; set; }
        public decimal? unitCost { get; set; }
        public decimal? lineCost { get; set; }
        public decimal? tax { get; set; }
        public string TotalUOM { get; set; }
        public string Bin { get; set; }
        public string ContainerType { get; set; }

        //receipts
        

    }
}
