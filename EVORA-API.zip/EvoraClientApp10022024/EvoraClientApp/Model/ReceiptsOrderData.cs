﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class ReceiptsOrderData
    {
        public string number { get; set; }
        public string status { get; set; }
        public string type { get; set; }
        public string location { get; set; }
        public DateTime date { get; set; }
        public decimal? sale { get; set; }
        public string customer { get; set; }
        public string vendor { get; set; }
        public string courier { get; set; }
        public string shippingNumber { get; set; }
        public string purchaseOrder { get; set; }

        List<ReceiptsOrderContent> contents { get; set; }

    }
}
