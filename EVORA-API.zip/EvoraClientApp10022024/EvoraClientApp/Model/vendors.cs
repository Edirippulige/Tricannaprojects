﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public class vendors
    {
        public string vendor { get; set; }


    }

    
}
