﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public class EvoraItemledger
    {
        public string id { get; set; }
        public string number { get; set; }
        public string entryType { get; set; }
        public string item { get; set; }
        public string description { get; set; }
        public string lot { get; set; }
        public string baseLot { get; set; }
        public string location { get; set; }
        public double quantity { get; set; }
        public string uom { get; set; }
        public object activity { get; set; }
        public string reason { get; set; }
        public string bin { get; set; }
        public DateTime postingDate { get; set; }
        public DateTime lastUpdated { get; set; }
        public object expires { get; set; }
    }
}
