﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using EvoraClientApp.dbconnect;
using EvoraClientApp.Model;
using EvoraClientApp.ExceptionHandler;
using System.Data.SqlClient;

namespace EvoraClientApp.Service
{
    public class EvoraSalesservice
    {

        public static string serverName = "DESKTOP-JAY"; // Replace with your SQL Server name or IP address
        public static string databaseName = "QB"; // Replace with your database name
        public static string userName = "sa"; // Replace with your SQL Server username
        public static string password = "SQLT3$t23"; // Replace with your SQL Server password

        // Build the connection string
        public static string connectionString = $"Server={serverName};Database={databaseName};User Id={userName};Password={password};";

        private readonly string _connectionString = connectionString;

        public EvoraSalesservice()
        {
        }

        public EvoraSalesservice(string connectionString)
        {
            _connectionString = connectionString;
        }




        public List<EvoraSales> ReadEvoraSalesFromJsonString(string jsonContent)
        {
            try
            {
                if (string.IsNullOrEmpty(jsonContent))
                {
                    Console.WriteLine("JSON content is null or empty.");
                    return null;
                }


                return JsonSerializer.Deserialize<List<EvoraSales>>(jsonContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deserializing JSON content: {ex.Message}");
                return null;
            }
        }






    }

}
