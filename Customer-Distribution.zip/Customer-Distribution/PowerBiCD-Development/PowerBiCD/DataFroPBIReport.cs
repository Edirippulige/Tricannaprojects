﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace PowerBiCD
{
    //class DataFroPBIReport
    //{
    //}
  
        class DataFroPBIReport
        {
            public string ESTABLISH_NAME { get; set; }
            public string ADDRESS { get; set; }
            public string CITY { get; set; }
            public string VENDOR_NUMBER_PO { get; set; }
            public string VENDOR_NAME { get; set; }
            public string PRODUCT_SKU_NO { get; set; }
            public string PRODUCT_NAME { get; set; }
            public string WEEK_ENDING_DATE { get; set; }
            public string CASE_SALES { get; set; }

    }
    }


