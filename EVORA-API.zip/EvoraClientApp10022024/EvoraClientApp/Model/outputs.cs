﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class outputs
    {
        public string item { get; set; }
        public decimal? amount { get; set; }
        public string uom { get; set;}
        public string lot { get; set; }
        public string status { get; set; }
    }
}
