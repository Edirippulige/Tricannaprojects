﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using EvoraClientApp.dbconnect;
using EvoraClientApp.Model;
using EvoraClientApp.ExceptionHandler;
using System.Data.SqlClient;


namespace EvoraClientApp.Service
{

   
    public class CustomerService
    {

        public static string serverName = "DESKTOP-JAY"; // Replace with your SQL Server name or IP address
        public static string databaseName = "QB"; // Replace with your database name
        public static string userName = "sa"; // Replace with your SQL Server username
        public static string password = "SQLT3$t23"; // Replace with your SQL Server password

        // Build the connection string
        public static string connectionString = $"Server={serverName};Database={databaseName};User Id={userName};Password={password};";

        private readonly string _connectionString = connectionString;

        public CustomerService()
        {
        }

        public CustomerService(string connectionString)
        {
            _connectionString = connectionString;
        }

        

        public List<EvoraCustomer> ReadCustomersFromJsonString(string jsonContent)
        {
            try
            {
                if (string.IsNullOrEmpty(jsonContent))
                {
                    Console.WriteLine("JSON content is null or empty.");
                    return null;
                }


                return JsonSerializer.Deserialize<List<EvoraCustomer>>(jsonContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deserializing JSON content: {ex.Message}");
                return null;
            }
        }


       


        public async Task SaveCustomersToDatabase(List<Customer> customers)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    
                    await connection.OpenAsync();

                    // Assuming there is a Customers table with appropriate schema
                           
                    //using (SqlCommand command = new System.Data.SqlClient.SqlCommand("INSERT INTO Customers (BillAddr1, BillAddr2,BillAddr3,Billcity,Billcountry,Billpostalcode,Billstate,CustomerFullName,CustomerIsActive,CustomerName,Email,FirstName,LastName,LicenseNumber,MiddleName,phone,Salutation,ShipAddr1,ShipAddr2,Shipcity,ShipCountry,ShipNote,ShipPostalcode,Shipstate,LicenseExpiryDate) VALUES (@BillAddr1,@BillAddr2,@BillAddr3,@BillCity,@BillCountry,@BillNote,@BillPostalCode,@BillState,@CustomerFullName,@CustomerIsActive,@CustomerName,@Email,@FirstName,@LastName,@LicenseNumber,@MiddleName,@Phone,@Salutation,@ShipAddr1,@ShipAddr2,@ShipCity,@ShipCountry,@ShipNote,@ShipPostalCode,@ShipState,@ExpiryDate)", connection))
                    using (SqlCommand command = new System.Data.SqlClient.SqlCommand("INSERT INTO Customer (CustomerName,BillAddr1,BillAddr2,BillCity,BillCountry,BillState,BillPostalCode,Evoranumber) VALUES (@CustomerName,@BillAddr1,@BillAddr2,@BillCity,@BillCountry,@BillState,@BillPostalCode,@Evoranumber)", connection))
                    {
                        foreach (var customer in customers)
                        {
                            command.Parameters.Clear();
                            command.Parameters.AddWithValue("@CustomerName", (object)customer.CustomerName?? DBNull.Value);
                            command.Parameters.AddWithValue("@BillAddr1", (object)customer.BillAddr1 ?? DBNull.Value);
                            command.Parameters.AddWithValue("@BillAddr2", (object)customer.BillAddr2 ?? DBNull.Value);
                            //command.Parameters.AddWithValue("@BillAddr3", customer.BillAddr3);
                            command.Parameters.AddWithValue("@BillCity", (object)customer.Billcity ?? DBNull.Value);   
                            //command.Parameters.AddWithValue("@BillCountry", (object)customer.Billcountry ?? DBNull.Value);
                            string billCountryValue = customer.Billcountry?? ""; // Assuming BillCountry is a string property
                                                      

                            // Replace 'CA' with 'CANADA'
                            if (billCountryValue.Equals("CA", StringComparison.OrdinalIgnoreCase))
                            {
                                billCountryValue = "CANADA";
                            }

                            // Add the value to the parameter
                            command.Parameters.AddWithValue("@BillCountry", (object)billCountryValue ?? DBNull.Value);


                            // command.Parameters.AddWithValue("@BillNote", customer.BillNote);
                            command.Parameters.AddWithValue("@BillPostalCode", (object)customer.Billpostalcode ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Evoranumber", (object)customer.EvoraNumber ?? DBNull.Value);
                            command.Parameters.AddWithValue("@BillState", (object)customer.Billstate ?? DBNull.Value);
                            // command.Parameters.AddWithValue("@CustomerFullName", customer.CustomerFullName);
                            //command.Parameters.AddWithValue("@CustomerIsActive", customer.CustomerIsActive);
                            // command.Parameters.AddWithValue("@CustomerName", customer.CustomerName);
                            // command.Parameters.AddWithValue("@Email", customer.Email); 
                            //command.Parameters.AddWithValue("@FirstName", customer.FirstName);
                            //command.Parameters.AddWithValue("@LastName", customer.LastName);
                            //command.Parameters.AddWithValue("@LicenseNumber", customer.LicenseNumber);
                            //command.Parameters.AddWithValue("@MiddleName", customer.MiddleName);
                            //command.Parameters.AddWithValue("@Phone", customer.phone);                        
                            // command.Parameters.AddWithValue("@Salutation", customer.Salutation);
                            // command.Parameters.AddWithValue("@ShipAddr1", customer.ShipAddr1);
                            // command.Parameters.AddWithValue("@ShipAddr2", customer.ShipAddr2);
                            // command.Parameters.AddWithValue("@ShipCity", customer.Shipcity);
                            // command.Parameters.AddWithValue("@ShipCountry", customer.ShipCountry);
                            //  command.Parameters.AddWithValue("@ShipNote", customer.ShipNote);
                            //  command.Parameters.AddWithValue("@ShipPostalCode", customer.ShipPostalcode);
                            //   command.Parameters.AddWithValue("@ShipState", customer.Shipstate);
                            //   command.Parameters.AddWithValue("@ExpiryDate", customer.LicenseExpiryDate);



                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }

                Console.WriteLine("Customers saved to the database successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving customers to the database: {ex.Message}");
            }
        }
    }



}
