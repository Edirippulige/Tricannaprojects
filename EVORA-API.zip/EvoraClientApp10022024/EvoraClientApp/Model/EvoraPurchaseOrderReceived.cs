﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class EvoraPurchaseOrderReceived
    {
        public string id { get; set; }
        public string item { get; set; }
        public int quantity { get; set; }
        public string uom { get; set; }
        public int percent { get; set; }
    }
}
