﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class PurchaseOrdersData
    {
        public string number { get; set; }
        public string type { get; set; }
        public decimal? sale { get; set; }
        public string status { get; set; }
        public string location { get; set; }
        public string customer { get; set; }
        public string courier { get; set; }
        public string shippingNumber { get; set; }
        public string purchaseOrder { get; set; }
        public DateTime date { get; set; }
        public string vendor { get; set; }
        public decimal? amount { get; set; }
        public string gstRate { get; set; }
        public object pstRate { get; set; }
        public object hstRate { get; set; }
        public decimal? taxAmount { get; set; }
        public object totalAmount { get; set; }
        public object expectedDelivery { get; set; }
        public List<PurchaseOrderContent> contents { get; set; }
        public List<PurchaseOrderReceived> received { get; set; }
    }
}
