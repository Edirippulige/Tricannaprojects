﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TricannaAPI.dbconnect;
using TricannaAPI.Model;
using QBFC16Lib;
using TricannaAPI.ExceptionHandler;

namespace TricannaAPI.Service
{

    public class VendorService
    {
        public int VendorCount = 0;
        //These values from QB for update function to compare with DB values
        public string public_vendorId = "";
        public string public_vendorEditSeq = "";
        public string Public_Name = "";
        public string Public_MainEmail = "";
        public string Public_MainPhone = "";
        public string Public_Company = "";
        //public bool Public_Active = false;
        public string Public_Title = "";
        public string Public_FirstName = "";
        public string Public_LastName = "";
        public string Public_BillFrom1 = "";
        public string Public_BillCity = "";
        public string Public_BillState = "";
        public string Public_BillCountry = "";
        public string Public_BillPostalCode = "";
        public string Public_BillNote = "";
        public string Public_PrintOnCheqAS = "";
        public double Public_CreditLimit = 0.00;
       // public bool Public_IsVendoreligible1099 = "";
        public string Public_VendorTaxId = "";
        public string Public_Balance = "";
        public string Public_LicNumber = "";
        public string Public_CurrencyFullName = "";
        public string public_LicenseNumber = "";

        

        public List<Vendor> GetAllVendorsFromDatabase()
        {
            List<Vendor> vendors = new List<Vendor>();
            Vendor vendorObject = new Vendor();

            DbOperation dbOperation = new DbOperation();

            string sqlQuery = "SELECT * FROM Vendor";
            DataSet vendorData = dbOperation.getData(sqlQuery);

            int x = 0;
            string sqlQueryCount = "Select Count(*) As VendorCount from Vendor";
            DataSet vendorCountData = dbOperation.getcountData(sqlQueryCount);
            ExceptionWritter.LogInfoWriter($"----------------Gather vendor data from database to update vendors record..! at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

            VendorCount = vendorData.Tables[x].Rows.Count;
            //Console.WriteLine("Customer count from database= " + CustomerCount);
            ExceptionWritter.LogInfoWriter($"----------------Vendor count from database= {VendorCount} at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");




            if (vendorData != null && vendorData.Tables.Count > 0 && vendorData.Tables.Count > x)
            {
                foreach (DataRow row in vendorData.Tables[x].Rows)
                {
                    vendorObject = new Vendor(); // Create a new Customer object for each customer

                    //Assign DB values to the vendor

                    vendorObject.Name = row["Name"].ToString() + " (V)";        //getting vendor name from database and assign into the module
                    vendorObject.Company = row["CompanyName"].ToString();
                    vendorObject.Active = bool.Parse(row["IsActive"].ToString());
                    vendorObject.Title = row["Salutation"].ToString();
                    vendorObject.FirstName = row["FirstName"].ToString();
                    vendorObject.MiddleInitial = row["MiddleName"].ToString();
                    vendorObject.LastName = row["LastName"].ToString();

                    vendorObject.BillFrom1= row["CompanyName"].ToString();
                    vendorObject.BillCity = row["Addr1"].ToString()+ ", " + row["City"].ToString(); //Addr1
                    vendorObject.BillPostalCode= row["PostalCode"].ToString();
                    vendorObject.BillState = row["State"].ToString();
                    vendorObject.BillCountry = row["Country"].ToString();
                    //vendorObject.BillNote = row["Note"].ToString();
                    vendorObject.AltPhone = row["AltPhone"].ToString();
                    vendorObject.MainPhone = row["Phone"].ToString();
                    vendorObject.MainEmail = row["Email"].ToString();
                    vendorObject.Fax = row["Fax"].ToString();
                    vendorObject.LicenseNumber = row["LicenseNumber"].ToString();
                   // vendorObject.AltPhone = row["AltContact"].ToString();
                    //vendorObject.PrimaryContact = row["Contact"].ToString();
                    //vendorObject.AccountNumber = row["AccountNumber"].ToString();
                    //vendorObject.PrintOnCheqAS = row["NameOnCheck"].ToString();
                    //vendorObject.CreditLimit = double.Parse(row["CreditLimit"].ToString());
                   // string creditLimitString = row["CreditLimit"].ToString();
                    //vendorObject.IsVendoreligible1099 = bool.Parse(row["IsVendorEligibleFor1099"].ToString());
                   // vendorObject.VendorTaxId = row["VendorTaxIdent"].ToString();
                   // vendorObject.Balance = double.Parse(row["Balance"].ToString());


                    vendors.Add(vendorObject);

                    ExceptionWritter.LogInfoWriter($"----------------The vendor {vendorObject.Name} found ..! at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                    //Console.WriteLine("Vendor Name = " + customerObject.Name);
                }
                Console.WriteLine("");
                //Console.WriteLine("End of read database");
                ExceptionWritter.LogInfoWriter($"End of read database at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                Console.WriteLine("");
            }

            else
            {
                // Console.WriteLine("No Vendor data found.");
                ExceptionWritter.LogErrorWriter($"vendors'data not found at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");
            }

            // Console.WriteLine("Gather vendor data from database to update vendors record..! Successfull..******************************************");
            ExceptionWritter.LogInfoWriter($"Gather vendor data from database to update vendors record..! Successfull.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");
            Console.Read();

            return vendors;
        }

        public void AddVendorsToQuickBooks(List<Vendor> vendors)
        
        {
            // Initialize the QuickBooks Application object
            ExceptionWritter.LogInfoWriter($"Initialize QuickBooks Application For Update Vendors Record..! Please Wait.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

            //Console.WriteLine("Initialize QuickBooks Application For Update Customers Record..! Please Wait..******************************************");
            QBSessionManager sessionManager = new QBSessionManager();
            //Console.WriteLine("Open QuickBooks Application Connection For Update Customers Record..! Please Wait..*************************************");
            ExceptionWritter.LogInfoWriter($"Open QuickBooks Application Connection For Update Vendors Record..! Please Wait.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");


            sessionManager.OpenConnection("", "QuickBooks Desktop");

            //Console.WriteLine("Accept the QuickBooks Application access certificate Connection For Update Customers Record..! Please Wait..************");
           // ExceptionWritter.LogInfoWriter($"Accept the QuickBooks Application access certificate Connection For Update Vendors Record..! Please Wait.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

           sessionManager.BeginSession("", ENOpenMode.omDontCare);
           Console.WriteLine("Customers Record Updating.....! Please Wait..***************************************************************************");
            ExceptionWritter.LogInfoWriter($"----------------Vendors Record Updating started.....!  at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");


            foreach (Vendor vendor in vendors)
            {
                // Create a VendorAdd request for each vendor
                IMsgSetRequest msgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
                msgSet.Attributes.OnError = ENRqOnError.roeStop;

                IVendorAdd vendorAdd = msgSet.AppendVendorAddRq();
               // IVendorAdd vendorAdd = (IVendorAdd) msgSet.AppendVendorModRq();
                // Adding customer values to the QB
                vendorAdd.Name.SetValue(vendor.Name);
                vendorAdd.Email.SetValue(vendor.MainEmail);
                vendorAdd.Phone.SetValue(vendor.MainPhone);
                vendorAdd.CompanyName.SetValue(vendor.Company);
                vendorAdd.IsActive.SetValue(vendor.Active);
                vendorAdd.Salutation.SetValue(vendor.Title);
                vendorAdd.FirstName.SetValue(vendor.FirstName);
                vendorAdd.LastName.SetValue(vendor.LastName);
                vendorAdd.VendorAddress.Addr1.SetValue(vendor.BillFrom1);
                vendorAdd.VendorAddress.City.SetValue(vendor.BillCity);
                vendorAdd.VendorAddress.State.SetValue(vendor.BillState);
                vendorAdd.VendorAddress.Country.SetValue(vendor.BillCountry);
                vendorAdd.VendorAddress.PostalCode.SetValue(vendor.BillPostalCode);
                //vendorAdd.VendorAddress.Note.SetValue(vendor.BillNote);
                vendorAdd.AccountNumber.SetValue(vendor.LicenseNumber);
                //vendorAdd.VendorAddress.Other1.SetValue(vendor.LicenseNumber);
                //if (vendorAdd.VendorAddress is IAddress vendorAddress)
                //{
                //    //vendorAddress.Addr1.SetValue(vendor.Address);
                //    //vendorAddress.Addr2.SetValue(vendor.City);

                //    // Add Other1 and Other2 details to the vendor's address
                //    //vendorAddress.Other1 = (vendor.LicenseNumber);

                //    //vendorAddress.Other2.SetValue(vendor.Other2);
                //}


                //vendorAdd.NameOnCheck.SetValue(vendor.PrintOnCheqAS);
                //vendorAdd.CreditLimit.SetValue(vendor.CreditLimit);
                //vendorAdd.IsVendorEligibleFor1099.SetValue(vendor.IsVendoreligible1099);
                //vendorAdd.VendorTaxIdent.SetValue(vendor.VendorTaxId);
                //vendorAdd.OpenBalance.SetValue(vendor.Balance);
                // vendorAdd.ExternalGUID.SetValue(vendor.LicNumber);
                //vendorAdd.CurrencyRef.FullName.SetValue(vendor.CurrencyFullName);

                IMsgSetResponse response = sessionManager.DoRequests(msgSet);
                Console.WriteLine(response.ResponseList.GetAt(0).ToString());
                Console.WriteLine(response.ResponseList.GetAt(0).StatusCode.ToString()+"sattus code for "+vendor.Name);
               
                if (response.ResponseList.GetAt(0).StatusCode == 0)
                {
                    //Console.WriteLine("Open QuickBooks Application Connection For Update Customers Record..! Please Wait..******************************************");
                    //Console.WriteLine(customer.Name + " Customer created successfully..!");
                    ExceptionWritter.LogInfoWriter($"{vendor.Name}  Vendor created successfully..!  $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                    Console.WriteLine("");
                }
                else
                {
                    //Console.WriteLine(response.ResponseList.GetAt(0).StatusMessage);
                    // ExceptionWritter.LogInfoWriter($"{customer.Name}  Customer created successfully..!  $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                    // find getCustomerListIDAndEditSequence 
                    try
                    {
                        GetVendorListIDAndEditSequence(vendor.Name);

                        GetVendorDataFromQB(vendor.Name);
                        //GetVendorListIDAndEdit

                        //Passing customer values to update

                        //            {




                        UpdateVendor(vendor.Name, vendor.MainEmail, vendor.MainPhone, vendor.Company, vendor.Title, vendor.FirstName,
                          vendor.LastName, vendor.BillFrom1, vendor.BillCity, vendor.BillState, vendor.BillCountry, vendor.BillPostalCode,/*vendor.BillNote*/vendor.LicenseNumber);



                    }
                    catch (Exception e)
                    {
                        ExceptionWritter.LogErrorWriter($"Vendor Update Error..! Customer Name: {vendor.Name}, Error Message: {e.Message} at {DateTime.Now:yyyy.MM.dd HH:mm:ss:ffff}");
                        throw;
                    }



                }
            }

            // Close the QuickBooks session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();
            //Console.WriteLine("Close QuickBooks Application Connection. Please Wait..******************************************************************");
            ExceptionWritter.LogInfoWriter($"Close QuickBooks Application Connection.!  $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

            Console.Read();
        }


        // Reset Globel variable for next vendor
        public void ResetValue()
        {
            public_vendorId = "";
            public_vendorEditSeq = "";
            Public_Name = "";
            Public_MainEmail = "";
            Public_MainPhone = "";
            Public_Company = "";
           // Public_Active = false;
            Public_Title = "";
            Public_FirstName = "";
            Public_LastName = "";
            Public_BillFrom1 = "";
            Public_BillCity = "";
            Public_BillState = "";
            Public_BillCountry = "";
            Public_BillPostalCode = "";
            Public_BillNote = "";
            Public_PrintOnCheqAS = "";
            Public_CreditLimit = 0.00;
            //Public_IsVendoreligible1099 = false;
            Public_VendorTaxId = "";
            Public_Balance = "";
            Public_LicNumber = "";
            Public_CurrencyFullName = "";
            public_LicenseNumber = "";




        }

        //get Customer ListId And EditSequence
        public void getVendorListIDAndEditSequence()
        {

            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "QuickBooks Desktop");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to get a list of vendors
            var query = requestMsgSet.AppendVendorTypeAddRq();

            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);

            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var vendorRetList = response.Detail as IVendorRetList;

                if (vendorRetList != null)
                {
                    for (int i = 0; i < vendorRetList.Count; i++)
                    {
                        var vendorRet = vendorRetList.GetAt(i);
                        var vendorId = vendorRet.ListID.GetValue();
                        var vendorEditSeq = vendorRet.EditSequence.GetValue();
                        var vendorName = vendorRet.Name.GetValue();
                        //Console.WriteLine($"Customer ID: {customerId}, Customer Name: {customerName},Customer Edit Sequance: {customerEditSeq}");
                    }
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();

            Console.ReadLine();
        }

        // get quickbook data for specific customer
        public void GetVendorDataFromQB(string vendorName)
        {
            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "Your App Name");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to find a specific customer by name
            var query = requestMsgSet.AppendVendorQueryRq();
            query.ORVendorListQuery.FullNameList.Add(vendorName);

            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);

            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var vendorRetList = response.Detail as IVendorRetList;

                if (vendorRetList != null && vendorRetList.Count > 0)
                {
                    var vendorRet = vendorRetList.GetAt(0); // Assuming you found one vendor with the provided name

                    // Retrieve various vendor data fields
                    public_vendorId = vendorRet.ListID.GetValue();
                    public_vendorEditSeq = vendorRet.EditSequence.GetValue();
                    Public_Name = vendorRet?.Name?.GetValue() ?? "";
                    Public_MainEmail = vendorRet?.Email?.GetValue() ?? "";
                    Public_MainPhone = vendorRet?.Phone?.GetValue() ?? "";
                    Public_Company = vendorRet?.CompanyName?.GetValue() ?? "";
                    //Public_Active = vendorRet?.IsActive?.GetValue() ?? true;
                    Public_Title = vendorRet?.Salutation?.GetValue() ?? "";
                    Public_FirstName = vendorRet?.FirstName?.GetValue() ?? "";
                    Public_LastName = vendorRet?.LastName?.GetValue() ?? "";
                    Public_BillFrom1 = vendorRet?.VendorAddress?.Addr1.GetValue() ?? "";
                    Public_BillCity = vendorRet?.VendorAddress?.City?.GetValue() ?? "";
                    Public_BillState = vendorRet?.VendorAddress?.State?.GetValue() ?? "";
                    Public_BillPostalCode = vendorRet?.VendorAddress?.PostalCode?.GetValue() ?? "";
                    Public_BillCountry = vendorRet?.VendorAddress?.Country?.GetValue() ?? "";
                    //Public_BillNote = vendorRet?.Notes?.GetValue() ?? "";
                    Public_PrintOnCheqAS = vendorRet?.NameOnCheck?.GetValue() ?? "";
                    Public_CreditLimit = vendorRet?.CreditLimit?.GetValue() ?? 0.0;
                    //Public_IsVendoreligible1099 = vendorRet?.IsVendorEligibleFor1099.GetValue() ?? true;
                    //Public_VendorTaxId = vendorRet?.ShipAddress?.State?.GetValue() ?? "";
                    //Public_Balance = vendorRet?.ShipAddress?.PostalCode?.GetValue() ?? "";
                    public_LicenseNumber = vendorRet?.AccountNumber?.GetValue() ?? "";
                    Public_CurrencyFullName = vendorRet?.ShipAddress?.Note?.GetValue() ?? "";
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();
        }

        public void UpdateVendor(string New_Name, string New_MainEmail, string New_MainPhone, string New_Company, string New_Title, string New_FirstName,
                         string New_LastName, string New_BillFrom1, string New_BillCity, string New_BillState, string New_BillCountry, string New_BillPostalCode,/*string New_BillNote*/string New_LicenseNumber)

        {
            /* add more nullable parameters for other fields as needed */


            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "Your App Name");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to find a specific customer by name
            var query = requestMsgSet.AppendVendorQueryRq();
            query.ORVendorListQuery.FullNameList.Add(New_Name);

            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);

            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var vendorRetList = response.Detail as IVendorRetList;    //Get vendor datafield from Quickbooks assign dataset to VendorRetList object

                if (vendorRetList != null && vendorRetList.Count > 0)
                {
                    var vendorRet = vendorRetList.GetAt(0);

                    // Get the vendor's ListID and EditSequence
                    var vendorId = vendorRet.ListID.GetValue();
                    var vendorEditSeq = vendorRet.EditSequence.GetValue();

                    // Create a VendorMod request to update selected fields
                    var vendorMod = requestMsgSet.AppendVendorModRq();
                    vendorMod.ListID.SetValue(vendorId);
                    vendorMod.EditSequence.SetValue(vendorEditSeq);

                    // Update the fields if non-null values are provided
                    if (!string.IsNullOrEmpty(New_MainEmail))
                    {
                        
                        vendorMod.Email.SetValue(New_MainEmail);
                    }

                    if (!string.IsNullOrEmpty(New_MainPhone))
                    {
                        vendorMod.Phone.SetValue(New_MainPhone);
                    }

                    if (!string.IsNullOrEmpty(New_Company))
                    {
                        
                        vendorMod.CompanyName.SetValue(New_Company);
                    }

                    if (!string.IsNullOrEmpty(New_Title))
                    {
                        vendorMod.Salutation.SetValue(New_Title);
                    }


                    if (!string.IsNullOrEmpty(New_FirstName))
                    {
                        vendorMod.FirstName.SetValue(New_FirstName);
                    }

                    if (!string.IsNullOrEmpty(New_LastName))
                    {
                        vendorMod.LastName.SetValue(New_LastName);
                    }

                    if (!string.IsNullOrEmpty(New_BillFrom1))
                    {
                        vendorMod.VendorAddress.Addr1.SetValue(New_BillFrom1);
                    }
                    if (!string.IsNullOrEmpty(New_BillCity))
                    {
                        vendorMod.VendorAddress.City.SetValue(New_BillCity);
                    }
                    if (!string.IsNullOrEmpty(New_BillState))
                    {
                        vendorMod.VendorAddress.State.SetValue(New_BillState);
                    }

                    if (!string.IsNullOrEmpty(New_BillCountry))
                    {
                        vendorMod.VendorAddress.Country.SetValue(New_BillCountry);
                    }

                    if (!string.IsNullOrEmpty(New_BillPostalCode))
                    {
                        vendorMod.VendorAddress.PostalCode.SetValue(New_BillPostalCode);
                    }
                    //if (!string.IsNullOrEmpty(New_BillNote))
                    //{
                    //    vendorMod.VendorAddress.PostalCode.SetValue(New_BillNote);
                    //}
                    if (!string.IsNullOrEmpty(New_LicenseNumber))
                    {
                        vendorMod.AccountNumber.SetValue(New_LicenseNumber);
                    }


                    // Update other fields if non-null values are provided

                    // Execute the modification request
                    var responseMod = sessionManager.DoRequests(requestMsgSet);

                    if (responseMod.ResponseList.Count > 0)
                    {
                        var responseModVendor = responseMod.ResponseList.GetAt(0);

                        if (responseModVendor.StatusCode == 0)
                        {
                            //Console.WriteLine($"Customer: {New_Name} updated {New_MainEmail} {New_MainPhone} {New_BillTo1} successfully.");
                            //Console.WriteLine("");
                            ExceptionWritter.LogInfoWriter($"Vendor: {New_Name} updated successfully $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                        }
                        else
                        {
                            ExceptionWritter.LogErrorWriter($"Vendor: {New_Name} not updated successfully $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");
                        }
                    }
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();
        }







        public (string ListID, string EditSequence) GetVendorListIDAndEditSequence(string vendorName)
        {
            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "QuickBooks Desktop");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to find a specific vendor by name
            var query = requestMsgSet.AppendVendorQueryRq();
            query.ORVendorListQuery.FullNameList.Add(vendorName);
            //query.ORVendorListQuery.FullNameList.GetAt


            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);

            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var vendorRetList = response.Detail as IVendorRetList;

                if (vendorRetList != null && vendorRetList.Count > 0)
                {
                    var vendorRet = vendorRetList.GetAt(0); // Assuming you found one customer with the provided name
                    var vendorId = vendorRet.ListID.GetValue();
                    var vendorEditSeq = vendorRet.EditSequence.GetValue();
                    var vendorNamed = vendorRet.Name.GetValue();
                    Console.WriteLine($"Vendor ID: {vendorId}, Vendor Name: {vendorNamed}, Vendor Edit Sequence: {vendorEditSeq}");
                    return (vendorId, vendorEditSeq);
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();

            //Console.WriteLine($"No customer found with the name: {customerName}");
            ExceptionWritter.LogInfoWriter($"No vendor found with the name: {vendorName} at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}");
            return (null, null); // Return null if the customer is not found
        }


    }

    //public interface IAddress
    //{
    //    string Other1 { get; set; }
    //    string Other2 { get; set; }
    //}

    //public interface IVendorAdd
    //{
    //    string Name { get; set; }
    //    string Email { get; set; }
    //    IAddress VendorAddress { get; set; }
    //}

}
