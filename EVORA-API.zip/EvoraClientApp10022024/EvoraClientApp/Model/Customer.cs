﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
  public  class Customer
    {
        public string EvoraNumber { get; set; } // Number
        public string CustomerType { get; set; } // Type
        public string CustomerName { get; set; }
        public string CustomerFullName { get; set; }
        public bool CustomerIsActive { get; set; }
        public string Salutation { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string BillAddr1 { get; set; }
        public string BillAddr2 { get; set; }
        public string BillAddr3 { get; set; }
        public string Billcity { get; set; }
        public string Billcountry { get; set; }
        public string Billstate { get; set; }
        public string Billpostalcode { get; set; }
        public string BillNote { get; set; }
        public string ShipAddr1 { get; set; }
        public string ShipAddr2 { get; set; }
        public string Shipcity { get; set; }
        public string Shipstate { get; set; }

        public string ShipCountry { get; set; }
        public string ShipPostalcode { get; set; }
        public string ShipNote { get; set; }
        public string Email { get; set; }
        public string phone { get; set; }
        public string LicenseNumber { get; set; }
        public DateTime LicenseExpiryDate { get; set; }


    }
}
