﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class EvoraVendor
    {
        public string number { get; set; }
        public string name { get; set; }
        public string phoneNumber { get; set; }
        public string licenseType { get; set; }
        public string terms { get; set; }
        public string type { get; set; }
        public string companyname { get; set; }
        public address address { get; set; }


    }
}

