﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public class EvoraProductionBatches
    {
        public string number { get; set; }
        public string description { get; set; }
        public string location { get; set; }
        public string status { get; set; }
        public DateTime? plannedStart { get; set; }
        public DateTime? actualStart { get; set; }
        public string startItem { get; set; }
        public string outputItem { get; set; }
        public string uom { get; set; }
        public decimal? outputQuantity { get; set; }
        public decimal? actualOutput { get; set; }
        public DateTime? dueDate { get; set; }
        public DateTime? packagedOn { get; set; }

        public List<activities> activities { get; set; }
        public List<outputs> outputs { get; set; }
        public List<inputs> inputs { get; set; }


    }
}
