﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.Configuration;

namespace PowerBiCD
{
    class Program
    {

        public static string dateValue = "";
        public static string filePath = "";
        public static string recordexist = "";
        public static string fileexist = "";
        //public static string serverName = "DESKTOP-JAY"; // Replace with your SQL Server name or IP address
        //public static string databaseName = "ReportServer"; // Replace with your database name
        //public static string userName = "sa"; // Replace with your SQL Server username
        //public static string password = "SQLT3$t23"; // Replace with your SQL Server password

      //  public static string connectionString = $"Server={serverName};Database={databaseName};User Id={userName};Password={password};";

        static void Main()
        {
            //Get the file path from App.config file
            filePath = ConfigurationManager.AppSettings["file_path"];

            //Fetch into a list after reading the CSV file
            List<DataFroPBIReport> dataList = ReadCsvFile<DataFroPBIReport>(filePath);

            //Get the Date from the CSV file
            getDate();

            //Assigning Azure SQL DB connection to the connectionString
             string connectionString = "Server=tcp:reporting.database.windows.net,1433;Initial Catalog=Reporting;Persist Security Info=False;User ID=Master;Password=Tr1c@nn@SQLS3rv3r$;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            //Saving data to the Azure db
            SaveListToSqlServer(dataList, connectionString);

            //Exit the program
            Console.WriteLine("Press Any Key to Exit...!");
            Console.Read();

        }

        /// <summary>
        /// Get date from the CSV file name
        /// </summary>
        public static void getDate()
        {

            // Define a regular expression pattern to match the date
            string pattern = @"(\d{4}-\d{2}-\d{2})"; // Assuming the date format is YYYY-MM-DD

            // Use Regex.Match to find the first match in the string
            Match match = Regex.Match(filePath, pattern);

            // Check if a match is found
            if (match.Success)
            {
                // Extract the matched date value
                dateValue = match.Groups[1].Value;

                // Parse the date string to a DateTime object if needed
                if (DateTime.TryParse(dateValue, out DateTime date))
                {
                    Console.WriteLine("Found Date: " + date.ToString("yyyy-MM-dd"));
                }
                else
                {
                    Console.WriteLine("Unable to parse the date.");
                }
            }
            else
            {
                Console.WriteLine("No date found in the file path.");
            }



            Console.WriteLine(dateValue);
        }


        /// <summary>
        /// Read CSV file and return datalist
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static List<T> ReadCsvFile<T>(string filePath)
        {
            try
            {

                // CSV File Reading Process
                using (var reader = new StreamReader(filePath))
                using (var csv = new CsvReader(reader, new CsvHelper.Configuration.CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    Delimiter = "\t" // Set the delimiter to tab
                }))
                {
                    //Return CSV file included data as a list
                    return csv.GetRecords<T>().ToList();
                }
            }
            catch (Exception ex)
            {
                // If got an error while reading process, send  a message to the user 
                Console.WriteLine($"Error reading CSV file: {ex.Message}");
                return new List<T>();
            }
        }

        /// <summary>
        /// Save data to the azure db
        /// </summary>
        /// <param name="dataList"></param>
        /// <param name="connectionString"></param>

        public static void SaveListToSqlServer(List<DataFroPBIReport> dataList, string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                recordexist = FileExists(connection, dateValue);
            }
            if (recordexist.Equals("No"))  // Check if the record does not exist
            {
                try
                {
                    foreach (var dataInstance in dataList)
                    {
                        string weekEndingDate = DateTime.Parse(dataInstance.WEEK_ENDING_DATE).ToString("yyyy-MM-dd");

                        // Check if the record exists for the given week ending date but with a different recorded date
                        string recordExistsQuery = "SELECT COUNT(*) FROM Customer_Distribution WHERE WEEK_ENDING_DATE = @WeekEndingDate AND FILE_DATE <> @FileDate";

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();


                            using (SqlCommand checkCommand = new SqlCommand(recordExistsQuery, connection))
                            {
                                checkCommand.Parameters.AddWithValue("@WeekEndingDate", weekEndingDate);
                                checkCommand.Parameters.AddWithValue("@FileDate", DateTime.Parse(dateValue));

                                int count = (int)checkCommand.ExecuteScalar();

                                if (count == 0) // If no record exists with the same week ending date but different recorded date
                                {
                                    // Proceed with insertion
                                    string insertQuery = @"
                            INSERT INTO Customer_Distribution(ESTABLISH_NAME, ADDRESS, CITY, VENDOR_NUMBER_PO, VENDOR_NAME,
                                PRODUCT_SKU_NO, PRODUCT_NAME, WEEK_ENDING_DATE, CASE_SALES, FILE_DATE) 
                            VALUES (@ESTABLISH_NAME, @ADDRESS, @CITY, @VENDOR_NUMBER_PO, @VENDOR_NAME, @PRODUCT_SKU_NO,
                                @PRODUCT_NAME, @WEEK_ENDING_DATE, @CASE_SALES, @FILE_DATE)";

                                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                                    {
                                        command.Parameters.AddWithValue("@ESTABLISH_NAME", dataInstance.ESTABLISH_NAME);
                                        command.Parameters.AddWithValue("@ADDRESS", dataInstance.ADDRESS);
                                        command.Parameters.AddWithValue("@CITY", dataInstance.CITY);
                                        command.Parameters.AddWithValue("@VENDOR_NUMBER_PO", dataInstance.VENDOR_NUMBER_PO);
                                        command.Parameters.AddWithValue("@VENDOR_NAME", dataInstance.VENDOR_NAME);
                                        command.Parameters.AddWithValue("@PRODUCT_SKU_NO", dataInstance.PRODUCT_SKU_NO);
                                        command.Parameters.AddWithValue("@PRODUCT_NAME", dataInstance.PRODUCT_NAME);
                                        command.Parameters.AddWithValue("@WEEK_ENDING_DATE", DateTime.Parse(dataInstance.WEEK_ENDING_DATE));
                                        command.Parameters.AddWithValue("@CASE_SALES", Double.Parse(dataInstance.CASE_SALES));
                                        command.Parameters.AddWithValue("@FILE_DATE", DateTime.Parse(dateValue));

                                        // Execute the SQL command
                                        command.ExecuteNonQuery();
                                    }
                                }
                                else
                                {
                                    Console.WriteLine($"Record already exists for week ending on: {weekEndingDate} with a different recorded date. Skipping insertion.");
                                }
                            }
                        }
                    }

                    Console.WriteLine("Data successfully inserted into SQL Server.");
                }

                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine("Record already exists. Skipping insertion.");
                Console.WriteLine("Press Any Key to Continue..!");
                Console.ReadLine();

            }

        }




        private static string FileExists(SqlConnection connection, string recordedDate)
        {
            // get value form azure db
            string checkQuery = "SELECT COUNT(*) FROM Customer_Distribution WHERE FILE_DATE = @RecordedDate";
            string state = "";

            using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
            {
                checkCommand.Parameters.AddWithValue("@RecordedDate", recordedDate);

                int count = (int)checkCommand.ExecuteScalar();

                if (count > 0)
                {
                    state = "Yes";
                }
                else
                {
                    state = "No";
                }
            }

            return state;
        }




        private static bool RecordExists(SqlConnection connection, string weekEndingDate, string recordedDate)
        {
            // Query to check if records exist for the given week ending date and recorded date
            string checkQuery = "SELECT COUNT(*) FROM Customer_Distribution WHERE WEEK_ENDING_DATE = @WeekEndingDate AND FILE_DATE = @RecordedDate";

            // Execute the query
            using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
            {
                // Add parameters for the week ending date and recorded date
                checkCommand.Parameters.AddWithValue("@WeekEndingDate", weekEndingDate);
                checkCommand.Parameters.AddWithValue("@RecordedDate", recordedDate);

                // Execute the scalar query to get the count of records
                int count = (int)checkCommand.ExecuteScalar();

                // Return true if records exist for the given week ending date and recorded date, otherwise false
                return count > 0;
            }
        }
    }

}







