﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class EvoraPurchaseOrderContent
    {
        public string id { get; set; }
        public string item { get; set; }
        public decimal? quantity { get; set; }
        public string uom { get; set; }
        public decimal? unitCost { get; set; }
        public decimal? lineCost { get; set; }
        public decimal? tax { get; set; }
    }

}
