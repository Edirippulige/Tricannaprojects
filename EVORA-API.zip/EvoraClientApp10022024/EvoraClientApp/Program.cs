﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
//using Newtonsoft.Json;
using System.Text.Json;
using EvoraClientApp.AccessToken;
using EvoraClientApp.APIRequest;
using EvoraClientApp.Service;
using EvoraClientApp.Model;
using EvoraClientApp.ExceptionHandler;
using System.Data.SqlClient;
using Newtonsoft.Json;

namespace EvoraClientApp
{
    public class Program
    {
        //public static string serverName = "DESKTOP-JAY"; // Replace with your SQL Server name or IP address
        //public static string databaseName = "QB"; // Replace with your database name
        //public static string userName = "sa"; // Replace with your SQL Server username
        //public static string password = "SQLT3$t23"; // Replace with your SQL Server password


        //replace data with Azure info
        //public static string serverName = "tcp:reporting.database.windows.net,1433";
        //public static string databaseName = "Reporting"; // Replace with your database name
        //public static string userName = "Master"; // Replace with your SQL Server username
        //public static string password = "Tr1c@nn@SQLS3rv3r$"; // Replace with your SQL Server password
       //Azure connection string
        public static string connectionString = "Server=tcp:reporting.database.windows.net,1433;Initial Catalog=Reporting;Persist Security Info=False;User ID=Master;Password=Tr1c@nn@SQLS3rv3r$;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            

        // Build the connection string
        //public static string connectionString = $"Server={serverName};Database={databaseName};User Id={userName};Password={password};";
        private static readonly string _connectionString = connectionString;

        public static string publicToken = "";
        public string tokenid = "";

        private static string customerJason;
        private static string itemJason;
        private static string itemledgerjason;
        private static string vendorJason;
        private static string salesjason;
        private static string shipmentjason;
        private static string purchaseOrderJson;
        private static string receiptorderJason;
        private static string productionbatchesJason;
        private static string productionorderJason;

        public static GetAccessToken gettoken = new GetAccessToken();
        public static CustomerApiRequest cusapirequest = new CustomerApiRequest();
        public static CustomerService customerservice = new CustomerService();
        public static Vendorservice vendorservice = new Vendorservice();
        public static ItemService itemService = new ItemService();
        public static EvoraItemledgerservice itemledgerservice = new EvoraItemledgerservice();
        public static EvoraSalesservice evorasalesservice = new EvoraSalesservice();
        public static EvoraSales salesservice = new EvoraSales();
        public static ExceptionWritter writter = new ExceptionWritter();
        public static Evorashipment evorashipment = new Evorashipment();
        public static EvoraPurchaseOrder evoraPurchaseOrder = new EvoraPurchaseOrder();
        public static EvoraReceiptsOrder evoraReceiptsorder = new EvoraReceiptsOrder();
        public static List<Customer> customerList = new List<Customer>();
        public static List<Vendor> vendorList = new List<Vendor>();
        public static List<EvoraCustomer> evoracustomerList = new List<EvoraCustomer>();
        public static List<EvoraVendor> evoravendorList = new List<EvoraVendor>();
        public static List<EvoraItem> evoraitemList = new List<EvoraItem>();
        public static List<EvoraItemledger> evoraitemledgerList = new List<EvoraItemledger>();
        public static List<EvoraAddress> addresses = new List<EvoraAddress>();
        public static List<address> vAddress = new List<address>();
        public static List<VendorAddress> vaddresses = new List<VendorAddress>();
        public static List<EvoraLines> linesList = new List<EvoraLines>();
        public static List<EvoraShipped> shippedList = new List<EvoraShipped>();
        public static List<Vendor> vendors = new List<Vendor>();
        public static List<Item> item = new List<Item>();
        public static List<Itemledger> itemledger = new List<Itemledger>();
        public static List<EvoraSales> evorasalesList = new List<EvoraSales>();
        public static List<Sales> salesList = new List<Sales>();
        public static List<EvoraNewLine> linelist = new List<EvoraNewLine>();
        public static List<contents> shipmentcontentslist = new List<contents>();
        public static List<Evorashipment> evorashipmentlist = new List<Evorashipment>();
        public static List<Shipment> shipmentlist = new List<Shipment>();
        public static List<Shipmentcontents> shipmentcontentlist = new List<Shipmentcontents>();
        public static List<EvoraPurchaseOrder> evoraPurchaseOrderList = new List<EvoraPurchaseOrder>();
        public static List<PurchaseOrdersData> PurchaseOrderDataList = new List<PurchaseOrdersData>();
        public static List<PurchaseOrderContent> purchContentList = new List<PurchaseOrderContent>();
        public static List<PurchaseOrderReceived> purchReceivedList = new List<PurchaseOrderReceived>();
        public static List<EvoraProductionBatches> evoraproductionbatchList = new List<EvoraProductionBatches>();
        public static List<productionorderactivities> productionorderactivitiesList = new List<productionorderactivities>();
        public static List<productionorderinputs> productioninputsList = new List<productionorderinputs>();
        public static List<productionorderoutput> productionorderoutputsList = new List<productionorderoutput>();
        public static List<EvoraReceiptsOrder> evoraReceiptsOrderList = new List<EvoraReceiptsOrder>();
        public static List<ReceiptsOrderData> ReceiptsOrderDataList = new List<ReceiptsOrderData>();
        public static List<ReceiptsOrderContent> receiptsContentList = new List<ReceiptsOrderContent>();
        public static List<ProductionBatches> productionbatchdataList = new List<ProductionBatches>();
        public static List<PInput> pInputList = new List<PInput>();
        public static List<ProductionOrder> POrder = new List<ProductionOrder>();
        public static List<POutput> pOutputList = new List<POutput>();


        public static async Task Main()
        {
            Program p = new Program();
            writter.LogInfoWriter("--------------------------------------------------------------------------Application started--------------------------------------------------------------------------");
            writter.LogInfoWriter("------------------" + "Application authoraiation started....!" + "--------------------------------------------------------------------------");

            Prepairetoken();
            Console.ReadLine();
            ///This App is the latest version
            await GetcustomerData();
            evoracustomerList = customerservice.ReadCustomersFromJsonString(customerJason);
            foreach (var evoracustomer in evoracustomerList)
            {
                Customer customer = new Customer();
                Console.WriteLine($"Customer: {evoracustomer.number}");
                Console.WriteLine($"Customer: {evoracustomer.name}");
                Console.WriteLine($"type: {evoracustomer.type}");
                customer.EvoraNumber = evoracustomer.number;
                customer.CustomerName = evoracustomer.name;


                //  Check if evoraAaddresses is not null before accessing its elements
                if (evoracustomer.addresses != null)
                {
                    //   Iterate through evoraAaddresses and print information
                    foreach (var address in evoracustomer.addresses)
                    {
                        Console.WriteLine($"Address Number: {address.number}");
                        Console.WriteLine($"Address Type: {address.type}");
                        Console.WriteLine($"Street1: {address.street1}");
                        Console.WriteLine($"Street2: {address.street2}");
                        Console.WriteLine($"City: {address.city}");
                        Console.WriteLine($"Province: {address.prov}");
                        Console.WriteLine($"Postal Code: {address.postal}");
                        Console.WriteLine($"Country: {address.country}");
                        Console.WriteLine();

                        customer.BillAddr1 = address.street1;
                        customer.BillAddr2 = address.street2;
                        customer.Billcity = address.city;
                        customer.Billpostalcode = address.postal;
                        customer.Billcountry = address.country;
                        customer.Billstate = address.prov;


                    }
                }
                else
                {
                    Console.WriteLine("No addresses available for this customer.");
                }
                customerList.Add(customer);

            }
            await p.SaveCustomersToDatabase(customerList, _connectionString);
            Console.ReadLine();

            ////-----------------------------------------------------------------------vendornew-----------------------

            await GetvendorData();
            List<EvoraVendor> evoraVendorList = JsonConvert.DeserializeObject<List<EvoraVendor>>(vendorJason);
            foreach (EvoraVendor evoraVendorDataList in evoraVendorList)
            {
                Vendor vendor = new Vendor();

                vendor.number = evoraVendorDataList.number;
                Console.WriteLine($"number: {vendor.number}");

                vendor.name = evoraVendorDataList.name;
                Console.WriteLine($"name: {vendor.name}");

                vendor.companyname = evoraVendorDataList.companyname;
                Console.WriteLine($"companyname: {vendor.companyname}");

                vendor.phonenumber = evoraVendorDataList.phoneNumber;
                Console.WriteLine($"phonenumber: {vendor.phonenumber}");

                vendor.licenseType = evoraVendorDataList.licenseType;
                Console.WriteLine($"licenseType: {vendor.licenseType}");

                vendor.terms = evoraVendorDataList.terms;
                Console.WriteLine($"terms: {vendor.terms}");

                vendor.type = evoraVendorDataList.type;
                Console.WriteLine($"type: {vendor.type}");

                vendorList.Add(vendor);

                address addressContent = evoraVendorDataList.address;

                VendorAddress vaddress = new VendorAddress();

                vaddress.street1 = addressContent.street1;
                Console.WriteLine($"street1: {vaddress.street1}");

                vaddress.street2 = addressContent.street2;
                Console.WriteLine($"street2: {vaddress.street2}");

                vaddress.city = addressContent.city;
                Console.WriteLine($"city: {vaddress.city}");

                vaddress.prov = addressContent.prov;
                Console.WriteLine($"prov: {vaddress.prov}");

                vaddress.postal = addressContent.postal;
                Console.WriteLine($"postal: {vaddress.postal}");

                vaddress.country = addressContent.country;
                Console.WriteLine($"country: {vaddress.country}");

                vAddress.Add(addressContent);
            }
            p.SaveVendorsToDatabase(vendorList, vAddress, _connectionString);
            Console.ReadLine();

            ///-------------------------------------------------------------------------vendornewend---------------------------

            await GetitemData();
            evoraitemList = itemService.ReadItemsFromJsonString(itemJason);
            foreach (var evoraitem in evoraitemList)
            {
                Item items = new Item();


                items.EvoraItemNumber = evoraitem.number;
                Console.WriteLine($"number: {items.EvoraItemNumber}");
                items.EvoraItemName = evoraitem.name;
                Console.WriteLine($"name: {items.EvoraItemName}");
                items.category = evoraitem.category;
                Console.WriteLine($"category: {items.category}");
                items.categoryName = evoraitem.categoryName;
                Console.WriteLine($"categoryName:{items.categoryName}");
                items.Uom = evoraitem.uom;
                Console.WriteLine($"uom: {items.Uom}");
                items.PurchaseUOM = evoraitem.purchaseUOM;
                Console.WriteLine($"purchase_uom: {items.PurchaseUOM}");
                items.EachQuantity = evoraitem.eachQuantity.ToString();
                Console.WriteLine($"each_quantity: {items.EachQuantity}");
                items.Strain = evoraitem.strain;
                Console.WriteLine($"strain: {items.Strain}");
                items.Inventory = evoraitem.inventory.ToString();
                Console.WriteLine($"inventory: {items.Inventory}");
                items.Price = evoraitem.price.ToString();
                Console.WriteLine($"price: {items.Price}");
                items.ItemCount = evoraitem.count.ToString();
                Console.WriteLine($"count: {items.ItemCount}");
                items.AverageWeight = evoraitem.averageWeight.ToString();
                Console.WriteLine($"average_weight: {items.AverageWeight}");
                items.Cost = evoraitem.cost.ToString();
                Console.WriteLine($"cost: {items.Cost}");
                items.Tracking = evoraitem.tracking;
                Console.WriteLine($"tracking: {items.Tracking}");
                items.ReorderLeadTime = evoraitem.reorderLeadTime;
                Console.WriteLine($"reorder_lead_time: {items.ReorderLeadTime}");
                items.ThcMg = evoraitem.thcMg;
                Console.WriteLine($"thc_mg: {items.ThcMg}");
                items.CbdMg = evoraitem.cbdMg;
                Console.WriteLine($"cbd_mg: {items.CbdMg}");
                items.PackSizeG = evoraitem.packSizeG.ToString();
                Console.WriteLine($"pack_size_g: {items.PackSizeG}");
                items.PackCount = evoraitem.packCount.ToString();
                Console.WriteLine($"pack_count: {items.PackCount}");
                items.ExpirationMonths = evoraitem.expirationMonths;
                Console.WriteLine($"expiration_months: {items.ExpirationMonths}");
                items.NewLotStatus = evoraitem.newLotStatus;
                Console.WriteLine($"new_lot_status: {items.NewLotStatus}");
                items.ExpectedUnitCost = evoraitem.expectedUnitCost;
                Console.WriteLine($"expected_unit_cost: {items.ExpectedUnitCost}");
                items.RegistrationNumer = evoraitem.registrationNumer;
                Console.WriteLine($"registration_number: {items.RegistrationNumer}");
                items.Sku = evoraitem.sku;
                Console.WriteLine($"sku: {items.Sku}");
                items.Gtin = evoraitem.gtin;
                Console.WriteLine($"gtin: {items.Gtin}");
                items.CaseQuantity = evoraitem.caseQuantity.ToString();
                Console.WriteLine($"case_quantity: {items.CaseQuantity}");
                items.MinimumQuantity = evoraitem.minimumQuantity.ToString();
                Console.WriteLine($"minimum_quantity: {items.MinimumQuantity}");
                items.ProductNumber = evoraitem.productNumber;
                Console.WriteLine($"product_number: {items.ProductNumber}");
                items.Description2 = evoraitem.description2;
                Console.WriteLine($"description2: {items.Description2}");
                items.FullCost = evoraitem.fullCost.ToString();
                Console.WriteLine($"full_cost: {items.FullCost}");
                items.Description2 = evoraitem.description2;
                Console.WriteLine($"description2: {items.Description2}");
                items.TotalUnitWeightG = evoraitem.totalUnitWeightG.ToString();
                Console.WriteLine($"total_unit_weight_g: {items.TotalUnitWeightG}");
                items.SkuOwner = evoraitem.skuOwner;
                Console.WriteLine($"sku_owner: {items.SkuOwner}");
                //--------------------------------------------------------------------------------------------------------------------------------------

                if (evoraitem.vendors != null && evoraitem.vendors.Count > 0)
                {


                    foreach (string vendor in evoraitem.vendors)
                    {

                        Console.WriteLine("Vendors:" + vendor);
                        items.VendorID = vendor;
                    }
                }


                item.Add(items);


            }
            Console.WriteLine("Item count is" + item.Count);
            p.SaveItemsToDatabase(item, _connectionString);
            Console.ReadLine();

            await GetEvoraItemledgerData();
            evoraitemledgerList = itemledgerservice.ReadEvoraItemledgerFromJsonString(itemledgerjason);
            foreach (var evoraitemledger in evoraitemledgerList)
            {
                Itemledger iteml = new Itemledger();

                Console.WriteLine($": {iteml.Activity}");
                if (evoraitemledger != null && evoraitemledger.activity != null)
                {
                    iteml.Activity = evoraitemledger.activity.ToString();
                }
                else
                {
                    iteml.Activity = "Null";
                }
                iteml.BaseLot = evoraitemledger.baseLot;
                Console.WriteLine($"name: {iteml.BaseLot}");


                iteml.Bin = evoraitemledger.bin;
                Console.WriteLine($"Bin: {iteml.Bin}");

                iteml.Description = evoraitemledger.description;
                Console.WriteLine($"Description: {iteml.Description}");

                iteml.EntryType = evoraitemledger.entryType;
                Console.WriteLine($"EntryType: {iteml.EntryType}");

                //iteml.Expires = evoraitemledger.expires.ToString();

                if (evoraitemledger != null && evoraitemledger.expires != null)
                {
                    iteml.Expires = evoraitemledger.expires.ToString();
                }
                else
                {
                    iteml.Expires = "Null";
                }


                Console.WriteLine($"Expires: {iteml.Expires}");

                iteml.ID = evoraitemledger.id;
                Console.WriteLine($"ID: {iteml.ID}");


                iteml.Item = evoraitemledger.item;
                Console.WriteLine($"Item: {iteml.Item}");

                iteml.LastUpdated = PrepareDateTime(evoraitemledger.lastUpdated);
                Console.WriteLine($"LastUpdated: {iteml.LastUpdated}");



                iteml.Location = evoraitemledger.location;
                Console.WriteLine($"Location: {iteml.Location}");


                iteml.Lot = evoraitemledger.lot;
                Console.WriteLine($"Lot: {iteml.Lot}");


                iteml.Number = evoraitemledger.number;
                Console.WriteLine($"Number: {iteml.Number}");



                iteml.PostingDate = PrepareDateTime(evoraitemledger.postingDate);
                Console.WriteLine($"PostingDate: {iteml.PostingDate}");


                iteml.Quantity = evoraitemledger.quantity;
                Console.WriteLine($"Quantity: {iteml.Quantity}");


                iteml.Reason = evoraitemledger.reason;
                Console.WriteLine($"Reason: {iteml.Reason}");


                iteml.Uom = evoraitemledger.uom;
                Console.WriteLine($"Uom: {iteml.Uom}");

                itemledger.Add(iteml);


            }
            Console.WriteLine("Itemleger count is" + itemledger.Count);
            p.SaveEvoraItemledgerToDatabase(itemledger, _connectionString);
            Console.ReadLine();





            ////  Salesdatacode

            await GetsalesData();
            List<EvoraSales> evoraSalesList = JsonConvert.DeserializeObject<List<EvoraSales>>(salesjason);
            foreach (EvoraSales evorasalesdatalist in evoraSalesList)
            {
                Sales sale = new Sales();


                sale.number = evorasalesdatalist.number;
                Console.WriteLine($"number: {sale.number}");

                sale.Status = evorasalesdatalist.status;
                Console.WriteLine($"Status: {sale.Status}");

                sale.Customer = evorasalesdatalist.customer;
                Console.WriteLine($"Customer: {sale.Customer}");

                sale.Street1 = evorasalesdatalist.street1;
                Console.WriteLine($"Street1: {sale.Street1}");

                sale.Street2 = evorasalesdatalist.street2;
                Console.WriteLine($"Street2: {sale.Street2}");

                sale.City = evorasalesdatalist.city;
                Console.WriteLine($"City: {sale.City}");

                sale.Prov = evorasalesdatalist.prov;
                Console.WriteLine($"prov: {sale.Prov}");

                sale.Postal = evorasalesdatalist.postal;
                Console.WriteLine($"Postal: {sale.Postal}");

                sale.Country = evorasalesdatalist.country;
                Console.WriteLine($"Country: {sale.Country}");

                sale.Date = evorasalesdatalist.date;
                Console.WriteLine($"Date: {sale.Date}");

                sale.Location = evorasalesdatalist.location;
                Console.WriteLine($"Location: {sale.Location}");

                sale.Amount = evorasalesdatalist.amount;
                Console.WriteLine($"Amount: {sale.Amount}");

                sale.GstRate = evorasalesdatalist.gstRate;
                Console.WriteLine($"GstRate: {sale.GstRate}");

                sale.HstRate = evorasalesdatalist.hstRate;
                Console.WriteLine($"number: {sale.HstRate}");

                sale.TaxRate = evorasalesdatalist.taxRate;
                Console.WriteLine($"TaxRate: {sale.TaxRate}");

                sale.PstRate = evorasalesdatalist.pstRate;
                Console.WriteLine($"PstRate: {sale.PstRate}");


                sale.TaxAmount = evorasalesdatalist.taxAmount;
                Console.WriteLine($"TaxAmount: {sale.TaxAmount}");

                sale.GstAmount = evorasalesdatalist.gstAmount;
                Console.WriteLine($"GstAmount: {sale.GstAmount}");

                sale.HstAmount = evorasalesdatalist.hstAmount;
                Console.WriteLine($"HstAmount: {sale.HstAmount}");

                sale.TotalAmount = evorasalesdatalist.totalAmount;
                Console.WriteLine($"TotalAmount: {sale.TotalAmount}");

                sale.Notes = evorasalesdatalist.notes;
                Console.WriteLine($"Notes: {sale.Notes}");

                sale.InvoiceNotes = evorasalesdatalist.notes;
                Console.WriteLine($"InvoiceNotes: {sale.InvoiceNotes}");

                sale.PurchaseOrder = evorasalesdatalist.purchaseOrder;
                Console.WriteLine($"purchaseOrder: {sale.PurchaseOrder}");

                sale.ExpectedDelivery = evorasalesdatalist.expectedDelivery;
                Console.WriteLine($"expectedDelivery: {sale.ExpectedDelivery}");

                sale.Type = evorasalesdatalist.type;
                Console.WriteLine($"Type: {sale.Type}");

                sale.CcxListing = evorasalesdatalist.ccxListing;
                Console.WriteLine($"CcxListing: {sale.CcxListing}");


                sale.RemittanceDate = evorasalesdatalist.remittanceDate;
                Console.WriteLine($"RemittanceDate: {sale.RemittanceDate}");

                sale.DiscountAmount = evorasalesdatalist.discountAmount;
                Console.WriteLine($"DiscountAmount: {sale.DiscountAmount}");

                sale.PreDiscount = evorasalesdatalist.preDiscount;
                Console.WriteLine($"PreDiscount: {sale.PreDiscount}");

                sale.ShippingCost = evorasalesdatalist.shippingCost;
                Console.WriteLine($"ShippingCost: {sale.ShippingCost}");


                salesList.Add(sale);

                foreach (EvoraLines line in evorasalesdatalist.Lines)
                {

                    EvoraNewLine newline = new EvoraNewLine();
                    newline.container = line.container;
                    Console.WriteLine($"container: {newline.container}");
                    newline.gst = line.gst;
                    Console.WriteLine($"GST: {newline.gst}");
                    newline.hst = line.hst;
                    Console.WriteLine($"HST: {newline.hst}");
                    newline.item = line.item;
                    Console.WriteLine($"Ittem: {newline.item}");
                    newline.lot = line.lot;
                    Console.WriteLine($"lot: {newline.lot}");
                    newline.price = line.price;
                    Console.WriteLine($"Price: {newline.price}");
                    newline.pst = line.pst;
                    Console.WriteLine($"PST: {newline.pst}");
                    newline.quantity = line.quantity;
                    Console.WriteLine($"Quantity: {newline.quantity}");
                    newline.uom = line.uom;
                    Console.WriteLine($"UOM: {newline.uom}");

                    linelist.Add(newline);


                }



                Console.WriteLine();
            }
            Console.WriteLine("Sales count is" + salesList.Count);
            p.SaveSalesdataToDatabase(salesList);
            Console.ReadLine();

            //////Get shipmentdata--------------------------------------------------------------------

            await GetshipmentData();
            List<Evorashipment> evoraShipmentList = JsonConvert.DeserializeObject<List<Evorashipment>>(shipmentjason);
            foreach (Evorashipment evorashipmentdatalist in evoraShipmentList)
            {
                //Sales sale = new Sales();
                Shipment shipment = new Shipment();


                shipment.number = evorashipmentdatalist.number;
                Console.WriteLine($"number: {shipment.number}");

                shipment.appointment = evorashipmentdatalist.appointment;
                Console.WriteLine($"appointment: {shipment.appointment}");

                shipment.asn = evorashipmentdatalist.asn;
                Console.WriteLine($"Customer: {shipment.asn}");

                shipment.city = evorashipmentdatalist.city;
                Console.WriteLine($"city: {shipment.city}");

                shipment.country = evorashipmentdatalist.country;
                Console.WriteLine($"country: {shipment.country}");

                shipment.courier = evorashipmentdatalist.courier;
                Console.WriteLine($"courier: {shipment.courier}");

                shipment.customer = evorashipmentdatalist.customer;
                Console.WriteLine($"customer: {shipment.customer}");

                shipment.date = evorashipmentdatalist.date;
                Console.WriteLine($"date: {shipment.date}");

                shipment.expectedDelivery = evorashipmentdatalist.expectedDelivery;
                Console.WriteLine($"expectedDelivery: {shipment.expectedDelivery}");

                shipment.location = evorashipmentdatalist.location;
                Console.WriteLine($"location: {shipment.location}");

                shipment.postal = evorashipmentdatalist.postal;
                Console.WriteLine($"postal: {shipment.postal}");

                shipment.prov = evorashipmentdatalist.prov;
                Console.WriteLine($"prov: {shipment.prov}");

                shipment.sale = evorashipmentdatalist.sale;
                Console.WriteLine($"sale: {shipment.sale}");

                shipment.shippingNumber = evorashipmentdatalist.shippingNumber;
                Console.WriteLine($"shippingNumber: {shipment.shippingNumber}");

                shipment.status = evorashipmentdatalist.status;
                Console.WriteLine($"status: {shipment.status}");

                shipment.street1 = evorashipmentdatalist.street1;
                Console.WriteLine($"street1: {shipment.street1}");


                shipment.street2 = evorashipmentdatalist.street2;
                Console.WriteLine($"street2: {shipment.street2}");

                shipment.vendor = evorashipmentdatalist.vendor;
                Console.WriteLine($"vendor: {shipment.vendor}");

                shipmentlist.Add(shipment);



                // Access properties of EvoraLines objects
                foreach (contents contents in evorashipmentdatalist.contents)
                {

                    //EvoraNewLine newline = new EvoraNewLine();
                    Shipmentcontents newcontents = new Shipmentcontents();
                    // newcontents.id = contents.id;
                    Console.WriteLine($"id: {newcontents.id}");
                    newcontents.number = evorashipmentdatalist.number;
                    Console.WriteLine($"number: {evorashipmentdatalist.number}");
                    newcontents.lot = contents.lot;
                    Console.WriteLine($"lot: {newcontents.lot}");
                    newcontents.item = contents.item;
                    Console.WriteLine($"Ittem: {newcontents.item}");
                    newcontents.quantity = contents.quantity;
                    Console.WriteLine($"lot: {newcontents.lot}");
                    newcontents.uom = contents.uom;
                    Console.WriteLine($"uom: {newcontents.uom}");



                    shipmentcontentlist.Add(newcontents);

                }

                p.SaveShipmentDataToDatabase(shipmentlist);



            }
            Console.ReadLine();


            ////Purchaseorderdata
            await GetPurchaseOrderData();
            List<EvoraPurchaseOrder> evoraPurchaseOrdersList = JsonConvert.DeserializeObject<List<EvoraPurchaseOrder>>(purchaseOrderJson);
            foreach (EvoraPurchaseOrder evoraPurchaseOrdersDataList in evoraPurchaseOrdersList)
            {
                PurchaseOrdersData purchaseOrdersData = new PurchaseOrdersData();

                purchaseOrdersData.number = evoraPurchaseOrdersDataList.number;
                Console.WriteLine($"number: {purchaseOrdersData.number}");

                purchaseOrdersData.status = evoraPurchaseOrdersDataList.status;
                Console.WriteLine($"status: {purchaseOrdersData.status}");

                purchaseOrdersData.location = evoraPurchaseOrdersDataList.location;
                Console.WriteLine($"type: {purchaseOrdersData.location}");

                purchaseOrdersData.date = evoraPurchaseOrdersDataList.date;
                Console.WriteLine($"date: {purchaseOrdersData.date}");

                purchaseOrdersData.vendor = evoraPurchaseOrdersDataList.vendor;
                Console.WriteLine($"vendor: {purchaseOrdersData.vendor}");

                purchaseOrdersData.amount = evoraPurchaseOrdersDataList.amount;
                Console.WriteLine($"amount: {purchaseOrdersData.amount}");

                purchaseOrdersData.gstRate = evoraPurchaseOrdersDataList.gstRate;
                Console.WriteLine($"gstRate: {purchaseOrdersData.gstRate}");


                purchaseOrdersData.pstRate = evoraPurchaseOrdersDataList.pstRate;
                Console.WriteLine($"pstRate: {purchaseOrdersData.pstRate}");

                purchaseOrdersData.hstRate = evoraPurchaseOrdersDataList.hstRate;
                Console.WriteLine($"hstRate: {purchaseOrdersData.hstRate}");

                purchaseOrdersData.taxAmount = evoraPurchaseOrdersDataList.taxAmount;
                Console.WriteLine($"taxAmount: {purchaseOrdersData.taxAmount}");

                purchaseOrdersData.totalAmount = evoraPurchaseOrdersDataList.totalAmount;
                Console.WriteLine($"totalAmount: {purchaseOrdersData.totalAmount}");

                purchaseOrdersData.expectedDelivery = evoraPurchaseOrdersDataList.expectedDelivery;
                Console.WriteLine($"expectedDelivery: {purchaseOrdersData.expectedDelivery}");


                PurchaseOrderDataList.Add(purchaseOrdersData);
                //// Access properties of EvoraLines objects


                foreach (contents content in evoraPurchaseOrdersDataList.contents)
                {
                    PurchaseOrderContent newContent = new PurchaseOrderContent();

                    newContent.number = evoraPurchaseOrdersDataList.number;
                    Console.WriteLine($"number: {newContent.number}");

                    newContent.id = content.id;
                    Console.WriteLine($"id: {newContent.id}");

                    newContent.item = content.item;
                    Console.WriteLine($"item: {newContent.item}");

                    newContent.quantity = content.quantity;
                    Console.WriteLine($"quantity: {newContent.quantity}");

                    newContent.uom = content.uom;
                    Console.WriteLine($"uom: {newContent.uom}");

                    newContent.unitCost = content.unitCost;
                    Console.WriteLine($"unitCost: {newContent.unitCost}");

                    newContent.lineCost = content.lineCost;
                    Console.WriteLine($"lineCost: {newContent.lineCost}");
                    newContent.tax = content.tax;
                    Console.WriteLine($"tax: {newContent.tax}");



                    purchContentList.Add(newContent);





                }


                foreach (received OrderReceived in evoraPurchaseOrdersDataList.received)
                {

                    PurchaseOrderReceived newReceived = new PurchaseOrderReceived();

                    newReceived.number = evoraPurchaseOrdersDataList.number;
                    Console.WriteLine($"number: {newReceived.number}");

                    newReceived.id = OrderReceived.id;
                    Console.WriteLine($"id: {newReceived.id}");

                    newReceived.item = OrderReceived.item;
                    Console.WriteLine($"item: {newReceived.item}");

                    newReceived.quantity = OrderReceived.quantity;
                    Console.WriteLine($"quantity: {newReceived.quantity}");

                    newReceived.uom = OrderReceived.uom;
                    Console.WriteLine($"uom: {newReceived.uom}");

                    newReceived.percent = OrderReceived.percent;
                    Console.WriteLine($"percent: {newReceived.percent}");



                    purchReceivedList.Add(newReceived);


                }

                Console.WriteLine();

            }
            await SavePODataToDatabase(PurchaseOrderDataList);
            Console.ReadLine();

            ////Receiptsorderdata

            await GetReceiptsOrderData();
            List<EvoraReceiptsOrder> evoraReceiptsOrdersList = JsonConvert.DeserializeObject<List<EvoraReceiptsOrder>>(receiptorderJason);
            foreach (EvoraReceiptsOrder evoraReceiptsOrdersDataList in evoraReceiptsOrdersList)
            {
                ReceiptsOrderData receiptsOrdersData = new ReceiptsOrderData();

                receiptsOrdersData.number = evoraReceiptsOrdersDataList.number;
                Console.WriteLine($"number: {receiptsOrdersData.number}");

                receiptsOrdersData.status = evoraReceiptsOrdersDataList.status;
                Console.WriteLine($"status: {receiptsOrdersData.status}");

                receiptsOrdersData.type = evoraReceiptsOrdersDataList.type;
                Console.WriteLine($"type: {receiptsOrdersData.type}");

                receiptsOrdersData.location = evoraReceiptsOrdersDataList.location;
                Console.WriteLine($"location: {receiptsOrdersData.location}");

                receiptsOrdersData.date = evoraReceiptsOrdersDataList.date;
                Console.WriteLine($"date: {receiptsOrdersData.date}");

                receiptsOrdersData.sale = evoraReceiptsOrdersDataList.sale;
                Console.WriteLine($"sale: {receiptsOrdersData.sale}");

                receiptsOrdersData.customer = evoraReceiptsOrdersDataList.customer;
                Console.WriteLine($"customer: {receiptsOrdersData.customer}");

                receiptsOrdersData.vendor = evoraReceiptsOrdersDataList.vendor;
                Console.WriteLine($"vendor: {receiptsOrdersData.vendor}");

                receiptsOrdersData.courier = evoraReceiptsOrdersDataList.courier;
                Console.WriteLine($"courier: {receiptsOrdersData.courier}");

                receiptsOrdersData.shippingNumber = evoraReceiptsOrdersDataList.shippingNumber;
                Console.WriteLine($"shippingNumber: {receiptsOrdersData.shippingNumber}");

                receiptsOrdersData.purchaseOrder = evoraReceiptsOrdersDataList.purchaseOrder;
                Console.WriteLine($"taxAmount: {receiptsOrdersData.purchaseOrder}");

                ReceiptsOrderDataList.Add(receiptsOrdersData);
                // Access properties of EvoraLines objects


                foreach (contents content in evoraReceiptsOrdersDataList.contents)
                {

                    ReceiptsOrderContent newContent = new ReceiptsOrderContent();

                    newContent.number = evoraReceiptsOrdersDataList.number;
                    Console.WriteLine($"number: {newContent.number}");

                    newContent.id = content.id;
                    Console.WriteLine($"id: {newContent.id}");

                    newContent.item = content.item;
                    Console.WriteLine($"item: {newContent.item}");

                    newContent.quantity = content.quantity;
                    Console.WriteLine($"quantity: {newContent.quantity}");

                    newContent.uom = content.uom;
                    Console.WriteLine($"uom: {newContent.uom}");

                    newContent.count = content.Count;
                    Console.WriteLine($"count: {newContent.count}");

                    newContent.container = content.container;
                    Console.WriteLine($"container: {newContent.container}");

                    newContent.lot = content.lot;
                    Console.WriteLine($"lot: {newContent.lot}");

                    newContent.bin = content.Bin;
                    Console.WriteLine($"bin: {newContent.bin}");

                    newContent.vendorLot = content.VendorLot;
                    Console.WriteLine($"vendorLot: {newContent.vendorLot}");

                    newContent.totalUOM = content.TotalUOM;
                    Console.WriteLine($"TotalUOM: {newContent.totalUOM}");

                    newContent.expectedquantity = content.expectedquantity;
                    Console.WriteLine($"expectedquantity: {newContent.expectedquantity}");


                    receiptsContentList.Add(newContent);


                }

            }
            await SaveRODataToDatabase(ReceiptsOrderDataList);
            Console.WriteLine("Press any key to continue");
            Console.Read();



            await GetProductionBatchData();
            List<EvoraProductionBatches> evoraProductionBatchList = JsonConvert.DeserializeObject<List<EvoraProductionBatches>>(productionbatchesJason);
            foreach (EvoraProductionBatches evoraProductionBatchDataList in evoraProductionBatchList)
            {
                ProductionBatches productionbatch = new ProductionBatches();

                productionbatch.number = evoraProductionBatchDataList.number;
                Console.WriteLine($"number: {productionbatch.number}");

                productionbatch.description = evoraProductionBatchDataList.description;
                Console.WriteLine($"description: {productionbatch.description}");

                productionbatch.location = evoraProductionBatchDataList.location;
                Console.WriteLine($"type: {productionbatch.location}");

                productionbatch.status = evoraProductionBatchDataList.status;
                Console.WriteLine($"status: {productionbatch.status}");

                productionbatch.plannedStart = evoraProductionBatchDataList.plannedStart;
                Console.WriteLine($"plannedStart: {productionbatch.plannedStart}");

                productionbatch.actualStart = evoraProductionBatchDataList.actualStart;
                Console.WriteLine($"productionbatch: {productionbatch.actualStart}");

                productionbatch.startItem = evoraProductionBatchDataList.startItem;
                Console.WriteLine($"startItem: {productionbatch.startItem}");

                productionbatch.outputItem = evoraProductionBatchDataList.outputItem;
                Console.WriteLine($"outputItem: {productionbatch.outputItem}");

                productionbatch.uom = evoraProductionBatchDataList.uom;
                Console.WriteLine($"uom: {productionbatch.uom}");

                productionbatch.outputQuantity = evoraProductionBatchDataList.outputQuantity;
                Console.WriteLine($"outputQuantity: {productionbatch.outputQuantity}");

                productionbatch.dueDate = evoraProductionBatchDataList.dueDate;
                Console.WriteLine($"dueDate: {productionbatch.dueDate}");

                productionbatch.packagedOn = evoraProductionBatchDataList.packagedOn;
                Console.WriteLine($"packagedOn: {productionbatch.packagedOn}");

                productionbatchdataList.Add(productionbatch);


                foreach (activities activity in evoraProductionBatchDataList.activities)
                {
                    productionorderactivities newactivity = new productionorderactivities();
                    newactivity.id = activity.id;
                    Console.WriteLine($"id: {newactivity.id}");
                    newactivity.roomCleaning = activity.roomCleaning;
                    Console.WriteLine($"roomCleaning: {newactivity.roomCleaning}");
                    newactivity.roomToClean = activity.roomToClean;
                    Console.WriteLine($"roomToClean: {newactivity.roomToClean}");
                    newactivity.productionOrder = activity.productionOrder;
                    Console.WriteLine($"productionOrder: {newactivity.productionOrder}");
                    newactivity.routing = activity.routing;
                    Console.WriteLine($"routing: {newactivity.routing}");
                    newactivity.bom = activity.bom;
                    Console.WriteLine($"bom: {newactivity.bom}");
                    newactivity.outputItem = activity.outputItem;
                    Console.WriteLine($"outputItem: {newactivity.outputItem}");
                    newactivity.outputUOM = activity.outputUOM;
                    Console.WriteLine($"outputUOM: {newactivity.outputUOM}");
                    newactivity.outputQuantity = activity.outputQuantity;
                    Console.WriteLine($"outputQuantity: {newactivity.outputQuantity}");
                    productionorderactivitiesList.Add(newactivity);

                }

                foreach (outputs output in evoraProductionBatchDataList.outputs)
                {
                    productionorderoutput newoutput = new productionorderoutput();
                    newoutput.item = output.item;
                    Console.WriteLine($"item: {newoutput.item}");
                    newoutput.amount = output.amount;
                    Console.WriteLine($"amount: {newoutput.amount}");
                    newoutput.uom = output.uom;
                    Console.WriteLine($"uom: {newoutput.uom}");
                    newoutput.lot = output.lot;
                    Console.WriteLine($"lot: {newoutput.lot}");
                    newoutput.status = output.status;
                    Console.WriteLine($"status: {newoutput.status}");
                    productionorderoutputsList.Add(newoutput);
                }

                foreach (inputs input in evoraProductionBatchDataList.inputs)
                {
                    productionorderinputs newinput = new productionorderinputs();
                    newinput.item = input.item;
                    Console.WriteLine($"item: {input.item}");
                    newinput.amount = input.amount;
                    Console.WriteLine($"amount: {input.amount}");
                    newinput.uom = input.uom;
                    Console.WriteLine($"uom: {input.uom}");
                    newinput.lot = input.lot;
                    Console.WriteLine($"lot: {input.lot}");
                    newinput.cost = input.cost;
                    Console.WriteLine($"cost: {input.cost}");
                    productioninputsList.Add(newinput);
                }


            }
            await SavePBDataToDatabase(productionbatchdataList);
            Console.WriteLine("Press any key to continue");
            Console.Read();
            ////---------------------------------------------------------------------------------------------------------Production-Orderstart---------------------------------
            
            await GetProductionOrderData();
            List<ProductionOrder> productionOrdersList = JsonConvert.DeserializeObject<List<ProductionOrder>>(productionorderJason);
            foreach (ProductionOrder evoraProductionOrderList in productionOrdersList)
            {
                ProductionOrder ProdOrdersData = new ProductionOrder();


                ProdOrdersData.number = evoraProductionOrderList.number;
                Console.WriteLine($"number: {ProdOrdersData.number}");

                ProdOrdersData.description = evoraProductionOrderList.description;
                Console.WriteLine($"description: {ProdOrdersData.description}");

                ProdOrdersData.productionBatch = evoraProductionOrderList.productionBatch;
                Console.WriteLine($"productionBatch: {ProdOrdersData.productionBatch}");

                ProdOrdersData.quantity = evoraProductionOrderList.quantity;
                Console.WriteLine($"quantity: {ProdOrdersData.quantity}");

                ProdOrdersData.quantityUOM = evoraProductionOrderList.quantityUOM;
                Console.WriteLine($"productionBatch: {ProdOrdersData.quantityUOM}");

                ProdOrdersData.plannedQuantity = evoraProductionOrderList.plannedQuantity;
                Console.WriteLine($"plannedQuantity: {ProdOrdersData.plannedQuantity}");

                ProdOrdersData.startDate = evoraProductionOrderList.startDate;
                Console.WriteLine($"startDate: {ProdOrdersData.startDate}");

                ProdOrdersData.plannedStart = evoraProductionOrderList.plannedStart;
                Console.WriteLine($"plannedStart: {ProdOrdersData.plannedStart}");

                ProdOrdersData.endDate = evoraProductionOrderList.endDate;
                Console.WriteLine($"endDate: {ProdOrdersData.endDate}");

                ProdOrdersData.dueDate = evoraProductionOrderList.dueDate;
                Console.WriteLine($"dueDate: {ProdOrdersData.dueDate}");

                ProdOrdersData.status = evoraProductionOrderList.status;
                Console.WriteLine($"status: {ProdOrdersData.status}");

                ProdOrdersData.location = evoraProductionOrderList.location;
                Console.WriteLine($"location: {ProdOrdersData.location}");

                ProdOrdersData.routing = evoraProductionOrderList.routing;
                Console.WriteLine($"routing: {ProdOrdersData.routing}");

                ProdOrdersData.productionBom = evoraProductionOrderList.productionBom;
                Console.WriteLine($"productionBom: {ProdOrdersData.productionBom}");

                ProdOrdersData.custom = evoraProductionOrderList.custom;
                Console.WriteLine($"custom: {ProdOrdersData.custom}");

                ProdOrdersData.inpurtCost = evoraProductionOrderList.inpurtCost;
                Console.WriteLine($"inpurtCost: {ProdOrdersData.inpurtCost}");

                ProdOrdersData.labourCost = evoraProductionOrderList.labourCost;
                Console.WriteLine($"labourCost: {ProdOrdersData.labourCost}");

                ProdOrdersData.notes = evoraProductionOrderList.notes;
                Console.WriteLine($"notes: {ProdOrdersData.notes}");

                ProdOrdersData.processingLoss = evoraProductionOrderList.processingLoss;
                Console.WriteLine($"processingLoss: {ProdOrdersData.processingLoss}");

                ProdOrdersData.processingLossPercent = evoraProductionOrderList.processingLossPercent;
                Console.WriteLine($"processingLossPercent: {ProdOrdersData.processingLossPercent}");

                ProdOrdersData.inputCannabisTotal = evoraProductionOrderList.inputCannabisTotal;
                Console.WriteLine($"inputCannabisTotal: {ProdOrdersData.inputCannabisTotal}");

                ProdOrdersData.outputCannabisTotal = evoraProductionOrderList.outputCannabisTotal;
                Console.WriteLine($"outputCannabisTotal: {ProdOrdersData.outputCannabisTotal}");


                POrder.Add(ProdOrdersData);

                foreach (Input input in evoraProductionOrderList.inputs)
                {
                    PInput newPInput = new PInput();

                    newPInput.number = evoraProductionOrderList.number;
                    Console.WriteLine($"number: {newPInput.number}");

                    newPInput.item = input.item;
                    Console.WriteLine($"item: {newPInput.item}");

                    newPInput.amount = input.amount;
                    Console.WriteLine($"amount: {newPInput.amount}");

                    newPInput.uom = input.uom;
                    Console.WriteLine($"uom: {newPInput.uom}");

                    newPInput.count = input.count;
                    Console.WriteLine($"count: {newPInput.count}");

                    newPInput.lot = input.lot;
                    Console.WriteLine($"lot: {newPInput.lot}");

                    newPInput.container = input.container;
                    Console.WriteLine($"container: {newPInput.container}");

                    newPInput.bin = input.bin;
                    Console.WriteLine($"outputCannabisTotal: {newPInput.bin}");

                    pInputList.Add(newPInput);
                }

                foreach (Output output in evoraProductionOrderList.outputs)
                {
                    POutput newPOutput = new POutput();

                    newPOutput.number = evoraProductionOrderList.number;
                    Console.WriteLine($"number: {newPOutput.number}");

                    newPOutput.id = output.id;
                    Console.WriteLine($"id: {newPOutput.id}");

                    newPOutput.item = output.item;
                    Console.WriteLine($"item: {newPOutput.item}");

                    newPOutput.amount = output.amount;
                    Console.WriteLine($"amount: {newPOutput.amount}");

                    newPOutput.uom = output.uom;
                    Console.WriteLine($"uom: {newPOutput.uom}");

                    newPOutput.lot = output.lot;
                    Console.WriteLine($"lot: {newPOutput.lot}");

                    newPOutput.container = output.container;
                    Console.WriteLine($"container: {newPOutput.container}");

                    newPOutput.bin = output.bin;
                    Console.WriteLine($"bin: {newPOutput.bin}");

                    newPOutput.discreteWeightUOM = output.discreteWeightUOM;
                    Console.WriteLine($"discreteWeightUOM: {newPOutput.discreteWeightUOM}");

                    newPOutput.containerType = output.containerType;
                    Console.WriteLine($"containerType: {newPOutput.containerType}");

                    pOutputList.Add(newPOutput);


                }

            }
            await SaveProductionOrderDataToDatabase(POrder);
            writter.LogInfoWriter("--------------------------------------------------------------------------Application End--------------------------------------------------------------------------");
            Console.WriteLine("Press any key to continue");
            Console.Read();

        }

        private static DateTime PrepareDateTime(DateTime? lastUpdated)
        {
            if (lastUpdated == null)
            {
                // Handle the case where lastUpdated is null
                throw new ArgumentNullException(nameof(lastUpdated), "lastUpdated cannot be null");
            }

            // If lastUpdated is not null, subtract 8 hours from it
            DateTime preparedDate = lastUpdated.Value.AddHours(-8);
            return preparedDate;
        }

        public static async void Prepairetoken()
        {
            try
            {



                string apiUrl = "https://ogkush.evoratechnologies.com/users/extlogin";
                publicToken = await gettoken.GetEvoraAccessToken(apiUrl, "x982eudkl@tricanna.com", "RrcT&1v5Jy");
                writter.LogInfoWriter("------------------" + "Authoraiation successful....!" + "--------------------------------------------------------------------------");
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Authoraiation unsuccessful....!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }
        }

        public static async Task GetcustomerData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/customers";
                customerJason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Customer record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }

        public async Task SaveCustomersToDatabase(List<Customer> customers,string _connectionString)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        foreach (var customer in customers)
                        {
                            await SaveOrUpdateCustomerAsync(connection, transaction, customer);
                        }

                        transaction.Commit();
                        Console.WriteLine("Customers saved to the database successfully.");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Error saving customers to the database: {ex.Message}");
                    }
                }
            }
        }

        private async Task SaveOrUpdateCustomerAsync(SqlConnection connection, SqlTransaction transaction, Customer customer)
        {
            using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM Customer WHERE Evoranumber = @Evoranumber) " +
                                                      "BEGIN " +
                                                      "   UPDATE Customer SET BillAddr1 = @BillAddr1, BillAddr2 = @BillAddr2, " +
                                                      "    BillCity = @BillCity, BillCountry = @BillCountry, " +
                                                      "    BillPostalCode = @BillPostalCode, BillState = @BillState, " +
                                                      "   CustomerName = @CustomerName,  " +
                                                      "   Evoranumber = @Evoranumber WHERE Evoranumber = @Evoranumber " +
                                                      "END " +
                                                      "ELSE " +
                                                      "BEGIN " +
                                                      "   INSERT INTO Customer (BillAddr1, BillAddr2, BillCity, BillCountry, " +
                                                      "    BillPostalCode, BillState,  " +
                                                      "   CustomerName, " +
                                                      "    Evoranumber) " +
                                                      "   VALUES (@BillAddr1, @BillAddr2, @BillCity, @BillCountry, " +
                                                      "   @BillPostalCode, @BillState, @CustomerName, " +
                                                      "   @Evoranumber); " +
                                                      "END", connection, transaction))
            {
                command.Parameters.AddWithValue("@BillAddr1", customer.BillAddr1 ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@BillAddr2", customer.BillAddr2 ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@BillCity", customer.Billcity ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@BillCountry", customer.Billcountry ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@BillPostalCode", customer.Billpostalcode ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@BillState", customer.Billstate ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@CustomerName", customer.CustomerName ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Evoranumber", customer.EvoraNumber);
                                                                

                await command.ExecuteNonQueryAsync();
            }
        }
///-----------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task GetvendorData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/vendors";
                vendorJason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Customer record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public async Task SaveVendorsToDatabase(List<Vendor> vendors, List<address> addresses, string _connectionString)
        {
            if (vendors == null || addresses == null || vendors.Count != addresses.Count)
            {
                Console.WriteLine("Invalid input: Vendors and addresses must not be null, and their counts must match.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        for (int i = 0; i < vendors.Count; i++)
                        {
                            var vendor = vendors[i];
                            var address = addresses[i];
                            await SaveOrUpdateVendorsAsync(connection, transaction, vendor, address);
                        }

                        transaction.Commit();
                        Console.WriteLine("Vendors saved to the database successfully.");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Error saving vendors to the database: {ex.Message}");
                    }
                }
            }
        }
        private async Task SaveOrUpdateVendorsAsync(SqlConnection connection, SqlTransaction transaction, Vendor vendor, address address)
        {
            using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM Vendor WHERE Number = @number) " +
                                                      "BEGIN " +
                                                      "   UPDATE Vendor SET Name = @Name, CompanyName = @CompanyName,Phone=@phonenumber, " +
                                                      "    Term = @term, LicenseType = @licenseType, " +
                                                      "   Type = @type, Street1=@Street1,Street2=@Street2,City=@City,Postal=@Postal,Country=@Country " +
                                                      "   WHERE Number = @number " +
                                                      "END " +
                                                      "ELSE " +
                                                      "BEGIN " +
                                                      " INSERT INTO [dbo].[Vendor] " +
                                                      " (Number,Name,CompanyName,Phone,Term,LicenseType,Type,Street1,Street2,City,Postal,Country)" +
                                                      " VALUES " +
                                                      " (@number,@Name,@CompanyName,@phonenumber,@term,@licenseType,@type,@Street1,@Street2,@City,@Postal,@Country) " +
                                                      "END", connection, transaction))
            {
                command.Parameters.AddWithValue("@number", vendor.number ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@name", vendor.name ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@CompanyName", vendor.companyname ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@phonenumber", vendor.phonenumber ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@licenseType", vendor.licenseType ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@term", vendor.terms ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@type", vendor.type ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@street1", address.street1 ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@street2", address.street2 ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@city", address.city ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@prov", address.prov ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@postal", address.postal ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@country", address.country ?? (object)DBNull.Value);

                await command.ExecuteNonQueryAsync();
            }
        }

        public static async Task GetitemData()
        {
            try
            {
                string apiUrl = "https://ogkush.evoratechnologies.com/ext/items";
                itemJason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Item record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public async Task SaveItemsToDatabase(List<Item> itemList,string _connectionString)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (SqlTransaction transaction = connection.BeginTransaction())
                {
                    try
                    {
                        foreach (var items in itemList)
                        {
                            await SaveOrUpdateEvoraitemsAsync(connection, transaction, items);
                        }

                        transaction.Commit();
                        Console.WriteLine("Items saved to the database successfully.");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Console.WriteLine($"Error saving items to the database: {ex.Message}");
                    }
                }
            }
        }
        private async Task SaveOrUpdateEvoraitemsAsync(SqlConnection connection, SqlTransaction transaction, Item evoraitems)
        {
            using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM Item WHERE number = @EvoraItemNumber) " +
                                                      "BEGIN " +
                                                      "   UPDATE Item SET AverageWeight = @AverageWeight, CaseQuantity = @CaseQuantity, " +
                                                      "    CbdMg = @CbdMg, Cost = @Cost,category = @Category, categoryName=@CategoryName , " +
                                                      "    Description2 = @Description2, EachQuantity = @EachQuantity, " +
                                                      "   EvoraItemName = @EvoraItemName, ExpectedUnitCost = @ExpectedUnitCost, " +
                                                      "   ExpirationMonths = @ExpirationMonths, FullCost = @FullCost, " +
                                                      "   Inventory = @Inventory, ItemCount = @ItemCount, " +
                                                      "   MinimumQuantity = @MinimumQuantity, Gtin = @Gtin, " +
                                                      "   NewLotStatus = @NewLotStatus, PackCount = @PackCount, " +
                                                      "   PackSizeG = @PackSizeG, Price = @Price ," +
                                                      "   RegistrationNumer = @RegistrationNumer, vendorID = @vendorID, " +
                                                      "   ProductNumber = @ProductNumber, PurchaseUOM = @PurchaseUOM ," +
                                                      "   ReorderLeadTime = @ReorderLeadTime, Sku = @Sku, " +
                                                      "   SkuOwner = @SkuOwner, Strain = @Strain, " +
                                                      "   ThcMg = @ThcMg, TotalUnitWeightG = @TotalUnitWeightG ," +
                                                      "   Tracking = @Tracking,Uom = @Uom " +
                                                      "   WHERE number = @EvoraItemNumber " +
                                                      "END " +
                                                      "ELSE " +
                                                      "BEGIN " +
                                                             //"   INSERT INTO Item (number,AverageWeight, CaseQuantity, CbdMg, Cost, " +
                                                             //"    Description2, EachQuantity,EvoraItemName,ExpectedUnitCost,ExpirationMonths,FullCost ," +
                                                             //"   Inventory,ItemCount,MinimumQuantity,Gtin,NewLotStatus,PackCount,PackSizeG,Price,ProductNumber,PurchaseUOM , " +
                                                             //"    RegistrationNumer,ReorderLeadTime,Sku,SkuOwner,Strain,ThcMg,TotalUnitWeightG,Tracking,Uom,vendorID) " +
                                                             //"   VALUES (@EvoraItemNumber,@AverageWeight, @CaseQuantity, @CbdMg, @Cost,@Description2,@EachQuantity,@EvoraItemName,@ExpectedUnitCost,@ExpirationMonths,@FullCost," +
                                                             //"   @Inventory, @ItemCount, @MinimumQuantity,@Gtin,@NewLotStatus,@PackCount,@PackSizeG,@Price,@ProductNumber,@PurchaseUOM,@RegistrationNumer,@ReorderLeadTime, " +
                                                             //"   @Sku,@SkuOwner,@Strain,@ThcMg,@TotalUnitWeightG,@Tracking,@Uom,@vendorID); " +
                                                             "INSERT INTO[dbo].[Item] ([number],[EvoraItemName],[category],[categoryName],[Uom],[PurchaseUOM] " +
                                                             ",[EachQuantity],[Strain],[Inventory],[Price],[ItemCount]" +
                                                             ",[AverageWeight],[Cost],[Tracking],[ReorderLeadTime],[ThcMg]" +
                                                             ",[CbdMg],[PackSizeG],[PackCount],[ExpirationMonths],[NewLotStatus]" +
                                                             ",[ExpectedUnitCost],[RegistrationNumer],[Sku],[Gtin],[CaseQuantity]" +
                                                             ",[MinimumQuantity],[ProductNumber],[Description2],[FullCost],[TotalUnitWeightG]" +
                                                             ",[SkuOwner],[vendorID])" +
                                                             "VALUES" +
                                                             "(@EvoraItemNumber, @EvoraItemName,@Category,@CategoryName, @Uom, @PurchaseUOM" +
                                                             ", @EachQuantity, @Strain, @Inventory, @Price, @ItemCount" +
                                                             ", @AverageWeight, @Cost, @Tracking, @ReorderLeadTime, @ThcMg" +
                                                             ", @CbdMg, @PackSizeG, @PackCount, @ExpirationMonths, @NewLotStatus" +
                                                             ", @ExpectedUnitCost, @RegistrationNumer, @Sku, @Gtin, @CaseQuantity" +
                                                             ", @MinimumQuantity, @ProductNumber, @Description2, @FullCost, @TotalUnitWeightG" +
                                                             ", @SkuOwner, @vendorID);" +
                                                      "END", connection, transaction))
            {
                command.Parameters.AddWithValue("@EvoraItemNumber", evoraitems.EvoraItemNumber ?? (object)DBNull.Value);
                //command.Parameters.AddWithValue("@AverageWeight", evoraitems.AverageWeight?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@CaseQuantity", evoraitems.CaseQuantity ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@CbdMg", evoraitems.CbdMg ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@Cost", evoraitems.Cost ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Description2", evoraitems.Description2 ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Category", evoraitems.category ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@CategoryName", evoraitems.categoryName ?? (object)DBNull.Value);

                // command.Parameters.AddWithValue("@EachQuantity", evoraitems.EachQuantity ?? (object)DBNull.Value);
                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.EachQuantity, out decimal eachQuantityDecimal))
                {
                    command.Parameters.AddWithValue("@EachQuantity", eachQuantityDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@EachQuantity", DBNull.Value); // or handle the invalid case accordingly
                }


                //-------------------------------------------------------------------------------------------------------------
                command.Parameters.AddWithValue("@EvoraItemName", evoraitems.EvoraItemName ?? (object)DBNull.Value);
                //command.Parameters.AddWithValue("@ExpectedUnitCost", evoraitems.ExpectedUnitCost ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@ExpirationMonths", evoraitems.ExpirationMonths ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@FullCost", evoraitems.FullCost ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@Inventory", evoraitems.Inventory ?? (object)DBNull.Value);


                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.Inventory, out decimal InventoryDecimal))
                {
                    command.Parameters.AddWithValue("@Inventory", InventoryDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@Inventory", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.TotalUnitWeightG, out decimal TotalUnitWeightGDecimal))
                {
                    command.Parameters.AddWithValue("@TotalUnitWeightG", TotalUnitWeightGDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@TotalUnitWeightG", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------




                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.FullCost, out decimal FullCostDecimal))
                {
                    command.Parameters.AddWithValue("@FullCost", FullCostDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@FullCost", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------


                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.ItemCount, out decimal ItemCountDecimal))
                {
                    command.Parameters.AddWithValue("@ItemCount", ItemCountDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@ItemCount", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.ReorderLeadTime, out decimal ReorderLeadTimeDecimal))
                {
                    command.Parameters.AddWithValue("@ReorderLeadTime", ReorderLeadTimeDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@ReorderLeadTime", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.ThcMg, out decimal ThcMgDecimal))
                {
                    command.Parameters.AddWithValue("@ThcMg", ThcMgDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@ThcMg", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------
                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.CbdMg, out decimal CbdMgDecimal))
                {
                    command.Parameters.AddWithValue("@CbdMg", CbdMgDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@CbdMg", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.PackSizeG, out decimal PackSizeGDecimal))
                {
                    command.Parameters.AddWithValue("@PackSizeG", PackSizeGDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@PackSizeG", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.PackCount, out decimal PackCountDecimal))
                {
                    command.Parameters.AddWithValue("@PackCount", PackCountDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@PackCount", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------




                // command.Parameters.AddWithValue("@MinimumQuantity", evoraitems.MinimumQuantity ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Gtin", evoraitems.Gtin ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@NewLotStatus", evoraitems.NewLotStatus ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@PackCount", evoraitems.PackCount ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@PackSizeG", evoraitems.PackSizeG ?? (object)DBNull.Value);
                //command.Parameters.AddWithValue("@Price", evoraitems.Price ?? (object)DBNull.Value);


                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.Price, out decimal PriceDecimal))
                {
                    command.Parameters.AddWithValue("@Price", PriceDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@Price", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.AverageWeight, out decimal AverageWeightDecimal))
                {
                    command.Parameters.AddWithValue("@AverageWeight", AverageWeightDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@AverageWeight", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.Cost, out decimal CostDecimal))
                {
                    command.Parameters.AddWithValue("@Cost", CostDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@Cost", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------


                //-------------------------------------------------------------------------------------------------------------
                if (decimal.TryParse(evoraitems.ExpectedUnitCost, out decimal ExpectedUnitCostDecimal))
                {
                    command.Parameters.AddWithValue("@ExpectedUnitCost", ExpectedUnitCostDecimal);
                }
                else
                {
                    command.Parameters.AddWithValue("@ExpectedUnitCost", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (int.TryParse(evoraitems.CaseQuantity, out int CaseQuantityInt))
                {
                    command.Parameters.AddWithValue("@CaseQuantity", CaseQuantityInt);
                }
                else
                {
                    command.Parameters.AddWithValue("@CaseQuantity", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------

                //-------------------------------------------------------------------------------------------------------------
                if (int.TryParse(evoraitems.MinimumQuantity, out int MinimumQuantityInt))
                {
                    command.Parameters.AddWithValue("@MinimumQuantity", MinimumQuantityInt);
                }
                else
                {
                    command.Parameters.AddWithValue("@MinimumQuantity", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------


                //-------------------------------------------------------------------------------------------------------------
                if (int.TryParse(evoraitems.ExpirationMonths, out int ExpirationMonthsInt))
                {
                    command.Parameters.AddWithValue("@ExpirationMonths", ExpirationMonthsInt);
                }
                else
                {
                    command.Parameters.AddWithValue("@ExpirationMonths", DBNull.Value); // or handle the invalid case accordingly
                }

                //-------------------------------------------------------------------------------------------------------------





                command.Parameters.AddWithValue("@ProductNumber", evoraitems.ProductNumber ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@PurchaseUOM", evoraitems.PurchaseUOM ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@RegistrationNumer", evoraitems.RegistrationNumer ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@ReorderLeadTime", evoraitems.ReorderLeadTime ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Sku", evoraitems.Sku ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@SkuOwner", evoraitems.SkuOwner ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Strain", evoraitems.Strain ?? (object)DBNull.Value);
                //  command.Parameters.AddWithValue("@ThcMg", evoraitems.ThcMg ?? (object)DBNull.Value);
                // command.Parameters.AddWithValue("@TotalUnitWeightG", evoraitems.TotalUnitWeightG ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Tracking", evoraitems.Tracking ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Uom", evoraitems.Uom ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@vendorID", evoraitems.VendorID ?? (object)DBNull.Value);


                await command.ExecuteNonQueryAsync();
            }
        }
///--------------------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task GetEvoraItemledgerData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/itemledgers?start=2023-05-08";
                itemledgerjason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Itemledger record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public async Task SaveEvoraItemledgerToDatabase(List<Itemledger> itemledger,string _connectionString)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                try
                {

                    await SaveOrUpdateEvoraItemledgerAsync(connection);

                    Console.WriteLine("Itemledger data saved to the database successfully.");
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"Error saving Itemledger data to the database: {ex.Message}");
                }

               
            }
        }

        public async Task SaveOrUpdateEvoraItemledgerAsync(SqlConnection connection)
        {
            try
            {
                List<EvoraItemledger> evoraitemledgerList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<EvoraItemledger>>(itemledgerjason);
                Console.WriteLine("Count is " + evoraitemledgerList.Count);

                foreach (EvoraItemledger eitemledger in evoraitemledgerList)
                {
                    using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM EvoraItemLedgerEntries WHERE Number = @Number) " +
                                                      "BEGIN " +
                                                      "   UPDATE EvoraItemLedgerEntries SET Number = @Number, EntryType = @EntryType, " +
                                                      "    Item = @Item, Description = @Description, " +
                                                      "    Lot = @Lot, BaseLot = @BaseLot, " +
                                                      "   Location = @Location,Quantity = @Quantity,Activity = @Activity,Reason = @Reason ," +
                                                      "   Bin = @Bin,PostingDate = @PostingDate,LastUpdated = @LastUpdated,Expires = @Expires " +
                                                      "   WHERE Number = @Number " +
                                                      "END " +
                                                      "ELSE " +
                                                      "BEGIN " +
                                                      "   INSERT INTO EvoraItemLedgerEntries ( ID,Number, EntryType,Item, Description,Lot,BaseLot,Location,Quantity ,Uom," +
                                                      "    Activity, Reason,Bin,PostingDate,LastUpdated,Expires) " +
                                                      "   VALUES (@ID,@Number, @EntryType,@Item, @Description, " +
                                                      "   @Lot, @BaseLot, @Location,@Quantity,@Uom,@Activity,@Reason,@Bin,@PostingDate,@LastUpdated,@Expires); " +
                                                      "    " +
                                                      "END", connection))
                    {

                        command.Parameters.AddWithValue("@Expires", eitemledger.expires ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@LastUpdated",  (object)PrepareDateTime(eitemledger.lastUpdated) ?? DBNull.Value);
                        command.Parameters.AddWithValue("@PostingDate", (object)PrepareDateTime(eitemledger.postingDate) ?? DBNull.Value);
                        command.Parameters.AddWithValue("@Bin", eitemledger.bin ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Reason", eitemledger.reason ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Activity", eitemledger.activity ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Uom", eitemledger.uom ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Quantity", (object)eitemledger.quantity ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Location", eitemledger.location ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@BaseLot", eitemledger.baseLot ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Lot", eitemledger.lot ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Description", eitemledger.description ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Item", eitemledger.item ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@EntryType", eitemledger.entryType?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Number", eitemledger.number ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@ID", eitemledger.id?? (object)DBNull.Value);



                        await command.ExecuteNonQueryAsync();
                    }
                    
                    
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
///----------------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task GetsalesData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/sales?start=2023-05-08";
                salesjason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Customer record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public async Task SaveSalesdataToDatabase(List<Sales> sale)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlConnection connection2 = new SqlConnection(_connectionString);
                SqlConnection connection3 = new SqlConnection(_connectionString);

                await connection.OpenAsync();
                await connection2.OpenAsync();
                await connection3.OpenAsync();


                try
                {
                    
                    await SaveOrUpdateSalesdataAsync(connection, connection2, connection3);

                    Console.WriteLine("Sales data saved to the database successfully.");
                }
                catch (Exception ex)
                {
                    
                    Console.WriteLine($"Error saving sales data to the database: {ex.Message}");
                }


            }


        }
        public async Task SaveOrUpdateSalesdataAsync(SqlConnection connection, SqlConnection connection2, SqlConnection connection3)
        {
            try
            {
                List<EvoraSales> evoraSalesList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<EvoraSales>>(salesjason);
                Console.WriteLine("Count is " + evoraSalesList.Count);

                foreach (EvoraSales evoraSales in evoraSalesList)
                {
                    using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM EvoraSales WHERE number = @Number) " +
                                                          "BEGIN " +
                                                          "   UPDATE EvoraSales SET number=@number,status=@Status,customer=@Customer,street1=@Street1,street2=@Street2, " +
                                                                  "city=@City,prov=@Prov,postal=@Postal,country=@Country,date=@Date, " +
                                                                  "location=@Location,amount=@Amount,gstRate=@GstRate,hstRate=@HstRate,taxRate=@TaxRate, " +
                                                                  "pstRate=@PstRate,taxAmount=@TaxAmount,gstAmount=@GstAmount,hstAmount=@HstAmount,totalAmount=@TotalAmount, " +
                                                                  "notes=@Notes,invoiceNotes=@InvoiceNotes,purchaseOrder=@PurchaseOrder,expectedDelivery=@ExpectedDelivery,type=@Type, " +
                                                                  "ccxListing=@CcxListing,remittanceDate=@RemittanceDate,discountAmount=@DiscountAmount,preDiscount=@PreDiscount,shippingCost=@ShippingCost " +
                                                          "   WHERE number = @Number " +
                                                          "END " +
                                                          "ELSE " +
                                                          "BEGIN " +
                                                                  " INSERT INTO[dbo].[EvoraSales] " +
                                                                  "([number],[status],[customer],[street1],[street2], " +
                                                                  "[city],[prov],[postal],[country],[date], " +
                                                                  "[location],[amount],[gstRate],[hstRate],[taxRate], " +
                                                                  "[pstRate],[taxAmount],[gstAmount],[hstAmount],[totalAmount], " +
                                                                  "[notes],[invoiceNotes],[purchaseOrder],[expectedDelivery],[type], " +
                                                                  "[ccxListing],[remittanceDate],[discountAmount],[preDiscount],[shippingCost]) " +
                                                                  " VALUES " +
                                                                  "(@number, @Status, @Customer, @Street1, @Street2," +
                                                                  "@City, @Prov, @Postal, @Country, @Date, @Location," +
                                                                  "@Amount, @GstRate, @HstRate, @TaxRate, @PstRate, " +
                                                                  "@TaxAmount, @GstAmount, @HstAmount, @TotalAmount, @Notes," +
                                                                  "@InvoiceNotes, @PurchaseOrder, @ExpectedDelivery, @Type, @CcxListing," +
                                                                  " @RemittanceDate, @DiscountAmount, @PreDiscount, @ShippingCost)" +
                                                          "END", connection))
                    {
                        command.Parameters.AddWithValue("@number", evoraSales.number ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Status", evoraSales.status ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Customer", evoraSales.customer ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Street1", evoraSales.street1 ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Street2", evoraSales.street2 ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@City", evoraSales.city ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Prov", evoraSales.prov ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Postal", evoraSales.postal ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Country", evoraSales.country ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Date", evoraSales.date != null ? (object)PrepareDateTime(evoraSales.date) : DBNull.Value);
                        command.Parameters.AddWithValue("@Location", evoraSales.location ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Amount", evoraSales.amount != null ? (object)evoraSales.amount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@GstRate", evoraSales.gstRate != null ? (object)evoraSales.gstRate : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@HstRate", evoraSales.hstRate != null ? (object)evoraSales.hstRate : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@TaxRate", evoraSales.taxRate != null ? (object)evoraSales.taxRate : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@PstRate", evoraSales.pstRate != null ? (object)evoraSales.pstRate : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@TaxAmount", evoraSales.taxAmount != null ? (object)evoraSales.taxAmount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@GstAmount", evoraSales.gstAmount != null ? (object)evoraSales.gstAmount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@HstAmount", evoraSales.hstAmount != null ? (object)evoraSales.hstAmount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@TotalAmount", evoraSales.totalAmount != null ? (object)evoraSales.totalAmount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Notes", evoraSales.notes != null ? (object)evoraSales.notes : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@InvoiceNotes", evoraSales.invoiceNotes != null ? (object)evoraSales.invoiceNotes : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@PurchaseOrder", evoraSales.purchaseOrder != null ? (object)evoraSales.purchaseOrder : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@ExpectedDelivery", evoraSales.expectedDelivery != null ? (object)evoraSales.expectedDelivery : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Type", evoraSales.type != null ? (object)evoraSales.type : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@CcxListing", evoraSales.ccxListing != null ? (object)evoraSales.ccxListing : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@RemittanceDate", evoraSales.remittanceDate != null ? (object)evoraSales.remittanceDate : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@DiscountAmount", evoraSales.discountAmount != null ? (object)evoraSales.discountAmount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@PreDiscount", evoraSales.preDiscount != null ? (object)evoraSales.preDiscount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@ShippingCost", evoraSales.shippingCost != null ? (object)evoraSales.shippingCost : (object)DBNull.Value);


                        await command.ExecuteNonQueryAsync();
                        foreach (EvoraLines line in evoraSales.Lines)
                        {
                            Console.WriteLine($"Line Item: {line.item}");
                            using (SqlCommand command2 = new SqlCommand("IF EXISTS (SELECT 1 FROM EvoraLines WHERE id = @id) " +
                   "BEGIN " +
                   "    UPDATE EvoraLines SET item=@item,uom=@uom,container=@container,quantity=@quantity, " +
                   "    price=@price,lot=@lot,gst=@gst,pst=@pst,hst=@hst,number=@number " +
                   "    WHERE id = @id " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                   "    INSERT INTO[dbo].[EvoraLines] " +
                   "    ([id],[number],[item],[uom],[container], " +
                   "    [quantity],[price],[lot],[gst],[pst], " +
                   "    [hst])" +
                   "    VALUES " +
                   "    (@id,@number, @item, @uom, @container, @quantity," +
                   "    @price, @lot, @gst, @pst, @hst)" +
                   "END", connection2))
                            {
                                command2.Parameters.AddWithValue("@id", line.id ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@number", evoraSales.number ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@item", (object)line.item ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@uom", (object)line.uom ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@container", line.container ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@quantity", line.quantity ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@price", line.price ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@lot", line.lot ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@gst", line.gst ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@pst", line.pst ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@hst", line.hst ?? (object)DBNull.Value);
                                // ... (other parameters)

                                await command2.ExecuteNonQueryAsync();
                            }
                        }

                        foreach (EvoraShipped shipped in evoraSales.Shipped)
                        {
                            Console.WriteLine($"Shipped Item: {shipped.item}");
                            using (SqlCommand command3 = new SqlCommand("IF EXISTS (SELECT 1 FROM EvoraShipped WHERE id = @id) " +
                   "BEGIN " +
                   "    UPDATE EvoraShipped SET item=@item,uom=@uom,quantity=@quantity, " +
                   "    evorapercent=@percent " +
                   "    WHERE id = @id " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                   "    INSERT INTO[dbo].[EvoraShipped] " +
                   "    ([id],[number],[item],[uom], " +
                   "    [quantity],[evorapercent]) " +
                   "      VALUES " +
                   "    (@id,@number, @item, @uom, @quantity," +
                   "    @percent)" +
                   "END", connection3))
                            {
                                command3.Parameters.AddWithValue("@id", shipped.id ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@number", evoraSales.number ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@item", (object)shipped.item ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@uom", (object)shipped.uom ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@quantity", (object)shipped.quantity ?? (object)DBNull.Value);
                                command3.Parameters.AddWithValue("@percent", (object)shipped.percent ?? (object)DBNull.Value);

                                // ... (other parameters)

                                await command3.ExecuteNonQueryAsync();
                            }
                        }








                    }


                    Console.WriteLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        //---------------------------------------------------------------Getshipment data------------------------------------------------
        public static async Task GetshipmentData()
        {

            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/shipments";
                shipmentjason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "shipment record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public async Task SaveShipmentDataToDatabase(List<Shipment> shipmentList)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlConnection connection1 = new SqlConnection(_connectionString);
                SqlConnection connection2 = new SqlConnection(_connectionString);

                await connection.OpenAsync();
                await connection2.OpenAsync();

                try
                {

                    await SaveOrUpdateShipmentDataAsync(connection, connection2);

                    Console.WriteLine("Shipment data saved to the database successfully.");
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"Error saving Shipment data to the database: {ex.Message}");
                }

                
                


            }
        }
        public async Task SaveOrUpdateShipmentDataAsync(SqlConnection connection, SqlConnection connection2)
        {
            try
            {
                List<Evorashipment> evoraShipmentList = JsonConvert.DeserializeObject<List<Evorashipment>>(shipmentjason);
                Console.WriteLine("Count is " + evoraShipmentList.Count);

                foreach (Evorashipment evorashipment in evoraShipmentList)
                {
                    using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM EvoraShipment WHERE number = @number) " +
                                                          "BEGIN " +
                                                          "   UPDATE EvoraShipment SET appointment=@appointment,asn=@asn,city=@city,country=@country, " +
                                                                  "courier=@courier,customer=@customer,expectedDelivery=@expectedDelivery,date=@date, " +
                                                                  "location=@location,postal=@postal,prov=@prov,sale=@sale,shippingNumber=@shippingNumber, " +
                                                                  "status=@status,street1=@street1,street2=@street2,vendor=@vendor,type =@type " +
                                                                  "WHERE number =@number " +
                                                          "END " +
                                                          "ELSE " +
                                                          "BEGIN " +
                                                                  " INSERT INTO[dbo].[EvoraShipment] " +
                                                                  "([number],[appointment],[asn],[city],[country], " +
                                                                  "[courier],[customer],[expectedDelivery],[date], " +
                                                                  "[location],[postal],[prov],[sale],[shippingNumber], " +
                                                                  "[status],[street1],[street2],[vendor],[type]) " +
                                                                  " VALUES " +
                                                                  "(@number, @appointment, @asn, @city, @country," +
                                                                  "@courier, @customer, @expectedDelivery, @date," +
                                                                  "@location, @postal, @prov, @sale, @shippingNumber, " +
                                                                  "@status, @street1, @street2, @vendor,@type)" +
                                                          "END", connection))
                    {
                        command.Parameters.AddWithValue("@number", evorashipment.number ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@appointment", evorashipment.appointment ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@asn", evorashipment.asn ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@city", evorashipment.city ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@country", evorashipment.country?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@courier", evorashipment.courier ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@customer", evorashipment.customer ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@expectedDelivery", evorashipment.expectedDelivery ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@date", evorashipment.date != null ? (object)PrepareDateTime(evorashipment.date) : DBNull.Value);
                        command.Parameters.AddWithValue("@location", evorashipment.location ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@postal", evorashipment.postal != null ? (object)evorashipment.postal : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@prov", evorashipment.prov != null ? (object)evorashipment.prov : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@sale", evorashipment.sale != null ? (object)evorashipment.sale : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@shippingNumber", evorashipment.shippingNumber != null ? (object)evorashipment.shippingNumber : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@status", evorashipment.status != null ? (object)evorashipment.status : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@street1", evorashipment.street1 != null ? (object)evorashipment.street1 : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@street2", evorashipment.street2 != null ? (object)evorashipment.street2 : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@vendor", evorashipment.vendor != null ? (object)evorashipment.vendor : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@type", evorashipment.type != null ? (object)evorashipment.type : (object)DBNull.Value);


                        await command.ExecuteNonQueryAsync();
                        foreach (contents shipmentcontent in evorashipment.contents)
                        {
                            Console.WriteLine($"Line Item: {shipmentcontent.id}");
                            using (SqlCommand command2 = new SqlCommand("IF EXISTS (SELECT 1 FROM Contents WHERE id = @id AND number = @number) " +
                   "BEGIN " +
                   "    UPDATE Contents SET item=@item,uom=@uom,container=@container, " +
                   "    quantity=@quantity,expectedquantity=@expectedquantity, lot = @lot " +
                   "    WHERE id = @id " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                   "    INSERT INTO[dbo].[Contents] " +
                   "    ([id],[number],[item],[uom],[container], " +
                   "    [quantity],[expectedquantity],[lot]) " +
                   "    VALUES " +
                   "    (@id,@number, @item, @uom, @container, @quantity," +
                   "    @expectedquantity,@lot)" +
                   "END", connection2))
                            {
                                command2.Parameters.AddWithValue("@id", shipmentcontent.id ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@number", evorashipment.number ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@item", (object)shipmentcontent.item ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@uom", (object)shipmentcontent.uom ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@container", shipmentcontent.container ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@quantity", shipmentcontent.quantity != null ? (object)shipmentcontent.quantity : (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@expectedquantity", shipmentcontent.expectedquantity ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@lot", shipmentcontent.lot?? (object)DBNull.Value);

                                // ... (other parameters)

                                await command2.ExecuteNonQueryAsync();
                            }
                        }


                    }


                    Console.WriteLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        //////--------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task GetPurchaseOrderData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/purchaseorders";
                purchaseOrderJson = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Customer record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public static async Task SavePODataToDatabase(List<PurchaseOrdersData> podatas)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlConnection connection2 = new SqlConnection(_connectionString);
                SqlConnection connection3 = new SqlConnection(_connectionString);

                await connection.OpenAsync();
                await connection2.OpenAsync();
                await connection3.OpenAsync();

                try
                {

                    await SaveOrUpdatePurchaseOrdersDatasAsync(connection, connection2, connection3);

                    Console.WriteLine("Purchase Order data saved to the database successfully.");
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"Error saving Purchase Order data  to the database: {ex.Message}");
                }

                
                
            }

        }
        public static async Task SaveOrUpdatePurchaseOrdersDatasAsync(SqlConnection connection, SqlConnection connection2, SqlConnection connection3)
        {
            try
            {

                List<EvoraPurchaseOrder> poList = JsonConvert.DeserializeObject<List<EvoraPurchaseOrder>>(purchaseOrderJson);
                Console.WriteLine("Purchase Order Count is " + poList.Count);

                foreach (EvoraPurchaseOrder evoraPoList in poList)
                {
                    using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM PurchaseOrdersData WHERE number = @number)" +
                                                          "BEGIN " +
                                                          "   UPDATE PurchaseOrdersData SET number=@number,status = @status,location = @location,date = @date,vendor = @vendor, " +
                                                          "amount = @amount,gstRate = @gstRate,pstRate = @pstRate,hstRate = @hstRate,taxAmount = @taxAmount," +
                                                          "totalAmount = @totalAmount,expectedDelivery = @expectedDelivery " +
                                                          " WHERE number = @number " +
                                                          "END " +
                                                          "ELSE " +
                                                          "BEGIN " +
                                                                 "INSERT INTO [dbo].[PurchaseOrdersData]" +
                                                                 "([number],[status],[location],[date],[vendor],[amount],[gstRate],[pstRate],[hstRate],[taxAmount],[totalAmount],[expectedDelivery])" +
                                                                 " VALUES" +
                                                                 "(@number,@status,@location,@date,@vendor,@amount,@gstRate,@pstRate,@hstRate,@taxAmount,@totalAmount,@expectedDelivery)" +
                                                          "END", connection))
                    {
                        command.Parameters.AddWithValue("@number", evoraPoList.number ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@status", evoraPoList.status ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@location", evoraPoList.location ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@date", (object)PrepareDateTime(evoraPoList.date) ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@vendor", evoraPoList.vendor ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@amount", (object)evoraPoList.amount ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@gstRate", (object)evoraPoList.gstRate ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@pstRate", evoraPoList.pstRate ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@hstRate", evoraPoList.hstRate ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@taxAmount", evoraPoList.taxAmount ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@totalAmount", evoraPoList.totalAmount != null ? (object)evoraPoList.totalAmount : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@expectedDelivery", evoraPoList.expectedDelivery != null ? (object)evoraPoList.expectedDelivery : (object)DBNull.Value);




                        await command.ExecuteNonQueryAsync();
                        foreach (contents poContents in evoraPoList.contents)
                        {
                            using (SqlCommand command2 = new SqlCommand("IF EXISTS (SELECT 1 FROM PurchaseOrderContents WHERE id = @id) " +
                   "BEGIN " +
                   "    UPDATE PurchaseOrderContents SET number=@number,item=@item,uom=@uom,quantity=@quantity, " +
                   "    unitCost=@unitCost,lineCost=@lineCost,tax=@tax " +
                   "    WHERE id = @id " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                    "INSERT INTO [dbo].[PurchaseOrderContents]" +
                     "(number,id,item,quantity,uom,unitCost,lineCost,tax)" +
                    "VALUES" +
                   "(@number,@id,@item,@quantity,@uom,@unitCost,@lineCost,@tax)" +
                   "END", connection2))
                            {
                                command2.Parameters.AddWithValue("@number", evoraPoList.number ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@id", poContents.id ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@item", poContents.item ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@quantity", (object)poContents.quantity ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@uom", (object)poContents.uom ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@unitCost", (object)poContents.unitCost ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@lineCost", (object)poContents.lineCost ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@tax", (object)poContents.tax ?? (object)DBNull.Value);

                                await command2.ExecuteNonQueryAsync();
                            }
                        }

                        foreach (received received in evoraPoList.received)
                        {
                            Console.WriteLine($"Received Item: {received.item}");
                            using (SqlCommand command3 = new SqlCommand("IF EXISTS (SELECT 1 FROM PurchaseOrderReceived WHERE id = @id) " +
                   "BEGIN " +
                   "    UPDATE PurchaseOrderReceived SET id=@id,number=@number,item=@item,uom=@uom,quantity=@quantity, " +
                   "    percentval=@percentval " +
                   "    WHERE id = @id " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                   "INSERT INTO [dbo].[PurchaseOrderReceived]" +
           "(number,id,item,quantity,uom,percentval)" +
     "VALUES" +
           "(@number,@id,@item,@quantity,@uom,@percentval)" +
                   "END", connection3))
                            {
                                command3.Parameters.AddWithValue("@id", received.id ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@number", evoraPoList.number ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@item", (object)received.item ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@uom", (object)received.uom ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@quantity", (object)received.quantity ?? (object)DBNull.Value);
                                command3.Parameters.AddWithValue("@percentval", (object)received.percent ?? (object)DBNull.Value);


                                await command3.ExecuteNonQueryAsync();
                            }
                        }








                    }


                    Console.WriteLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        //////--------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task GetReceiptsOrderData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/receipts";
                receiptorderJason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                //.WriteLine(customerJason);
                //Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Customer record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public static async Task SaveRODataToDatabase(List<ReceiptsOrderData> rodatas)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlConnection connection2 = new SqlConnection(_connectionString);
              

                await connection.OpenAsync();
                await connection2.OpenAsync();

                try
                {

                    await SaveOrUpdateReceiptsOrdersDatasAsync(connection, connection2);

                    Console.WriteLine("Receipts Order Data saved to the database successfully.");
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"Error saving Receipts Order Data to the database: {ex.Message}");
                }


               
            }

        }
        public static async Task SaveOrUpdateReceiptsOrdersDatasAsync(SqlConnection connection, SqlConnection connection2)
        {
            try
            {

                List<EvoraReceiptsOrder> roList = JsonConvert.DeserializeObject<List<EvoraReceiptsOrder>>(receiptorderJason);
                Console.WriteLine("Receipts Order Count is " + roList.Count);

                foreach (EvoraReceiptsOrder evoraRoList in roList)
                {
                    using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM ReceiptsOrdersData WHERE number = @number)" +
                                                          "BEGIN " +
                                                          "   UPDATE ReceiptsOrdersData SET number=@number,status = @status,type = @type,location = @location,date = @date,sale = @sale, " +
                                                          "customer = @customer,vendor = @vendor,courier = @courier,shippingNumber = @shippingNumber,purchaseOrder = @purchaseOrder" +
                                                          " WHERE number = @number " +
                                                          "END " +
                                                          "ELSE " +
                                                          "BEGIN " +
                                                                 "INSERT INTO [dbo].[ReceiptsOrdersData]" +
                                                                 "(number,status,type,location,date,sale,customer,vendor,courier,shippingNumber,purchaseOrder)" +
                                                                 "VALUES" +
                                                                 "(@number,@status,@type,@location,@date,@sale,@customer,@vendor,@courier,@shippingNumber,@purchaseOrder)" +
                                                          "END", connection))
                    {
                        command.Parameters.AddWithValue("@number", evoraRoList.number ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@status", evoraRoList.status ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@type", evoraRoList.type ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@location", evoraRoList.location ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@date", (object)PrepareDateTime(evoraRoList.date) ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@sale", evoraRoList.sale?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@customer", (object)evoraRoList.customer?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@vendor", (object)evoraRoList.vendor ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@courier", evoraRoList.courier ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@shippingNumber", evoraRoList.shippingNumber ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@purchaseOrder", evoraRoList.purchaseOrder ?? (object)DBNull.Value);
                        

                        await command.ExecuteNonQueryAsync();
                        foreach (contents roContents in evoraRoList.contents)
                        {
                            using (SqlCommand command2 = new SqlCommand("IF EXISTS (SELECT 1 FROM ReceiptsOrderContents WHERE id = @id) " +
                   "BEGIN " +
                   "    UPDATE ReceiptsOrderContents SET number=@number,item=@item,uom=@uom,count=@count,container=@container,quantity=@quantity, " +
                   "    lot=@lot,bin=@bin,vendorLot=@vendorLot,totalUOM=@totalUOM,containerType=@containerType,expectedQuantity=@expectedQuantity " +
                   "    WHERE id = @id " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                    "INSERT INTO [dbo].[ReceiptsOrderContents]" +
                    "(number,id,item,uom,count,container,quantity,lot,bin,vendorLot,totalUOM,containerType,expectedQuantity)" +
                    "VALUES" +
                    "(@number,@id,@item,@uom,@count,@container,@quantity,@lot,@bin,@vendorLot,@totalUOM,@containerType,@expectedQuantity)" +
                   "END", connection2))
                            {
                                command2.Parameters.AddWithValue("@number", evoraRoList.number ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@id", roContents.id ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@item", roContents.item ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@uom", (object)roContents.uom ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@count", (object)roContents.Count ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@container", (object)roContents.container ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@quantity", (object)roContents.quantity?? DBNull.Value);
                                command2.Parameters.AddWithValue("@lot", (object)roContents.lot ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@bin", (object)roContents.Bin ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@VendorLot", (object)roContents.VendorLot ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@TotalUOM", (object)roContents.TotalUOM ?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@ContainerType", (object)roContents.ContainerType?? (object)DBNull.Value);
                                command2.Parameters.AddWithValue("@expectedquantity", (object)roContents.expectedquantity ?? (object)DBNull.Value);
                               
                                await command2.ExecuteNonQueryAsync();
                            }
                        }
 

                    }

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        /////--------------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task GetProductionBatchData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/productionbatches?start=2024-01-01";
                productionbatchesJason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "Customer record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public static async Task SavePBDataToDatabase(List<ProductionBatches> pbdatas)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {

                SqlConnection connection2 = new SqlConnection(_connectionString);
                SqlConnection connection3 = new SqlConnection(_connectionString);
                SqlConnection connection4 = new SqlConnection(_connectionString);


                await connection.OpenAsync();
                await connection2.OpenAsync();
                await connection3.OpenAsync();
                await connection4.OpenAsync();

                try
                {

                    await SaveOrUpdatePBDataToDatabase(connection, connection2, connection3, connection4);

                    Console.WriteLine("Production Batch Data saved to the database successfully.");
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"Error saving Production Batch Data to the database: {ex.Message}");
                }



            }

        }
        public static async Task SaveOrUpdatePBDataToDatabase(SqlConnection connection, SqlConnection connection2, SqlConnection connection3,SqlConnection connection4)
        {
            try
            {

                List<EvoraProductionBatches> pbList = JsonConvert.DeserializeObject<List<EvoraProductionBatches>>(productionbatchesJason);
                Console.WriteLine("Production Order Count is " + pbList.Count);

                foreach (EvoraProductionBatches evoraPbList in pbList)
                {
                    using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM ProductionBatches WHERE number = @number)" +
                                                          "BEGIN " +
                                                          "   UPDATE ProductionBatches SET number=@number,description = @description,location = @location,status = @status,plannedStart = @plannedStart, " +
                                                          "actualStart = @actualStart,startItem = @startItem,outputItem = @outputItem,dueDate = @dueDate,packagedOn = @packagedOn" +
                                                          " WHERE number = @number " +
                                                          "END " +
                                                          "ELSE " +
                                                          "BEGIN " +
                                                                 "INSERT INTO [dbo].[ProductionBatches] " +
                                                                 "(number,description,location,status,plannedStart,actualStart,startItem,outputItem,uom,outputQuantity,dueDate,packagedOn)" +
                                                                 " VALUES " +
                                                                 "(@number,@description,@location,@status,@plannedStart,@actualStart,@startItem,@outputItem,@uom,@outputQuantity,@dueDate,@packagedOn) " +
                                                          "END", connection))
                    {
                        command.Parameters.AddWithValue("@number", evoraPbList.number ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@description", evoraPbList.description ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@location", evoraPbList.location ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@status", (object)evoraPbList.status ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@plannedStart", evoraPbList.plannedStart?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@actualStart", (object)evoraPbList.actualStart ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@startItem", (object)evoraPbList.startItem ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@outputItem", evoraPbList.outputItem?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@uom", evoraPbList.uom ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@outputQuantity", evoraPbList.outputQuantity ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@dueDate", (object)PrepareDateTime(evoraPbList.dueDate) ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@packagedOn", evoraPbList.packagedOn ?? (object)DBNull.Value);


                        await command.ExecuteNonQueryAsync();
                            foreach (activities pbactivity in evoraPbList.activities)
                                {
                                    using (SqlCommand command2 = new SqlCommand("IF EXISTS (SELECT 1 FROM Activities WHERE id = @id) " +
                                    "BEGIN " +
                                    "UPDATE Activities SET number=@number,roomCleaning=@roomCleaning,roomToClean=@roomToClean,productionOrder=@productionOrder, " +
                                    "routing=@routing,bom=@bom,outputItem=@outputItem,outputUOM=@outputUOM,outputQuantity=@outputQuantity " +
                                    "WHERE id = @id " +
                                    "END " +
                                    "ELSE " +
                                    "BEGIN " +
                                    "INSERT INTO [dbo].[Activities]" +
                                    "(number,id,roomCleaning,roomToClean,productionOrder,routing,bom,outputItem,outputUOM,outputQuantity) " +
                                    " VALUES" +
                                    " (@number,@id,@roomCleaning,@roomToClean,@productionOrder,@routing,@bom,@outputItem,@outputUOM,@outputQuantity)" +
                                    "END", connection2))
                                        {
                                             command2.Parameters.AddWithValue("@number", evoraPbList.number ?? (Object)DBNull.Value);
                                             command2.Parameters.AddWithValue("@id", pbactivity.id ?? (Object)DBNull.Value);
                                             command2.Parameters.AddWithValue("@roomCleaning", pbactivity.roomCleaning ?? (Object)DBNull.Value);
                                             command2.Parameters.AddWithValue("@roomToClean", (object)pbactivity.roomToClean ?? DBNull.Value);
                                             command2.Parameters.AddWithValue("@productionOrder", (object)pbactivity.productionOrder?? DBNull.Value);
                                             command2.Parameters.AddWithValue("@routing", (object)pbactivity.routing ?? (object)DBNull.Value);
                                             command2.Parameters.AddWithValue("@bom", (object)pbactivity.bom ?? (object)DBNull.Value);
                                             command2.Parameters.AddWithValue("@outputItem", (object)pbactivity.outputItem ?? (object)DBNull.Value);
                                             command2.Parameters.AddWithValue("@outputUOM", (object)pbactivity.outputUOM ?? (object)DBNull.Value);
                                             command2.Parameters.AddWithValue("@outputQuantity", (object)pbactivity.outputQuantity?? (object)DBNull.Value);

                                            await command2.ExecuteNonQueryAsync();
                                        }
                                }

                            foreach (outputs output in evoraPbList.outputs)
                               {
                            

                                    Console.WriteLine($"output Item: {output.item}");
                                     using (SqlCommand command3 = new SqlCommand("IF EXISTS (SELECT 1 FROM Outputs WHERE item = @item) " +
                                    "BEGIN " +
                                    "    UPDATE Outputs SET number=@number,item=@item,uom=@uom,lot=@lot,status=@status,amount=@amount" +
                                    "    WHERE item = @item " +
                                    "END " +
                                    "ELSE " +
                                    "BEGIN " +
                                    "INSERT INTO [dbo].[Outputs]" +
                                    "(number,item,amount,uom,lot,status)" +
                                    "VALUES" +
                                    "(@number,@item,@amount,@uom,@lot,@status)" +
                                    "END", connection3))
                                    {
                                        command3.Parameters.AddWithValue("@item", output.item ?? (Object)DBNull.Value);
                                        command3.Parameters.AddWithValue("@number", evoraPbList.number ?? (Object)DBNull.Value);
                                        command3.Parameters.AddWithValue("@amount", output.amount ?? (Object)DBNull.Value);
                                        command3.Parameters.AddWithValue("@uom", (object)output.uom ?? DBNull.Value);
                                        command3.Parameters.AddWithValue("@lot", (object)output.lot ?? (object)DBNull.Value);
                                        command3.Parameters.AddWithValue("@status", (object)output.status ?? (object)DBNull.Value);
                                        await command3.ExecuteNonQueryAsync();

                                    }
                               }

                            foreach (inputs input in evoraPbList.inputs)
                               {
                                    Console.WriteLine($"input Item: {input.item}");
                                    using (SqlCommand command4 = new SqlCommand("IF EXISTS (SELECT 1 FROM IInputs WHERE item = @item) " +
                                    "BEGIN " +
                                     "UPDATE IInputs SET item=@item,number=@number,uom=@uom,lot=@lot,amount=@amount,cost=@cost " +
                                    " WHERE item = @item " +
                                    "END " +
                                    "ELSE " +
                                    "BEGIN " +
                                    "INSERT INTO [dbo].[IInputs]" +
                                    "(number,item,amount,uom,lot,cost)" +
                                    "VALUES" +
                                    "(@number,@item,@amount,@uom,@lot,@cost)" +
                                    "END", connection4))
                                        {
                                            command4.Parameters.AddWithValue("@number", evoraPbList.number ?? (Object)DBNull.Value);
                                            command4.Parameters.AddWithValue("@item", input.item ?? (Object)DBNull.Value);
                                            command4.Parameters.AddWithValue("@amount", input.amount ?? (Object)DBNull.Value);
                                            command4.Parameters.AddWithValue("@uom", (object)input.uom ?? DBNull.Value);
                                            command4.Parameters.AddWithValue("@lot", (object)input.lot ?? (object)DBNull.Value);
                                            command4.Parameters.AddWithValue("@cost", (object)input.cost ?? (object)DBNull.Value);


                                            await command4.ExecuteNonQueryAsync();
                                        }
                               }


                    }


                   
                }
                

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        /////---------------------------------------------------------------------------------------------------------------------------------------------------
        public static async Task GetProductionOrderData()
        {
            try
            {

                string apiUrl = "https://ogkush.evoratechnologies.com/ext/productionorders?start=2021-11-15";
                productionorderJason = await cusapirequest.EvoraApiRequest(apiUrl, publicToken);
                
            }
            catch (Exception ex)
            {
                writter.LogInfoWriter("------------------" + "production order record reading error...!" + "--------------------------------------------------------------------------");
                writter.LogInfoWriter("------------------" + $"Exception: {ex.Message}" + "--------------------------------------------------------------------------");

            }


        }
        public static async Task SaveProductionOrderDataToDatabase(List<ProductionOrder> POrdersdatas)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlConnection connection2 = new SqlConnection(_connectionString);
                SqlConnection connection3 = new SqlConnection(_connectionString);

                await connection.OpenAsync();
                await connection2.OpenAsync();
                await connection3.OpenAsync();

                try
                {

                    await SaveOrUpdateProductionOrderDataAsync(connection, connection2, connection3);

                    Console.WriteLine("Production Order Data saved to the database successfully.");
                }
                catch (Exception ex)
                {

                    Console.WriteLine($"Error saving Production Order Data to the database: {ex.Message}");
                }

                
            }

        }

        public static async Task SaveOrUpdateProductionOrderDataAsync(SqlConnection connection, SqlConnection connection2, SqlConnection connection3)
        {
            try
            {

                List<POrders> poList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<POrders>>(productionorderJason);
                Console.WriteLine("Production Order Count is " + poList.Count);

                foreach (POrders pOrderList in poList)
                {
                    using (SqlCommand command = new SqlCommand("IF EXISTS (SELECT 1 FROM ProductionOrderData WHERE number = @number)" +
                                                          "BEGIN " +
                                                          "   UPDATE ProductionOrderData SET number=@number, description=@description, productionBatch=@productionBatch, quantity=@quantity, quantityUOM=@quantityUOM, " +
                                                                 "plannedQuantity=@plannedQuantity, startDate=@startDate, plannedStart=@plannedStart, endDate=@endDate, dueDate=@dueDate, " +
                                                                 "status=status, location=location, routing=routing, productionBom=productionBom, custom=custom, " +
                                                                 "outputItem=@outputItem, inpurtCost=@inpurtCost, labourCost=@labourCost, notes=@notes, processingLoss=@processingLoss, " +
                                                                 "processingLossPercent=@processingLossPercent, inputCannabisTotal=@inputCannabisTotal, outputCannabisTotal=@outputCannabisTotal, lines=@lines, inputs=@inputs, " +
                                                                 "outputs=@outputs, activityOutputs=@activityOutputs" +
                                                          " WHERE number = @number " +
                                                          "END " +
                                                          "ELSE " +
                                                          "BEGIN " +
                                                                 "INSERT INTO [dbo].[ProductionOrderData]" +
                                                                 "(number, description, productionBatch, quantity, quantityUOM, " +
                                                                 "plannedQuantity, startDate, plannedStart, endDate, dueDate, " +
                                                                 "status, location, routing, productionBom, custom, " +
                                                                 "outputItem, inpurtCost, labourCost, notes, processingLoss, " +
                                                                 "processingLossPercent, inputCannabisTotal, outputCannabisTotal, lines, inputs, " +
                                                                 "outputs, activityOutputs)" +
                                                                 "VALUES" +
                                                                 "(@number, @description, @productionBatch, @quantity, @quantityUOM, " +
                                                                 "@plannedQuantity, @startDate, @plannedStart, @endDate, @dueDate, " +
                                                                 "@status, @location, @routing, @productionBom, @custom, " +
                                                                 "@outputItem, @inpurtCost, @labourCost, @notes, @processingLoss, " +
                                                                 "@processingLossPercent, @inputCannabisTotal, @outputCannabisTotal, @lines, @inputs, " +
                                                                 "@outputs, @activityOutputs)" +
                                                          "END", connection))
                    {
                        command.Parameters.AddWithValue("@number", pOrderList.number ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@description", pOrderList.description ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@productionBatch", pOrderList.productionBatch ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@quantity", (object)pOrderList.quantity ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@quantityUOM", (object)pOrderList.quantityUOM ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@plannedQuantity", (object)pOrderList.plannedQuantity ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@startDate", (object)PrepareDateTime(pOrderList.startDate) ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@plannedStart", (object)PrepareDateTime(pOrderList.plannedStart) ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@endDate", (object)PrepareDateTime(pOrderList.endDate) ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@dueDate", (object)PrepareDateTime(pOrderList.dueDate) ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@status", pOrderList.status ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@location", pOrderList.location ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@routing", pOrderList.routing ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@productionBom", pOrderList.productionBom ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@custom", (object)pOrderList.custom ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@outputItem", (object)pOrderList.outputItem ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@inpurtCost", (object)pOrderList.inpurtCost ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@labourCost", (object)pOrderList.labourCost ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@notes", (object)pOrderList.notes ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@processingLoss", (object)pOrderList.processingLoss ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@processingLossPercent", (object)pOrderList.processingLossPercent ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@inputCannabisTotal", (object)pOrderList.inputCannabisTotal ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@outputCannabisTotal", (object)pOrderList.outputCannabisTotal ?? (object)DBNull.Value);



                        await command.ExecuteNonQueryAsync();
                        foreach (Input inputContents in pOrderList.inputs)
                        {
                            using (SqlCommand command2 = new SqlCommand("IF EXISTS (SELECT 1 FROM ProductionOrderInput WHERE number = @number) " +
                   "BEGIN " +
                   "    UPDATE ProductionOrderInput SET number=@number,item=@item,amount=@amount,uom=@uom,count=@count,lot=@lot,container=@container,bin=@bin, " +
                   "    WHERE number = @number " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                    "INSERT INTO [dbo].[ProductionOrderInput]" +
                    "(number, item, amount, uom, count, lot, container, bin)" +
                    "VALUES" +
                    "(@number, @item, @amount, @uom, @count, @lot, @container, @bin)" +
                   "END", connection2))
                            {
                                command2.Parameters.AddWithValue("@number", pOrderList.number ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@item", inputContents.item ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@amount", (Object)inputContents.amount ?? (Object)DBNull.Value);
                                command2.Parameters.AddWithValue("@uom", (object)inputContents.uom ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@count", (object)inputContents.count ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@lot", (object)inputContents.lot ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@container", (object)inputContents.container ?? DBNull.Value);
                                command2.Parameters.AddWithValue("@bin", (object)inputContents.bin ?? DBNull.Value);


                                await command2.ExecuteNonQueryAsync();
                            }
                        }

                        foreach (Output outputContents in pOrderList.outputs)
                        {
                            using (SqlCommand command3 = new SqlCommand("IF EXISTS (SELECT 1 FROM ProductionOrderOutput WHERE id = @id) " +
                   "BEGIN " +
                   "    UPDATE (number=number, id=@id, item=@item, amount=@amount, uom, lot, container, bin, discreteWeightUOM, containerType) " +
                   "    WHERE id = @id " +
                   "END " +
                   "ELSE " +
                   "BEGIN " +
                    "INSERT INTO [dbo].[ProductionOrderOutput]" +
                    "(number, id, item, amount, uom, lot, container, bin, discreteWeightUOM, containerType)" +
                    "VALUES" +
                    "(@number, @id, @item, @amount, @uom, @lot, @container, @bin, @discreteWeightUOM, @containerType)" +
                   "END", connection3))
                            {
                                command3.Parameters.AddWithValue("@number", pOrderList.number ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@id", outputContents.id ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@item", (object)outputContents.amount ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@amount", (Object)outputContents.uom ?? (Object)DBNull.Value);
                                command3.Parameters.AddWithValue("@uom", (object)outputContents.lot ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@lot", (object)outputContents.container ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@container", (object)outputContents.discreteWeightUOM ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@bin", (object)outputContents.containerType ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@discreteWeightUOM", (object)outputContents.discreteWeightUOM ?? DBNull.Value);
                                command3.Parameters.AddWithValue("@containerType", (object)outputContents.containerType ?? DBNull.Value);



                                await command3.ExecuteNonQueryAsync();
                            }
                        }


                    }


                    Console.WriteLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }


    }


}


    



        
    






