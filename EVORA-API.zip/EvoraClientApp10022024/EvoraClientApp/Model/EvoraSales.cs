﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class EvoraSales
    {
        public string number { get; set; }
        public string status { get; set; }
        public string customer { get; set; }
        public string street1 { get; set; }
        public string street2 { get; set; }
        public string city { get; set; }
        public string prov { get; set; }
        public string postal { get; set; }
        public string country { get; set; }
        public DateTime date { get; set; }
        public string location { get; set; }
        public double? amount { get; set; }
        public double? gstRate { get; set; }
        public double? hstRate { get; set; }
        public double? taxRate { get; set; }
        public double? pstRate { get; set; }
        public double? taxAmount { get; set; }
        public double? gstAmount { get; set; }
        public double? hstAmount { get; set; }
        public double? totalAmount { get; set; }
        public string notes { get; set; }
        public string invoiceNotes { get; set; }
        public string purchaseOrder { get; set; }
        public string expectedDelivery { get; set; }
        public string type { get; set; }
        public string ccxListing { get; set; }
        public string remittanceDate { get; set; }
        public double? discountAmount { get; set; }
        public double? preDiscount { get; set; }
        public double?  shippingCost { get; set; }
        public List<EvoraLines> Lines { get; set; }
        public List<EvoraShipped> Shipped { get; set; }

    }
}
