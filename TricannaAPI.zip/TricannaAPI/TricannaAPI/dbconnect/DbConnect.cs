﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TricannaAPI.ExceptionHandler;

namespace TricannaAPI.dbconnect
{
    class DbConnect
    {
        string conString;
        SqlConnection cn;

        public SqlConnection dbConnet()
        {
            try
            {
                //conString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + System.Configuration.ConfigurationManager.AppSettings["DataBase"].ToString() + ";Jet OLEDB:Database Password=";
                //cn = new OleDbConnection(conString);
                //  MessageBox.Show("Connection Sucseeded");
                //create a SQL connection for SQL database
                conString = @"Data Source=" + System.Configuration.ConfigurationManager.AppSettings["ServerName"].ToString() + "; Initial Catalog="+ System.Configuration.ConfigurationManager.AppSettings["CatalogName"].ToString() + ";User ID= "+ System.Configuration.ConfigurationManager.AppSettings["UserName"].ToString()+";Password=" + System.Configuration.ConfigurationManager.AppSettings["Password"].ToString();
                cn = new SqlConnection(conString);
               // MessageBox.Show("Connection Sucseeded");

            }
            catch (Exception e)
            {
                ExceptionWritter.LogErrorWriter("Error on database connectivity.  " + e.Message.ToString()); ;
                // MessageBox.Show("Connection Fail");
            }
            return cn;
        }

    }
}
