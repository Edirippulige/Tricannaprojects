﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class Item
    {
        public string EvoraItemNumber { get; set; }
        public string EvoraItemName { get; set; }
        public string category { get; set; }
        public string categoryName { get; set; }
        public string Uom { get; set; }
        public string PurchaseUOM { get; set; }
        public string EachQuantity { get; set; }
        public string Strain { get; set; }
        public string Inventory { get; set; }
        public string Price { get; set; }
        public string ItemCount { get; set; }
        public string AverageWeight { get; set; }
        public string Cost { get; set; }
        public string Tracking { get; set; }
        public string ReorderLeadTime { get; set; }
        public string ThcMg { get; set; }
        public string CbdMg { get; set; }
        public string PackSizeG { get; set; }
        public string PackCount { get; set; }
        public string ExpirationMonths { get; set; }
        public string NewLotStatus { get; set; }
        public string ExpectedUnitCost { get; set; }
        public string RegistrationNumer { get; set; }
        public string Sku { get; set; }
        public string Gtin { get; set; }
        public string CaseQuantity { get; set; }
        public string MinimumQuantity { get; set; }
        public string ProductNumber { get; set; }
        public string Description2 { get; set; }
        public string FullCost { get; set; }
        public string TotalUnitWeightG { get; set; }
        public string SkuOwner { get; set; }

        public string VendorID { get; set; }

        //public List<ItemVendor> vendors { get; set; }


    }
}
