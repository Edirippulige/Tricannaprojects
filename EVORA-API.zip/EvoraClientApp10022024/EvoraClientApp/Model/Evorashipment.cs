﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EvoraClientApp.Model
{
   public class Evorashipment
    {
        public string number { get; set; }
        public string id { get; set; }
        public string status { get; set; }
        public string type { get; set; }
        public string location { get; set; }
        public DateTime date { get; set; }
        public string sale { get; set; }
        public string customer { get; set; }
        public string vendor { get; set; }
        public string courier { get; set; }
        public string shippingNumber { get; set; }
        public string prov { get; set; }
        public string country { get; set; }
        public string street1 { get; set; }
        public string street2 { get; set; }
        public string city { get; set; }
        public string postal { get; set; }
        public string asn { get; set; }

        public string appointment { get; set; }
        public string expectedDelivery { get; set; }

        public List<contents> contents { get; set; }




    }
}
