﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public  class Sales
    {
        public string number { get; set; }
        public string Status { get; set; }
        public string Customer { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string City { get; set; }
        public string Prov { get; set; }
        public string Postal { get; set; }
        public string Country { get; set; }
        public DateTime Date { get; set; }
        public string Location { get; set; }
        public double? Amount { get; set; }
        public double? GstRate { get; set; }
        public double? HstRate { get; set; }
        public double? TaxRate { get; set; }
        public double? PstRate { get; set; }
        public double? TaxAmount { get; set; }
        public double? GstAmount { get; set; }
        public double? HstAmount { get; set; }
        public double? TotalAmount { get; set; }
        public string Notes { get; set; }
        public string InvoiceNotes { get; set; }
        public string PurchaseOrder { get; set; }
        public string ExpectedDelivery { get; set; }
        public string Type { get; set; }
        public string CcxListing { get; set; }
        public string RemittanceDate { get; set; }
        public double? DiscountAmount { get; set; }
        public double? PreDiscount { get; set; }
        public double? ShippingCost { get; set; }
        
        public List<EvoraLines> lines { get; set; }
        public List<EvoraShipped> shipped { get; set; }
    }
}
