﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TricannaAPI.dbconnect;
using TricannaAPI.Model;
using QBFC16Lib;
using TricannaAPI.ExceptionHandler;

namespace TricannaAPI.Service
{

    public class CustomerService
    {
        public int CustomerCount = 0;

        //These values from QB for update function to compare with DB values

        public string public_customerId = "";
        public string public_customerEditSeq = "";
        public string public_MainEmail = "";
        public string public_Name = "";
        public string public_MainPhone = "";
        public string public_BillTo1 = "";
        public string public_city = "";
        public string public_state = "";
        public string public_postal_code = "";
        public string public_BillTo2 = "";
        public string public_BillTo3 = "";
        public string public_Bcity = "";
        public string public_Bstate = "";
        public string public_Bpostal_code = "";
        public string public_BCountry = "";
        public string public_BNote = "";
        public string public_ShipTo1 = "";
        public string public_ShipTo2 = "";
        public string public_Scity = "";
        public string public_Sstate = "";
        public string public_Spostal_code = "";
        public string public_SCountry = "";
        public string public_SNote = "";

        public List<Customer> GetAllCustomersFromDatabase()
        {
            List<Customer> customers = new List<Customer>();
            Customer customerObject = new Customer();

            DbOperation dbOperation = new DbOperation();

            string sqlQuery = "SELECT * FROM Customer";
            DataSet customerData = dbOperation.getData(sqlQuery);

            int x = 0;
            string sqlQueryCount = "Select Count(*) As CCount from Customer";
            DataSet customerCountData = dbOperation.getcountData(sqlQueryCount);
            ExceptionWritter.LogInfoWriter($"----------------Gather customer data from database to update customers record..! at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

            CustomerCount = customerData.Tables[x].Rows.Count;
            //Console.WriteLine("Customer count from database= " + CustomerCount);
            ExceptionWritter.LogInfoWriter($"----------------Customer count from database= {CustomerCount} at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");




            if (customerData != null && customerData.Tables.Count > 0 && customerData.Tables.Count > x)
            {
                foreach (DataRow row in customerData.Tables[x].Rows)
                {
                    customerObject = new Customer(); // Create a new Customer object for each customer

                    //Assign DB values to the customer

                    customerObject.Name = row["CustomerName"].ToString();        //getting customer name from database and assign into the module
                    customerObject.Company = row["CustomerFullName"].ToString();
                   // customerObject.Active = (bool)row["CustomerIsActive"];
                   // customerObject.Title = row["Salutation"].ToString();
                   // customerObject.FirstName = row["FirstName"].ToString();
                    //customerObject.MiddleInitial = row["MiddleName"].ToString();
                   // customerObject.LastName = row["LastName"].ToString();
                    customerObject.BillTo1 = row["BillAddr1"].ToString();
                    customerObject.BillTo2 = row["BillAddr2"].ToString();
                  //  customerObject.BillTo3 = row["BillAddr3"].ToString();
                    customerObject.BillCity = row["BillCity"].ToString();
                    customerObject.BillCountry = row["BillCountry"].ToString();
                    customerObject.BillState = row["BillState"].ToString();
                    customerObject.BillPostalCode = row["BillPostalCode"].ToString();
                   // customerObject.BillNote = row["BillNote"].ToString();
                   // customerObject.ShipTo1 = row["ShipAddr1"].ToString();
                   // customerObject.ShipTo2 = row["ShipAddr2"].ToString();
                    //customerObject.ShipCity = row["ShipCity"].ToString();
                    //customerObject.ShipState = row["ShipState"].ToString();
                   // customerObject.ShipCountry = row["ShipCountry"].ToString();
                    //customerObject.ShipPostal = row["ShipPostalCode"].ToString();
                   // customerObject.ShipNote = row["ShipNote"].ToString();
                  //  customerObject.MainEmail = row["Email"].ToString();
                  //  customerObject.MainPhone = row["Phone"].ToString();
                  //  customerObject.LicenseNumber = row["LicenseNumber"].ToString();


                    customers.Add(customerObject);
                    ExceptionWritter.LogInfoWriter($"----------------The customer {customerObject.Name} found ..! at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                    //Console.WriteLine("Customer Name = " + customerObject.Name);
                }
                Console.WriteLine("");
                //Console.WriteLine("End of read database");
                ExceptionWritter.LogInfoWriter($"End of read database at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                Console.WriteLine("");
            }

            else
            {
               // Console.WriteLine("No customer data found.");
                ExceptionWritter.LogErrorWriter($"customers'data not found at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");
            }

           // Console.WriteLine("Gather customer data from database to update customers record..! Successfull..******************************************");
            ExceptionWritter.LogInfoWriter($"Gather customer data from database to update customers record..! Successfull.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");
            Console.Read();

            return customers;
        }
        public void AddCustomersToQuickBooks(List<Customer> customers)
        {
            // Initialize the QuickBooks Application object
            ExceptionWritter.LogInfoWriter($"Initialize QuickBooks Application For Update Customers Record..! Please Wait.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

           //Console.WriteLine("Initialize QuickBooks Application For Update Customers Record..! Please Wait..******************************************");
            QBSessionManager sessionManager = new QBSessionManager();
            //Console.WriteLine("Open QuickBooks Application Connection For Update Customers Record..! Please Wait..*************************************");
            ExceptionWritter.LogInfoWriter($"Open QuickBooks Application Connection For Update Customers Record..! Please Wait.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");


            sessionManager.OpenConnection("", "QuickBooks Desktop");

            //Console.WriteLine("Accept the QuickBooks Application access certificate Connection For Update Customers Record..! Please Wait..************");
            ExceptionWritter.LogInfoWriter($"Accept the QuickBooks Application access certificate Connection For Update Customers Record..! Please Wait.. at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

            
            sessionManager.BeginSession("", ENOpenMode.omDontCare);
           // Console.WriteLine("Customers Record Updating.....! Please Wait..***************************************************************************");
            ExceptionWritter.LogInfoWriter($"----------------Customers Record Updating started.....!  at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");


            foreach (Customer customer in customers)
            {
                // Create a CustomerAdd request for each customer
                IMsgSetRequest msgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
                msgSet.Attributes.OnError = ENRqOnError.roeStop;

                ICustomerAdd customerAdd = msgSet.AppendCustomerAddRq();
                

                
                
                //dataExtAdd.DataExtName.SetValue("LICENSE NUMBER");
                //dataExtAdd. // Adjust based on your data type

                //dataExtAdd.DataExtValue.SetValue(customer.LicenseNumber);


                // Adding customer values to the QB
                customerAdd.Name.SetValue(customer.Name);
                customerAdd.Email.SetValue(customer.MainEmail);
                customerAdd.Phone.SetValue(customer.MainPhone);
                //customerAdd.CompanyName.SetValue(customer.Name);
                //customerAdd.IsActive.SetValue(customer.Active);
                //customerAdd.Salutation.SetValue(customer.Title);
                //customerAdd.FirstName.SetValue(customer.FirstName);
                //customerAdd.LastName.SetValue(customer.LastName);
                customerAdd.BillAddress.Addr1.SetValue(customer.Name);
                customerAdd.BillAddress.Addr2.SetValue(customer.BillTo1);
                //customerAdd.BillAddress.Addr3.SetValue(customer.BillTo2);
                customerAdd.BillAddress.City.SetValue(customer.BillCity);
                customerAdd.BillAddress.State.SetValue(customer.BillState);
                customerAdd.BillAddress.PostalCode.SetValue(customer.BillPostalCode);
                customerAdd.BillAddress.Country.SetValue(customer.BillCountry);
                //customerAdd.ShipAddress.Addr1.SetValue(customer.ShipTo1);
                //customerAdd.ShipAddress.Addr2.SetValue(customer.ShipTo2);
                //customerAdd.ShipAddress.City.SetValue(customer.ShipCity);
                //customerAdd.ShipAddress.State.SetValue(customer.ShipState);
                //customerAdd.ShipAddress.PostalCode.SetValue(customer.ShipPostal);
               // customerAdd.ShipAddress.Country.SetValue(customer.ShipCountry);
                

                IMsgSetResponse response = sessionManager.DoRequests(msgSet);



                if (response.ResponseList.GetAt(0).StatusCode == 0)
                {
                    //Console.WriteLine("Open QuickBooks Application Connection For Update Customers Record..! Please Wait..******************************************");
                    //Console.WriteLine(customer.Name + " Customer created successfully..!");
                    ExceptionWritter.LogInfoWriter($"{customer.Name}  Customer created successfully..!  $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                    Console.WriteLine("");
                }
                else
                {
                    //Console.WriteLine(response.ResponseList.GetAt(0).StatusMessage);
                   // ExceptionWritter.LogInfoWriter($"{customer.Name}  Customer created successfully..!  $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                    // find getCustomerListIDAndEditSequence 
                    try
                    {
                        GetCustomerListIDAndEditSequence(customer.Name);
                        GetCustomerDataFromQB(customer.Name);
                        //Passing customer values to update

                        //            {



                        
                        UpdateCustomer(customer.Name, customer.MainEmail,customer.MainPhone,customer.BillTo1,
                            customer.BillTo2,customer.BillTo3,customer.BillCity,
                            customer.BillState,customer.BillPostalCode,customer.BillCountry,customer.BillNote,customer.ShipTo1, customer.ShipTo2
                            ,customer.ShipCity,
                            customer.ShipState,customer.ShipPostal,customer.ShipCountry,customer.ShipNote);
                       


                    }
                    catch (Exception e)
                    {
                        ExceptionWritter.LogErrorWriter($"Customer Update Error..! Customer Name: {customer.Name}, Error Message: {e.Message} at {DateTime.Now:yyyy.MM.dd HH:mm:ss:ffff}");
                        throw;
                    }



                }
            }

            // Close the QuickBooks session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();
            //Console.WriteLine("Close QuickBooks Application Connection. Please Wait..******************************************************************");
            ExceptionWritter.LogInfoWriter($"Close QuickBooks Application Connection.!  $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

            Console.Read();
        }


        // Reset Globel variable for next customer
        public void ResetValue()
        {
            public_customerId = "";
            public_customerEditSeq = "";
            public_Name = "";
            public_MainEmail = "";
            public_MainPhone = "";
            public_BillTo1 = "";
            public_BillTo2 = "";
            public_BillTo3 = "";
            public_Bcity = "";
            public_Bstate = "";
            public_Bpostal_code = "";
            public_BCountry = "";
            public_BNote = "";
            public_ShipTo1 = "";
            public_ShipTo2 = "";
            public_Scity = "";
            public_Sstate = "";
            public_Spostal_code = "";
            public_SCountry = "";
            public_SNote = "";
            

        }

        //get Customer ListId And EditSequence
        public void getCustomerListIDAndEditSequence()
        {

            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "QuickBooks Desktop");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to get a list of customers
            var query = requestMsgSet.AppendCustomerQueryRq();

            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);

            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var customerRetList = response.Detail as ICustomerRetList;

                if (customerRetList != null)
                {
                    for (int i = 0; i < customerRetList.Count; i++)
                    {
                        var customerRet = customerRetList.GetAt(i);
                        var customerId = customerRet.ListID.GetValue();
                        var customerEditSeq = customerRet.EditSequence.GetValue();
                        var customerName = customerRet.Name.GetValue();
                        //Console.WriteLine($"Customer ID: {customerId}, Customer Name: {customerName},Customer Edit Sequance: {customerEditSeq}");
                    }
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();

            Console.ReadLine();
        }

        // get quickbook data for specific customer
        public void GetCustomerDataFromQB(string customerName)
        {
            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "Your App Name");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to find a specific customer by name
            var query = requestMsgSet.AppendCustomerQueryRq();
            query.ORCustomerListQuery.FullNameList.Add(customerName);

            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);

            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var customerRetList = response.Detail as ICustomerRetList;

                if (customerRetList != null && customerRetList.Count > 0)
                {
                    var customerRet = customerRetList.GetAt(0); // Assuming you found one customer with the provided name

                    // Retrieve various customer data fields
                    public_customerId = customerRet.ListID.GetValue();
                    public_customerEditSeq = customerRet.EditSequence.GetValue();
                    public_Name = customerRet?.Name?.GetValue() ?? "";
                    public_MainEmail = customerRet?.Email?.GetValue() ?? "";
                    public_MainPhone = customerRet?.Phone?.GetValue() ?? "";
                    public_BillTo1 = customerRet?.BillAddress?.Addr1?.GetValue() ?? "";
                    public_BillTo2 = customerRet?.BillAddress?.Addr2?.GetValue() ?? "";
                    public_BillTo3 = customerRet?.BillAddress?.Addr3?.GetValue() ?? "";       
                    public_Bcity = customerRet?.BillAddress?.City?.GetValue() ?? "";
                    public_Bstate = customerRet?.BillAddress?.State?.GetValue() ?? "";
                    public_Bpostal_code = customerRet?.BillAddress?.PostalCode?.GetValue() ?? "";
                    public_BCountry = customerRet?.BillAddress?.Country?.GetValue() ?? "";
                    public_BNote = customerRet?.BillAddress?.Note?.GetValue() ?? "";
                    public_ShipTo1 = customerRet?.ShipAddress?.Addr1?.GetValue() ?? "";
                    public_ShipTo2 = customerRet?.ShipAddress?.Addr2?.GetValue() ?? "";
                    public_Scity = customerRet?.ShipAddress?.City?.GetValue() ?? "";
                    public_Sstate = customerRet?.ShipAddress?.State?.GetValue() ?? "";
                    public_Spostal_code = customerRet?.ShipAddress?.PostalCode?.GetValue() ?? "";
                    public_SCountry = customerRet?.ShipAddress?.Country?.GetValue() ?? "";
                    public_SNote = customerRet?.ShipAddress?.Note?.GetValue() ?? "";  
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();
        }

        public void UpdateCustomer(string New_Name, string New_MainEmail, string New_MainPhone, string New_BillTo1, string New_BillTo2,
            string New_BillTo3, string New_Bcity, string New_Bstate,
            string New_Bpostal_code, string New_BCountry, string New_BNote, string New_ShipTo1, string New_ShipTo2,
             string New_Scity, string New_Sstate,
            string New_Spostal_code, string New_SCountry, string New_SNote)
        {
            /* add more nullable parameters for other fields as needed */


            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "Your App Name");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to find a specific customer by name
            var query = requestMsgSet.AppendCustomerQueryRq();
            query.ORCustomerListQuery.FullNameList.Add(public_Name);

            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);
            
            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var customerRetList = response.Detail as ICustomerRetList;    //Get customer datafield from Quickbooks assign dataset to CustomerRetList object

                if (customerRetList != null && customerRetList.Count > 0)
                {
                    var customerRet = customerRetList.GetAt(0); 

                    // Get the customer's ListID and EditSequence
                    var customerId = customerRet.ListID.GetValue();
                    var customerEditSeq = customerRet.EditSequence.GetValue();

                    // Create a CustomerMod request to update selected fields
                    var customerMod = requestMsgSet.AppendCustomerModRq();
                    customerMod.ListID.SetValue(customerId);
                    customerMod.EditSequence.SetValue(customerEditSeq);
                   
                    // Update the fields if non-null values are provided
                    if (!string.IsNullOrEmpty(New_MainEmail))
                    {
                        customerMod.Email.SetValue(New_MainEmail);
                    }

                    if (!string.IsNullOrEmpty(New_MainPhone))
                    {
                        customerMod.Phone.SetValue(New_MainPhone);
                    }

                    if (!string.IsNullOrEmpty(New_BillTo1))
                    {
                        customerMod.BillAddress.Addr1.SetValue(New_Name);
                    }

                    if (!string.IsNullOrEmpty(New_BillTo2))
                    {
                        customerMod.BillAddress.Addr2.SetValue(New_BillTo1);
                    }

                    if (!string.IsNullOrEmpty(New_BillTo3))
                    {
                        customerMod.BillAddress.Addr3.SetValue(New_BillTo3);
                    }
                    

                    if (!string.IsNullOrEmpty(New_Bcity))
                    {
                        customerMod.BillAddress.City.SetValue(New_Bcity);
                    }

                    if (!string.IsNullOrEmpty(New_Bstate))
                    {
                       customerMod.BillAddress.State.SetValue(New_Bstate);
                    }

                    if (!string.IsNullOrEmpty(New_Bpostal_code))
                    {
                        customerMod.BillAddress.PostalCode.SetValue(New_Bpostal_code);
                    }
                    if (!string.IsNullOrEmpty(New_BCountry))
                    {
                        customerMod.BillAddress.Country.SetValue(New_BCountry);
                    }
                    //if (!string.IsNullOrEmpty(New_Bpostal_code))
                    //{
                    //    customerMod.BillAddress.PostalCode.SetValue(New_Bpostal_code);
                    //}
                    if (!string.IsNullOrEmpty(New_BNote))
                    {
                        customerMod.BillAddress.Note.SetValue(New_BNote);
                    }

                    if (!string.IsNullOrEmpty(New_ShipTo1))
                    {
                        customerMod.ShipAddress.Addr1.SetValue(New_ShipTo1);
                    }

                    if (!string.IsNullOrEmpty(New_ShipTo2))
                    {
                        customerMod.ShipAddress.Addr2.SetValue(New_ShipTo2);
                    }

                    if (!string.IsNullOrEmpty(New_Scity))
                    {
                        customerMod.ShipAddress.City.SetValue(New_Scity);
                    }

                    if (!string.IsNullOrEmpty(New_Sstate))
                    {
                        customerMod.ShipAddress.State.SetValue(New_Sstate);
                    }

                    if (!string.IsNullOrEmpty(New_Spostal_code))
                    {
                        customerMod.ShipAddress.PostalCode.SetValue(New_Spostal_code);
                    }

                    if (!string.IsNullOrEmpty(New_SCountry))
                    {
                        customerMod.ShipAddress.Country.SetValue(New_SCountry);
                    }

                    if (!string.IsNullOrEmpty(New_SNote))
                    {
                        customerMod.ShipAddress.Note.SetValue(New_SNote);
                        
                    }
                    

                    // Update other fields if non-null values are provided

                    // Execute the modification request
                    var responseMod = sessionManager.DoRequests(requestMsgSet);

                    if (responseMod.ResponseList.Count > 0)
                    {
                        var responseModCustomer = responseMod.ResponseList.GetAt(0);

                        if (responseModCustomer.StatusCode == 0)
                        {
                            //Console.WriteLine($"Customer: {New_Name} updated {New_MainEmail} {New_MainPhone} {New_BillTo1} successfully.");
                            //Console.WriteLine("");
                            ExceptionWritter.LogInfoWriter($"Customer: {New_Name} updated successfully $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

                        }
                        else
                        {
                            ExceptionWritter.LogErrorWriter($"Customer: {New_Name} not updated successfully $ at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");
                        }
                    }
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();
        }



        



        public (string ListID, string EditSequence) GetCustomerListIDAndEditSequence(string customerName)
        {
            // Create a QBSessionManager
            var sessionManager = new QBSessionManager();

            // Open a connection to QuickBooks Desktop
            sessionManager.OpenConnection("", "QuickBooks Desktop");
            sessionManager.BeginSession("", ENOpenMode.omDontCare);

            // Create a request
            var requestMsgSet = sessionManager.CreateMsgSetRequest("US", 13, 0);
            requestMsgSet.Attributes.OnError = ENRqOnError.roeStop;

            // Create a query request to find a specific customer by name
            var query = requestMsgSet.AppendCustomerQueryRq();
            query.ORCustomerListQuery.FullNameList.Add(customerName);

            // Execute the request
            var responseMsgSet = sessionManager.DoRequests(requestMsgSet);

            // Process the response
            var responseList = responseMsgSet.ResponseList;
            if (responseList.Count > 0)
            {
                var response = responseList.GetAt(0);
                var customerRetList = response.Detail as ICustomerRetList;

                if (customerRetList != null && customerRetList.Count > 0)
                {
                    var customerRet = customerRetList.GetAt(0); // Assuming you found one customer with the provided name
                    var customerId = customerRet.ListID.GetValue();
                    var customerEditSeq = customerRet.EditSequence.GetValue();
                    var customerNamed = customerRet.Name.GetValue();
                    //Console.WriteLine($"Customer ID: {customerId}, Customer Name: {customerNamed}, Customer Edit Sequence: {customerEditSeq}");
                    return (customerId, customerEditSeq);
                }
            }

            // Close the session and connection
            sessionManager.EndSession();
            sessionManager.CloseConnection();

            //Console.WriteLine($"No customer found with the name: {customerName}");
            ExceptionWritter.LogInfoWriter($"No customer found with the name: {customerName} at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}");
            return (null, null); // Return null if the customer is not found
        }

    }


}
