﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace EvoraClientApp.APIRequest
{
    public class CustomerApiRequest
    {
        public  async Task<string> EvoraApiRequest(string apiEndpoint, string accessToken)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", accessToken);

                var apiResponse = await client.GetAsync(apiEndpoint);

                if (apiResponse.IsSuccessStatusCode)
                {
                    return await apiResponse.Content.ReadAsStringAsync();
                }
                else
                {
                    throw new InvalidOperationException($"Error making API request: {apiResponse.StatusCode} - {apiResponse.ReasonPhrase}");
                }
            }
        }
    }
}
