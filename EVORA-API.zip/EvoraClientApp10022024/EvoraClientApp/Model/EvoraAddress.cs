﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class EvoraAddress
    {
       public string number { get; set; }
       public string type { get; set; }
        public string street1 { get; set; }
        public string street2 { get; set; }
        public string city { get; set; }
        public string prov { get; set; }
        public string postal { get; set; }
        public string country { get; set; }

        //vendor addresses

    }
    public class address
    {
        public string street1 { get; set; }
        public string street2 { get; set; }
        public string city { get; set; }
        public string prov { get; set; }
        public string postal { get; set; }
        public string country { get; set; }
    }

    public class VendorAddress
    {
        public string street1 { get; set; }
        public string street2 { get; set; }
        public string city { get; set; }
        public string prov { get; set; }
        public string postal { get; set; }
        public string country { get; set; }
    }




    /*public string street1 = null;

    public string Street1
    {
        get { return street1 ?? "-"; }
        set { street1 = value; }
    }
    public string street2 = null;
    public string Street2
    {
        get { return street2 ?? "-"; }
        set { street2 = value; }
    }

    public string city
    {
        get { return city ?? "-"; }
        set { city = value; }
    }
    // public string? street1 { get; set; }
    //public string street2 { get; set; }
    // public string city { get; set; }

    public string prov
    {
        get { return prov ?? "-"; }
        set { prov = value; }
    }
    //public string prov { get; set; }

    public string postal
    {
        get { return postal ?? "-"; }
        set { postal = value; }
    }
    // public string postal { get; set; }
    public string country
    {
        get { return country ?? "-"; }
        set { country = value; }
    }
    //public string country { get; set; }

    //vendor addresses
    */

}

    /*public class VendorAddress
    {

      // public string number = null;
        public string number
        {
            get { return number ?? "-"; }
            set { number = value; }
        }

        public string street1 = null;

        public string Street1
        {
            get { return street1 ?? "-"; }
            set { street1 = value; }
        }
        public string street2 = null;
        public string Street2
        {
            get { return street2 ?? "-"; }
            set { street2 = value; }
        }

        public string city
        {
            get { return city ?? "-"; }
            set { city = value; }
        }
        // public string? street1 { get; set; }
        //public string street2 { get; set; }
        // public string city { get; set; }

        public string prov
        {
            get { return prov ?? "-"; }
            set { prov = value; }
        }
        //public string prov { get; set; }

        public string postal
        {
            get { return postal ?? "-"; }
            set { postal = value; }
        }
        // public string postal { get; set; }
        public string country
        {
            get { return country ?? "-"; }
            set { country = value; }
        }
        //public string country { get; set; }

        //vendor addresses

    }*/





