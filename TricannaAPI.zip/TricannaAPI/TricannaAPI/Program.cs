﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TricannaAPI.dbconnect;
using TricannaAPI.ExceptionHandler;
using TricannaAPI.Model;
using TricannaAPI.Service;

namespace TricannaAPI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************************************************************************************************************************");
            ExceptionWritter.LogInfoWriter($"------------------Application starts at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");

            Console.WriteLine("*************************************************************************************************************************");

            
            CustomerService customerService = new CustomerService();

            List<Customer> customers = customerService.GetAllCustomersFromDatabase();
            customerService.AddCustomersToQuickBooks(customers);

            ExceptionWritter.LogInfoWriter($"-----Customers Record Updated successfully...! {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.-------");

            VendorService vendorService = new VendorService();

            List<Vendor> vendors = vendorService.GetAllVendorsFromDatabase();
            vendorService.AddVendorsToQuickBooks(vendors);

            ExceptionWritter.LogInfoWriter($"-----Vendors Record Updated successfully...! {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.-------");

            //customerService.getCustomerListIDAndEditSequence();
            Console.WriteLine("************************************************************************************************************************");
            ExceptionWritter.LogInfoWriter($"----------------Application ends at {DateTime.Now.ToString("yyyy.MM.dd HH:mm:ss:ffff")}.----------------");
            Console.WriteLine("************************************************************************************************************************");

            


            Console.Read();
            Console.ReadLine();
            Console.ReadKey();

        }

    }
}
