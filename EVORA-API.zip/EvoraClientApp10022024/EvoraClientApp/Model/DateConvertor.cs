﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class DateConvertor
    {
       public static DateTime PrepareDate(DateTime inputDate)
        {
            // Subtract 8 hours from the input date
            DateTime preparedDate = inputDate.AddHours(-8);
            return preparedDate;
        }

    }
}
