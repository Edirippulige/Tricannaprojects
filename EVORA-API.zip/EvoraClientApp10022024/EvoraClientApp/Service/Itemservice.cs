﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using EvoraClientApp.dbconnect;
using EvoraClientApp.Model;
using EvoraClientApp.ExceptionHandler;
using System.Data.SqlClient;


namespace EvoraClientApp.Service
{


    public class ItemService
    {

        public static string serverName = "DESKTOP-JAY"; // Replace with your SQL Server name or IP address
        public static string databaseName = "QB"; // Replace with your database name
        public static string userName = "sa"; // Replace with your SQL Server username
        public static string password = "SQLT3$t23"; // Replace with your SQL Server password

        // Build the connection string
        public static string connectionString = $"Server={serverName};Database={databaseName};User Id={userName};Password={password};";

        private readonly string _connectionString = connectionString;

        public ItemService()
        {
        }

        public ItemService(string connectionString)
        {
            _connectionString = connectionString;
        }



        public List<EvoraItem> ReadItemsFromJsonString(string jsonContent)
        {
            try
            {
                if (string.IsNullOrEmpty(jsonContent))
                {
                    Console.WriteLine("JSON content is null or empty.");
                    return null;
                }


                return JsonSerializer.Deserialize<List<EvoraItem>>(jsonContent);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error deserializing JSON content: {ex.Message}");
                return null;
            }
        }





        public async Task SaveCustomersToDatabase(List<EvoraItem> evoraitem)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {

                    await connection.OpenAsync();

                    // Assuming there is a Customers table with appropriate schema

                    //using (SqlCommand command = new System.Data.SqlClient.SqlCommand("INSERT INTO Customers (BillAddr1, BillAddr2,BillAddr3,Billcity,Billcountry,Billpostalcode,Billstate,CustomerFullName,CustomerIsActive,CustomerName,Email,FirstName,LastName,LicenseNumber,MiddleName,phone,Salutation,ShipAddr1,ShipAddr2,Shipcity,ShipCountry,ShipNote,ShipPostalcode,Shipstate,LicenseExpiryDate) VALUES (@BillAddr1,@BillAddr2,@BillAddr3,@BillCity,@BillCountry,@BillNote,@BillPostalCode,@BillState,@CustomerFullName,@CustomerIsActive,@CustomerName,@Email,@FirstName,@LastName,@LicenseNumber,@MiddleName,@Phone,@Salutation,@ShipAddr1,@ShipAddr2,@ShipCity,@ShipCountry,@ShipNote,@ShipPostalCode,@ShipState,@ExpiryDate)", connection))
                    using (SqlCommand command = new System.Data.SqlClient.SqlCommand ("INSERT INTO Item (number,name,uom,purchase_uom,each_quantity,strain,inventory,price,count,average_weight,cost,tracking,reorder_lead_time,thc_mg"
                                                                                    + ", cbd_mg, pack_size_g, pack_count, expiration_months, new_lot_statu, expected_unit_cost, registration_number, sku, gtin, case_quantity"
                                                                                    +", minimum_quantity, product_number, description2, full_cost"
                                                                                     + ", total_unit_weight_g, sku_owner,vendorID)"
                                                                                     + "VALUES (@number, @name, @uom, @purchase_uom, @each_quantity, @strain, @inventory, @price, @count, @average_weight, @cost, @tracking, @reorder_lead_time, @thc_mg, @cbd_mg"
                                                                                     + ", @pack_size_g, @pack_count, @expiration_months, @new_lot_status, @expected_unit_cost, @registration_numb, @sku, @gtin, @case_quantity, @minimum_quantity, @product_number"
                                                                                    + ", @description2, @full_cost, @total_unit_weight_g, @sku_owner"
                                                                                     + ", @vendorID)", connection))
                    {
                        foreach (var item in evoraitem)
                        {
                            command.Parameters.Clear();
                            command.Parameters.AddWithValue("@EvoraItemNumber", (object)item.number?? DBNull.Value);
                            command.Parameters.AddWithValue("@EvoraItemName", (object)item.name ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Uom", (object)item.uom ?? DBNull.Value);
                            command.Parameters.AddWithValue("@PurchaseUOM", (object)item.purchaseUOM ?? DBNull.Value);
                            command.Parameters.AddWithValue("@EachQuantity", (object)item.eachQuantity ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Strain", (object)item.strain ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Inventory", (object)item.inventory ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Price", (object)item.price?? DBNull.Value);
                            command.Parameters.AddWithValue("@ItemCount", (object)item.count?? DBNull.Value);
                            command.Parameters.AddWithValue("@AverageWeight", (object)item.averageWeight ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Cost", (object)item.cost ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Tracking", (object)item.tracking?? DBNull.Value);
                            command.Parameters.AddWithValue("@ReorderLeadTime", (object)item.reorderLeadTime?? DBNull.Value);
                            command.Parameters.AddWithValue("@ThcMg", (object)item.thcMg ?? DBNull.Value);
                            command.Parameters.AddWithValue("@CbdMg", (object)item.cbdMg ?? DBNull.Value);
                            command.Parameters.AddWithValue("@PackSizeG", (object)item.packSizeG?? DBNull.Value);
                            command.Parameters.AddWithValue("@PackCount", (object)item.packCount ?? DBNull.Value);
                            command.Parameters.AddWithValue("@ExpirationMonths", (object)item.expirationMonths?? DBNull.Value);
                            command.Parameters.AddWithValue("@NewLotStatus", (object)item.newLotStatus?? DBNull.Value);
                            command.Parameters.AddWithValue("@ExpectedUnitCost", (object)item.expectedUnitCost ?? DBNull.Value);
                            command.Parameters.AddWithValue("@RegistrationNumer", (object)item.registrationNumer ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Sku", (object)item.sku ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Gtin", (object)item.gtin ?? DBNull.Value);
                            command.Parameters.AddWithValue("@CaseQuantity", (object)item.caseQuantity ?? DBNull.Value);
                            command.Parameters.AddWithValue("@MinimumQuantity", (object)item.minimumQuantity ?? DBNull.Value);
                            command.Parameters.AddWithValue("@ProductNumber", (object)item.productNumber ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Description2", (object)item.description2 ?? DBNull.Value);
                            command.Parameters.AddWithValue("@FullCost", (object)item.fullCost ?? DBNull.Value);
                            command.Parameters.AddWithValue("@TotalUnitWeightG", (object)item.totalUnitWeightG ?? DBNull.Value);
                            command.Parameters.AddWithValue("@SkuOwner", (object)item.skuOwner ?? DBNull.Value);
                           // command.Parameters.AddWithValue("@VendorID", (object)item.VendorID ?? DBNull.Value);
                            


                            

                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }

                Console.WriteLine("Customers saved to the database successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving customers to the database: {ex.Message}");
            }
        }
    }



}
