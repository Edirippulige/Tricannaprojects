﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class POrders
    {
        public string number { get; set; }
        public string description { get; set; }
        public object productionBatch { get; set; }
        public int quantity { get; set; }
        public string quantityUOM { get; set; }
        public int plannedQuantity { get; set; }
        public DateTime startDate { get; set; }
        public DateTime plannedStart { get; set; }
        public DateTime endDate { get; set; }
        public DateTime dueDate { get; set; }
        public string status { get; set; }
        public string location { get; set; }
        public object routing { get; set; }
        public object productionBom { get; set; }
        public bool custom { get; set; }
        public string outputItem { get; set; }
        public int inpurtCost { get; set; }
        public int labourCost { get; set; }
        public string notes { get; set; }
        public double processingLoss { get; set; }
        public int processingLossPercent { get; set; }
        public double inputCannabisTotal { get; set; }
        public double outputCannabisTotal { get; set; }
        public List<object> lines { get; set; }
        public List<Input> inputs { get; set; }
        public List<Output> outputs { get; set; }
        public List<object> activityOutputs { get; set; }
    }
}
