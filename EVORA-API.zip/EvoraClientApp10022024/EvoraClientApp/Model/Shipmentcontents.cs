﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class Shipmentcontents
    {
        public string id { get; set; }

        public string number { get; set; }

        public string item { get; set; }

        public string uom { get; set; }
        public decimal? quantity { get; set; }

        public string container { get; set; }
        public string lot { get; set; }
        public decimal? expectedquantity { get; set; }

       

    }
}
