﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Serilog;
using Serilog.Exceptions;



namespace TricannaAPI.ExceptionHandler
{
    class ExceptionWritter
    {
        private static readonly ILogger _logger;

        static ExceptionWritter()
        {
            //var documentFolderPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            //var subFolderPath = Path.Combine(documentFolderPath, "DataExtractErrors");

            // Serilog configurations
            // All the serilog configurations are define here except minimum logging level. default logging level get from the web.config
            _logger = new LoggerConfiguration()
                // Writes Serilog events to System.Diagnostics.Trace. further reference : https://github.com/serilog/serilog-sinks-trace
                .WriteTo.Trace()
                // Writes log events to the Windows Console or an ANSI terminal.Themes can be specified. further reference : https://github.com/serilog/serilog-sinks-console
                //.WriteTo.Console(theme: AnsiConsoleTheme.Code)
                // Writes Serilog events to text files Files write as per day. further reference : https://github.com/serilog/serilog-sinks-file
                // if you want to write as JSON format refer this :  https://github.com/serilog/serilog-formatting-compact
                .WriteTo.File("Info_logs/log-.txt", rollingInterval: RollingInterval.Day, fileSizeLimitBytes: null)
                // Supplemented with detailed exception information and even custom exception properties. further reference : https://github.com/RehanSaeed/Serilog.Exceptions
                .Enrich.WithExceptionDetails()
                .Enrich.FromLogContext()
                .CreateLogger();

            Serilog.Debugging.SelfLog.Enable(msg => Console.WriteLine("serilog_error - " + msg));
        }

        public static void LogInfo(string message)
        {
            try
            {
                _logger.Information(message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void LogError(Exception ex)
        {
            try
            {
                _logger.Error(ex, "API Error");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void LogError(string ex)
        {
            try
            {
                _logger.Error(ex, "API Error");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void LogInfoWriter(string message)
        {
            try
            {
                Console.WriteLine(message);
                LogInfo(message);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void LogErrorExceptionWriter(Exception ex)
        {
            try
            {
                _logger.Error("-----------------API Error-----------");
                _logger.Error(ex, "API Error");

                Console.WriteLine("-----------------API Error-----------");
                Console.WriteLine(ex);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void LogErrorWriter(string ex)
        {
            try
            {
                _logger.Error(ex, "API Error");
                Console.WriteLine(ex, "API Error");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
