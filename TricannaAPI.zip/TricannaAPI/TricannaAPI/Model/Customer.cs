﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TricannaAPI.Model
{
    public class Customer
    {
        public bool Active { get; set; }    //CustomerIsActive
        public string Name { get; set; }
        public decimal Balance { get; set; }
        public decimal BalanceTotal { get; set; }
        public string Company { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string MiddleInitial { get; set; }
        public string LastName { get; set; }
        public string PrimaryContact { get; set; }
        public string MainPhone { get; set; }
        public string Fax { get; set; }
        public string AltPhone { get; set; }
        public string SecondaryContact { get; set; }
        public string JobTitle { get; set; }
        public string MainEmail { get; set; }
        public string BillTo1 { get; set; }
        public string BillTo2 { get; set; }
        public string BillTo3 { get; set; }
        public string BillTo4 { get; set; }
        public string BillTo5 { get; set; }
        public string BillCity { get; set; }
        public string BillState { get; set; }
        public string BillPostalCode { get; set; }
        public string BillCountry { get; set; }
        public string ShipTo1 { get; set; }
        public string ShipTo2 { get; set; }
        public string ShipTo3 { get; set; }
        public string ShipTo4 { get; set; }
        public string ShipTo5 { get; set; }
        public string ShipCity { get; set; }
        public string ShipState { get; set; }
        public string ShipPostal { get; set; }
        public string ShipCountry { get; set; }
        public string LicenseNumber { get; set; }
        public string CustomerType { get; set; }
        public string Terms { get; set; }
        public string SalesRep { get; set; }
        public string SalesTaxCode { get; set; }
        public string TaxItem { get; set; }
        public string ResaleNumber { get; set; }
        public string AccountNumber { get; set; }
        public decimal CreditLimit { get; set; }
        public string JobStatus { get; set; }
        public string JobType { get; set; }
        public string JobDescription { get; set; }
        //public string LicNumber { get; set; }
        public string BillNote { get; set; }
        public string ShipNote { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime ProjectedEndDate { get; set; }
        public DateTime EndDate { get; set; }


    }
}



