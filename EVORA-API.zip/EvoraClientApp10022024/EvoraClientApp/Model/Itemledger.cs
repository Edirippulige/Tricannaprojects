﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class Itemledger
    {
        public string ID { get; set; }
        public string Number { get; set; }
        public string EntryType { get; set; }
        public string Item { get; set; }
        public string Description { get; set; }
        public string Lot { get; set; }
        public string BaseLot { get; set; }
        public string Location { get; set; }
        public double Quantity { get; set; }
        public string Uom { get; set; }
        public string  Activity { get; set; }
        public string Reason { get; set; }
        public string Bin { get; set; }
        public DateTime PostingDate { get; set; }
        public DateTime LastUpdated { get; set; }
        public string Expires { get; set; }
    }
}
