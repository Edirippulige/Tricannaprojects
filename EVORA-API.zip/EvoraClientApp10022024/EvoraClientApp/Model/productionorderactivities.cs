﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public  class productionorderactivities
    {
        public string id { get; set; }
        public string roomCleaning { get; set; }
        public string roomToClean { get; set; }
        public string productionOrder { get; set; }
        public string routing { get; set; }
        public string bom { get; set; }
        public string outputItem { get; set; }
        public string outputUOM { get; set; }
        public string outputQuantity { get; set; }
    }
}
