﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class Vendor
    {
        public string number { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public string phonenumber { get; set; }
        public string gender { get; set; }
        public DateTime? dob { get; set; }
        public string terms { get; set; }
        public string licenseType { get; set; }
        public string street1 { get; set; }
        public string street2 { get; set; }
        public string city { get; set; }
        public string prov { get; set; }
        public string postal { get; set; }
        public string country { get; set; }
        public string companyname { get; set; }
       


        public List<address> address { get; set; }









    }
}
