﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class EvoraCustomer
    {
        public string number { get; set; }
        public string name { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string type { get; set; }
        public string email { get; set; }
        public string gender { get; set; }
        public DateTime? dob { get; set; }
        public string terms { get; set; }
        public string foreignId { get; set; }
        public List<EvoraAddress> addresses  { get; set; }


    }
}
