﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    public class EvoraItem
    {
        public string number { get; set; }
        public string name { get; set; }
        public string category { get; set; }
        public string categoryName { get; set; }
        public string uom { get; set; }
        public string purchaseUOM { get; set; }
        public decimal? eachQuantity { get; set; }
        public string strain { get; set; }
        public decimal? inventory { get; set; }
        public decimal? price { get; set; }
        public decimal? count { get; set; }
        public decimal? averageWeight { get; set; }
        public decimal? cost { get; set; }
        public string tracking { get; set; }
        public string reorderLeadTime { get; set; }
        public string thcMg { get; set; }
        public string cbdMg { get; set; }
        public decimal? packSizeG { get; set; }
        public decimal? packCount { get; set; }
        public string expirationMonths { get; set; }
        public string newLotStatus { get; set; }
        public string expectedUnitCost { get; set; }
        public string registrationNumer { get; set; }
        public string sku { get; set; }
        public string gtin { get; set; }
        public decimal? caseQuantity { get; set; }
        public decimal? minimumQuantity { get; set; }
        public string productNumber { get; set; }
        public string description2 { get; set; }
        public decimal? fullCost { get; set; }
        public decimal? totalUnitWeightG { get; set; }
        public string skuOwner { get; set; }

       // public List <VendorID> vendorids { get; set; }

        public List<string> vendors { get; set; }
            

    }
}
