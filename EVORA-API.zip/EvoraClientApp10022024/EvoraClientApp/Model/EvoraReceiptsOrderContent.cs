﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
    class EvoraReceiptsOrderContent
    {
        public string id { get; set; }
        public string item { get; set; }
        public decimal? quantity { get; set; }
        public string uom { get; set; }
        public string count { get; set; }
        public string container { get; set; }
        public string lot { get; set; }
        public string bin { get; set; }
        public string vendorLot  { get; set; }
        public string totalUOM { get; set; }
        public string containerType { get; set; }
        public decimal? expectedquantity { get; set; }

        public decimal? unitCost { get; set; }
        public decimal? lineCost { get; set; }
        public decimal? tax { get; set; }
    }
}
