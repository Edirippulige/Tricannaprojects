﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvoraClientApp.Model
{
   public  class EvoraShipped
    {

        public string id { get; set; }
        public string item { get; set; }
        public string uom { get; set; }
        public double quantity { get; set; }
        public double percent { get; set; }
        

    }
}
