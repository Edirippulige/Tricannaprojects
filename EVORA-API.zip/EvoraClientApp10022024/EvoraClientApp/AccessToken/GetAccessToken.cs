﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text.Json;

namespace EvoraClientApp.AccessToken
{
    public class GetAccessToken
    {
        public async Task<string> GetEvoraAccessToken(string apiEndpoint, string username, string password)
        {
            using (HttpClient client = new HttpClient())
            {
                var tokenEndpoint = apiEndpoint;


                var tokenRequest = new FormUrlEncodedContent(new[]
                {
                new KeyValuePair<string, string>("grant_type", "password"),
                new KeyValuePair<string, string>("userid", username),
                new KeyValuePair<string, string>("password", password),
            });

                var tokenResponse = await client.PostAsync(tokenEndpoint, tokenRequest);

                if (tokenResponse.IsSuccessStatusCode)
                {
                    var tokenResponseContent = await tokenResponse.Content.ReadAsStringAsync();
                    var accessToken = JsonDocument.Parse(tokenResponseContent).RootElement.GetProperty("token").GetString();
                    //return  accessToken;
                    return accessToken?.Replace("Bearer ", "");
                    //return JsonDocument.Parse(tokenResponseContent).RootElement.GetProperty("access_token").GetString();
                }
                else
                {
                    throw new InvalidOperationException($"Error obtaining access token: {tokenResponse.StatusCode} - {tokenResponse.ReasonPhrase}");
                }
            }
        }
    }
}
